
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('customer');

$user = currentUser();
$userId = (int) $user['id'];

$pageTitle = 'Saved Events';
$activePage = 'saved-events';

$errors = [];
$success = '';
$events = [];

/*
|--------------------------------------------------------------------------
| Remove a saved event
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (!verifyCsrfToken($token)) {

        $errors[] = 'Invalid security token. Please refresh the page and try again.';

    } else {

        $savedId = filter_input(
            INPUT_POST,
            'saved_id',
            FILTER_VALIDATE_INT
        );

        if (!$savedId || $savedId < 1) {

            $errors[] = 'Invalid saved event.';

        } else {

            try {

                $stmt = $pdo->prepare("
                    DELETE FROM saved_events
                    WHERE id = :saved_id
                    AND user_id = :user_id
                ");

                $stmt->execute([
                    'saved_id' => $savedId,
                    'user_id' => $userId
                ]);

                if ($stmt->rowCount() > 0) {

                    $success = 'Event removed from your saved list.';

                } else {

                    $errors[] = 'Saved event not found or already removed.';
                }

            } catch (PDOException $e) {

                error_log('Remove saved event error: ' . $e->getMessage());

                $errors[] = 'Unable to remove this event. Please try again.';
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| Load saved events for the logged-in customer
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT
            se.id AS saved_id,
            e.id AS event_id,
            e.title,
            e.event_type,
            e.event_date,
            e.location,
            u.name AS organiser_name

        FROM saved_events se

        INNER JOIN events e
            ON e.id = se.event_id

        INNER JOIN users u
            ON u.id = e.user_id

        WHERE se.user_id = :user_id

        ORDER BY se.id DESC
    ");

    $stmt->execute([
        'user_id' => $userId
    ]);

    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log('Saved events loading error: ' . $e->getMessage());

    $errors[] = 'Unable to load saved events. Please check your database configuration.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1
        data-en="Saved Events"
        data-mr="जतन केलेले कार्यक्रम">
        Saved Events
    </h1>

    <p>
        Your collection of events you may want to attend.
    </p>

    <!-- Success message -->

    <?php if ($success !== ''): ?>

        <div class="alert alert-success">
            <?= h($success) ?>
        </div>

    <?php endif; ?>

    <!-- Error messages -->

    <?php if (!empty($errors)): ?>

        <div class="alert alert-error">

            <?php foreach (array_unique($errors) as $error): ?>

                <p><?= h($error) ?></p>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

    <!-- Saved events -->

    <div class="section-heading" style="margin-top:24px;">

        <h2>My Saved Events</h2>

        <span class="muted">
            <?= count($events) ?> saved events
        </span>

    </div>

    <?php if (!empty($events)): ?>

        <div style="
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
            gap:18px;
        ">

            <?php foreach ($events as $event): ?>

                <article class="card" style="padding:20px;">

                    <span class="role-badge">
                        <?= h($event['event_type'] ?: 'Event') ?>
                    </span>

                    <h2><?= h($event['title']) ?></h2>

                    <p>
                        <strong>Date:</strong>
                        <?= h(formatDate($event['event_date'])) ?>
                    </p>

                    <p>
                        <strong>Location:</strong>
                        <?= h($event['location'] ?: 'Not specified') ?>
                    </p>

                    <p>
                        <strong>Organiser:</strong>
                        <?= h($event['organiser_name']) ?>
                    </p>

                    <a
                        class="btn btn-primary"
                        href="<?= h(assetUrl(
                            'customer/event-details.php?id=' .
                            (int) $event['event_id']
                        )) ?>"
                    >
                        View Event
                    </a>

                    <form
                        method="POST"
                        style="margin-top:12px;"
                        onsubmit="return confirm('Are you sure you want to remove this saved event?');"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= h(csrfToken()) ?>"
                        >

                        <input
                            type="hidden"
                            name="saved_id"
                            value="<?= (int) $event['saved_id'] ?>"
                        >

                        <button
                            class="btn btn-secondary"
                            type="submit"
                        >
                            Remove Saved Event
                        </button>

                    </form>

                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="card" style="padding:24px;margin-top:20px;">

            <h3>No saved events yet</h3>

            <p class="muted">
                You have not saved any events.
                Explore upcoming events and save the ones
                you are interested in.
            </p>

            <a
                class="btn btn-primary"
                href="<?= h(assetUrl('customer/explore-events.php')) ?>"
            >
                Explore Events
            </a>

        </div>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
