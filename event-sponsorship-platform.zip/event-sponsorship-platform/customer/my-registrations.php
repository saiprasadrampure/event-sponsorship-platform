
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('customer');

$pageTitle = 'My Registrations';
$user = currentUser();
$registrations = [];
$errorMessage = '';

try {
    $sql = "
        SELECT
            r.id AS registration_id,
            r.status AS registration_status,
            r.created_at AS registration_date,
            e.id AS event_id,
            e.title,
            e.event_type,
            e.event_date,
            e.location,
            e.description,
            e.status AS event_status,
            u.name AS organiser_name
        FROM event_registrations r
        INNER JOIN events e ON e.id = r.event_id
        LEFT JOIN users u ON u.id = e.user_id
        WHERE r.customer_id = :customer_id
        ORDER BY r.created_at DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'customer_id' => $user['id']
    ]);

    $registrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('My registrations error: ' . $e->getMessage());
    $errorMessage = 'Unable to load your registrations. Please try again later.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-section">
    <div class="page-heading">
        <h1>My Registrations</h1>
        <p>Review the events you have registered for and check your registration status.</p>
    </div>

    <div class="content-card">

        <?php if ($errorMessage !== ''): ?>

            <div class="alert alert-danger">
                <?= h($errorMessage) ?>
            </div>

        <?php elseif (empty($registrations)): ?>

            <div class="empty-state">
                <h3>No registrations yet</h3>
                <p>You have not registered for any events.</p>
                <a href="<?= h(assetUrl('customer/explore-events.php')) ?>"
                   class="btn btn-primary">
                    Explore Events
                </a>
            </div>

        <?php else: ?>

            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Event</th>
                            <th>Event Date</th>
                            <th>Location</th>
                            <th>Organiser</th>
                            <th>Registration Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($registrations as $registration): ?>
                            <tr>
                                <td>
                                    <strong>
                                        <?= h($registration['title']) ?>
                                    </strong>
                                    <br>
                                    <small>
                                        <?= h($registration['event_type']) ?>
                                    </small>
                                </td>

                                <td>
                                    <?= h(formatDate($registration['event_date'])) ?>
                                </td>

                                <td>
                                    <?= h($registration['location']) ?>
                                </td>

                                <td>
                                    <?= h($registration['organiser_name'] ?? 'N/A') ?>
                                </td>

                                <td>
                                    <?= h(formatDate($registration['registration_date'])) ?>
                                </td>

                                <td>
                                    <span class="status-badge status-<?= h($registration['registration_status']) ?>">
                                        <?= h(ucfirst($registration['registration_status'])) ?>
                                    </span>
                                </td>

                                <td>
                                    <a class="btn btn-sm btn-primary"
                                       href="<?= h(assetUrl('customer/event-details.php?id=' . (int)$registration['event_id'])) ?>">
                                        View Event
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>

    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
