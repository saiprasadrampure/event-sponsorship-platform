
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('customer');

$user = currentUser();

$pageTitle = 'Explore Events';
$activePage = 'explore-events';

$search = trim((string) ($_GET['q'] ?? ''));
$type = trim((string) ($_GET['type'] ?? ''));

$types = [
    'Wedding',
    'Birthday',
    'Corporate',
    'Education',
    'Sports',
    'Music',
    'Cultural',
    'Charity',
    'Technology',
    'Other'
];

$events = [];
$errorMessage = '';

/*
|--------------------------------------------------------------------------
| Validate event category
|--------------------------------------------------------------------------
*/

if ($type !== '' && !in_array($type, $types, true)) {
    $type = '';
}

/*
|--------------------------------------------------------------------------
| Search upcoming published events
|--------------------------------------------------------------------------
*/

try {

    $sql = "
        SELECT
            e.id,
            e.title,
            e.event_type,
            e.event_date,
            e.location,
            e.description,
            u.name AS organiser_name
        FROM events e

        INNER JOIN users u
            ON u.id = e.user_id

        WHERE e.status = 'published'
          AND e.event_date >= CURDATE()

          AND (
              :search_empty = ''
              OR e.title LIKE :title_search
              OR e.location LIKE :location_search
          )

          AND (
              :type_empty = ''
              OR e.event_type = :event_type
          )

        ORDER BY e.event_date ASC, e.id DESC

        LIMIT 100
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        'search_empty' => $search,
        'title_search' => '%' . $search . '%',
        'location_search' => '%' . $search . '%',
        'type_empty' => $type,
        'event_type' => $type,
    ]);

    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log('Customer explore events error: ' . $e->getMessage());

    $errorMessage = 'Unable to load events. Please check your database configuration.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1
        data-en="Explore Events"
        data-mr="कार्यक्रम शोधा">
        Explore Events
    </h1>

    <p>
        Find celebrations, cultural programmes, corporate events,
        educational programmes, sports events and more.
    </p>

    <!-- Search and category filters -->

    <form
        method="GET"
        action="<?= h(assetUrl('customer/explore-events.php')) ?>"
        class="card"
        style="
            padding:18px;
            display:flex;
            gap:12px;
            flex-wrap:wrap;
            margin:20px 0;
        "
    >

        <input
            type="search"
            name="q"
            value="<?= h($search) ?>"
            placeholder="Search event or location"
            aria-label="Search events"
            style="flex:1;min-width:200px;"
        >

        <select
            name="type"
            aria-label="Event category"
        >

            <option value="">All Categories</option>

            <?php foreach ($types as $eventType): ?>

                <option
                    value="<?= h($eventType) ?>"
                    <?= $type === $eventType ? 'selected' : '' ?>
                >
                    <?= h($eventType) ?>
                </option>

            <?php endforeach; ?>

        </select>

        <button
            class="btn btn-primary"
            type="submit"
        >
            Search Events
        </button>

        <?php if ($search !== '' || $type !== ''): ?>

            <a
                class="btn btn-secondary"
                href="<?= h(assetUrl('customer/explore-events.php')) ?>"
            >
                Clear Filters
            </a>

        <?php endif; ?>

    </form>

    <!-- Error message -->

    <?php if ($errorMessage !== ''): ?>

        <div class="card" style="padding:16px;">
            <p class="alert alert-error">
                <?= h($errorMessage) ?>
            </p>
        </div>

    <?php else: ?>

        <!-- Event results heading -->

        <div class="section-heading">

            <h2>Available Events</h2>

            <span class="muted">
                <?= number_format(count($events)) ?> event(s) found
            </span>

        </div>

        <!-- Event cards -->

        <?php if (!empty($events)): ?>

            <div style="
                display:grid;
                grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
                gap:18px;
                margin-top:20px;
            ">

                <?php foreach ($events as $event): ?>

                    <article class="card" style="padding:20px;">

                        <span class="role-badge">
                            <?= h($event['event_type'] ?: 'Event') ?>
                        </span>

                        <h2><?= h($event['title']) ?></h2>

                        <p>
                            <strong>Date:</strong>
                            <?= h(formatDate($event['event_date'])) ?>
                        </p>

                        <p>
                            <strong>Location:</strong>
                            <?= h($event['location'] ?: 'Not specified') ?>
                        </p>

                        <p>
                            <strong>Organiser:</strong>
                            <?= h($event['organiser_name']) ?>
                        </p>

                        <p>
                            <?= h(mb_strimwidth(
                                (string) ($event['description'] ?? ''),
                                0,
                                140,
                                '...'
                            )) ?>
                        </p>

                        <a
                            class="btn btn-primary"
                            href="<?= h(assetUrl(
                                'customer/event-details.php?id=' .
                                (int) $event['id']
                            )) ?>"
                        >
                            View Event
                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="card" style="padding:24px;margin-top:20px;">

                <h3>No upcoming events found</h3>

                <p class="muted">
                    No events match your current search.
                    Try another keyword or select a different category.
                </p>

                <a
                    class="btn btn-primary"
                    href="<?= h(assetUrl('customer/explore-events.php')) ?>"
                >
                    Explore All Events
                </a>

            </div>

        <?php endif; ?>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
