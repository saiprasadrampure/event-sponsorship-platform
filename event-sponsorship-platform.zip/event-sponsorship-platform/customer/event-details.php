
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('customer');

$user = currentUser();
$pageTitle = 'Event Details';

$eventId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$eventId || $eventId < 1) {
    http_response_code(400);
    exit('Invalid event ID.');
}

$event = null;
$message = '';
$messageType = 'error';

try {
    // Load published event and organiser information.
    $stmt = $pdo->prepare("
        SELECT
            e.*,
            u.name AS organiser_name,
            u.email AS organiser_email
        FROM events e
        INNER JOIN users u ON u.id = e.user_id
        WHERE e.id = :event_id
          AND e.status = 'published'
        LIMIT 1
    ");

    $stmt->execute(['event_id' => $eventId]);
    $event = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$event) {
        http_response_code(404);
        exit('Event not found or not available.');
    }

    // Process registration.
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
            throw new RuntimeException(
                'Your session expired. Please refresh the page and try again.'
            );
        }

        if ($event['event_date'] < date('Y-m-d')) {
            throw new RuntimeException(
                'Registration is closed because this event has already started or ended.'
            );
        }

        $pdo->beginTransaction();

        // Check whether this customer already has a registration.
        $check = $pdo->prepare("
            SELECT id, status
            FROM event_registrations
            WHERE customer_id = :customer_id
              AND event_id = :event_id
            LIMIT 1
            FOR UPDATE
        ");

        $check->execute([
            'customer_id' => $user['id'],
            'event_id' => $eventId
        ]);

        $existing = $check->fetch(PDO::FETCH_ASSOC);

        if ($existing && $existing['status'] === 'registered') {
            $pdo->rollBack();

            throw new RuntimeException(
                'You have already registered for this event.'
            );
        }

        if ($existing) {
            // Restore a previously cancelled registration.
            $update = $pdo->prepare("
                UPDATE event_registrations
                SET status = 'registered'
                WHERE id = :id
            ");

            $update->execute(['id' => $existing['id']]);

        } else {
            // Create a new registration.
            $insert = $pdo->prepare("
                INSERT INTO event_registrations
                    (customer_id, event_id, status)
                VALUES
                    (:customer_id, :event_id, 'registered')
            ");

            $insert->execute([
                'customer_id' => $user['id'],
                'event_id' => $eventId
            ]);
        }

        $pdo->commit();

        $message = 'Your event registration was successful!';
        $messageType = 'success';
    }

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    if ($e instanceof RuntimeException) {
        $message = $e->getMessage();
    } else {
        error_log('Event registration error: ' . $e->getMessage());
        $message = 'Unable to process your registration. Please try again.';
    }

    $messageType = 'error';
}

// Check current registration status.
$registrationStatus = null;

try {
    $statusStmt = $pdo->prepare("
        SELECT status
        FROM event_registrations
        WHERE customer_id = :customer_id
          AND event_id = :event_id
        LIMIT 1
    ");

    $statusStmt->execute([
        'customer_id' => $user['id'],
        'event_id' => $eventId
    ]);

    $registrationStatus = $statusStmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Registration status error: ' . $e->getMessage());
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-section">

    <div class="page-heading">
        <h1>Event Details</h1>
        <p>Explore this event and book your place.</p>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert <?= $messageType === 'success' ? 'alert-success' : 'alert-danger' ?>">
            <?= h($message) ?>
        </div>
    <?php endif; ?>

    <div class="content-card">

        <h2><?= h($event['title']) ?></h2>

        <p>
            <strong>Event Type:</strong>
            <?= h($event['event_type']) ?>
        </p>

        <p>
            <strong>Event Date:</strong>
            <?= h(formatDate($event['event_date'])) ?>
        </p>

        <p>
            <strong>Location:</strong>
            <?= h($event['location']) ?>
        </p>

        <p>
            <strong>Organiser:</strong>
            <?= h($event['organiser_name']) ?>
        </p>

        <p>
            <strong>Expected Attendees:</strong>
            <?= h($event['expected_attendees'] ?? 'Not specified') ?>
        </p>

        <p>
            <strong>Event Description:</strong>
        </p>

        <p><?= nl2br(h($event['description'] ?? 'No description available.')) ?></p>

        <hr>

        <?php if ($registrationStatus === 'registered'): ?>

            <div class="alert alert-success">
                You are already registered for this event!
            </div>

        <?php elseif ($event['event_date'] < date('Y-m-d')): ?>

            <div class="alert alert-danger">
                Registration is closed for this event.
            </div>

        <?php else: ?>

            <form method="POST" action="">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= h(csrfToken()) ?>"
                >

                <button type="submit" class="btn btn-primary"
                    onclick="return confirm('Are you sure you want to register for this event?');">
                    Register / Book Event
                </button>
            </form>

        <?php endif; ?>

        <br>

        <a href="<?= h(assetUrl('customer/my-registrations.php')) ?>"
           class="btn btn-secondary">
            My Registrations
        </a>

        <a href="<?= h(assetUrl('customer/explore-events.php')) ?>"
           class="btn btn-secondary">
            Back to Events
        </a>

    </div>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
