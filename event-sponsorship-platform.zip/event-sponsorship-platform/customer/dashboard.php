
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('customer');

$user = currentUser();
$userId = (int) $user['id'];

$pageTitle = 'Customer Dashboard';
$activePage = 'dashboard';

$stats = [
    'registrations' => 0,
    'saved_events' => 0,
    'upcoming_events' => 0,
];

$recentRegistrations = [];
$upcomingEvents = [];
$dashboardErrors = [];

/*
|--------------------------------------------------------------------------
| Total event registrations
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM event_registrations
        WHERE user_id = :user_id
    ");

    $stmt->execute(['user_id' => $userId]);
    $stats['registrations'] = (int) $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Customer registration statistics: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load registration statistics.';
}

/*
|--------------------------------------------------------------------------
| Saved events count
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM saved_events
        WHERE user_id = :user_id
    ");

    $stmt->execute(['user_id' => $userId]);
    $stats['saved_events'] = (int) $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Customer saved events statistics: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load saved events statistics.';
}

/*
|--------------------------------------------------------------------------
| Upcoming published events count
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->query("
        SELECT COUNT(*)
        FROM events
        WHERE status = 'published'
        AND event_date >= CURDATE()
    ");

    $stats['upcoming_events'] = (int) $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Customer upcoming events statistics: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load upcoming event statistics.';
}

/*
|--------------------------------------------------------------------------
| Recent registrations
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT
            er.id AS registration_id,
            er.event_id,
            er.created_at AS registration_date,
            e.title,
            e.event_type,
            e.event_date,
            e.location
        FROM event_registrations er
        INNER JOIN events e ON e.id = er.event_id
        WHERE er.user_id = :user_id
        ORDER BY er.created_at DESC
        LIMIT 5
    ");

    $stmt->execute(['user_id' => $userId]);

    $recentRegistrations = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Customer recent registrations: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load recent registrations.';
}

/*
|--------------------------------------------------------------------------
| Upcoming events
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT
            e.id,
            e.title,
            e.event_type,
            e.event_date,
            e.location,
            e.description,
            u.name AS organiser_name
        FROM events e
        INNER JOIN users u ON u.id = e.user_id
        WHERE e.status = 'published'
        AND e.event_date >= CURDATE()
        ORDER BY e.event_date ASC
        LIMIT 5
    ");

    $stmt->execute();

    $upcomingEvents = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Customer upcoming events: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load upcoming events.';
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="dashboard-layout">

    <?php require __DIR__ . '/../includes/sidebar.php'; ?>

    <section class="dashboard-main">

        <!-- Dashboard heading -->

        <div class="dashboard-topbar">

            <div>

                <h1
                    data-en="Customer Dashboard"
                    data-mr="ग्राहक डॅशबोर्ड">
                    Customer Dashboard
                </h1>

                <p class="muted">

                    <span
                        data-en="Welcome back,"
                        data-mr="पुन्हा स्वागत आहे,">
                        Welcome back,
                    </span>

                    <?= h($user['name']) ?>!

                </p>

            </div>

            <a
                class="btn btn-primary"
                href="<?= h(assetUrl('customer/explore-events.php')) ?>"
                data-en="Explore Events"
                data-mr="कार्यक्रम शोधा">
                Explore Events
            </a>

        </div>

        <!-- Error messages -->

        <?php if (!empty($dashboardErrors)): ?>

            <div class="card" style="padding:15px;margin-bottom:20px;">

                <p class="muted">
                    Some dashboard information could not be loaded.
                    Please check the application error log.
                </p>

            </div>

        <?php endif; ?>

        <!-- Dashboard statistics -->

        <div class="stats-grid">

            <article class="stat-card">

                <span
                    class="stat-label"
                    data-en="My Registrations"
                    data-mr="माझी नोंदणी">
                    My Registrations
                </span>

                <span class="stat-value">
                    <?= number_format($stats['registrations']) ?>
                </span>

                <span class="muted">
                    Events you registered for
                </span>

            </article>

            <article class="stat-card">

                <span
                    class="stat-label"
                    data-en="Saved Events"
                    data-mr="जतन केलेले कार्यक्रम">
                    Saved Events
                </span>

                <span class="stat-value">
                    <?= number_format($stats['saved_events']) ?>
                </span>

                <span class="muted">
                    Events saved for later
                </span>

            </article>

            <article class="stat-card">

                <span
                    class="stat-label"
                    data-en="Upcoming Events"
                    data-mr="आगामी कार्यक्रम">
                    Upcoming Events
                </span>

                <span class="stat-value">
                    <?= number_format($stats['upcoming_events']) ?>
                </span>

                <span class="muted">
                    Published event opportunities
                </span>

            </article>

        </div>

        <!-- Quick actions -->

        <div class="section-heading">

            <h2
                data-en="Quick Actions"
                data-mr="जलद कृती">
                Quick Actions
            </h2>

        </div>

        <div class="card-grid">

            <article class="card">

                <h3>🎉 Explore Events</h3>

                <p class="muted">
                    Discover upcoming festivals, college events,
                    cultural programs and other activities.
                </p>

                <a
                    class="btn"
                    href="<?= h(assetUrl('customer/explore-events.php')) ?>">
                    Explore Events
                </a>

            </article>

            <article class="card">

                <h3>❤️ Saved Events</h3>

                <p class="muted">
                    View events you have saved and revisit
                    interesting opportunities.
                </p>

                <a
                    class="btn"
                    href="<?= h(assetUrl('customer/saved-events.php')) ?>">
                    View Saved Events
                </a>

            </article>

            <article class="card">

                <h3>📅 My Registrations</h3>

                <p class="muted">
                    Review the events you have registered for.
                </p>

                <a
                    class="btn"
                    href="<?= h(assetUrl('customer/my-registrations.php')) ?>">
                    My Registrations
                </a>

            </article>

        </div>

        <!-- Recent registrations -->

        <div class="section-heading" style="margin-top:32px;">

            <h2
                data-en="My Recent Registrations"
                data-mr="माझ्या अलीकडील नोंदणी">
                My Recent Registrations
            </h2>

            <a href="<?= h(assetUrl('customer/my-registrations.php')) ?>">
                View all →
            </a>

        </div>

        <?php if (empty($recentRegistrations)): ?>

            <div class="card" style="padding:20px;">

                <h3>No registrations yet</h3>

                <p class="muted">
                    You have not registered for any events yet.
                    Explore events and find something interesting.
                </p>

                <a
                    class="btn btn-primary"
                    href="<?= h(assetUrl('customer/explore-events.php')) ?>">
                    Find Events
                </a>

            </div>

        <?php else: ?>

            <div class="dashboard-grid">

                <?php foreach ($recentRegistrations as $registration): ?>

                    <article class="event-card">

                        <span class="badge">
                            <?= h($registration['event_type'] ?: 'Event') ?>
                        </span>

                        <h3>
                            <?= h($registration['title']) ?>
                        </h3>

                        <p>
                            <strong>Date:</strong>
                            <?= h(formatDate($registration['event_date'])) ?>
                        </p>

                        <p>
                            <strong>Location:</strong>
                            <?= h($registration['location'] ?: 'Not specified') ?>
                        </p>

                        <p class="muted">
                            Registered:
                            <?= h(formatDate($registration['registration_date'])) ?>
                        </p>

                        <a
                            class="btn"
                            href="<?= h(assetUrl(
                                'customer/event-details.php?id=' .
                                (int) $registration['event_id']
                            )) ?>">
                            View Event
                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

        <!-- Upcoming events -->

        <div class="section-heading" style="margin-top:32px;">

            <h2
                data-en="Discover Upcoming Events"
                data-mr="आगामी कार्यक्रम शोधा">
                Discover Upcoming Events
            </h2>

            <a href="<?= h(assetUrl('customer/explore-events.php')) ?>">
                View all →
            </a>

        </div>

        <?php if (empty($upcomingEvents)): ?>

            <div class="card" style="padding:20px;">

                <h3>No upcoming events available</h3>

                <p class="muted">
                    New published events will appear here.
                </p>

            </div>

        <?php else: ?>

            <div class="dashboard-grid">

                <?php foreach ($upcomingEvents as $event): ?>

                    <article class="event-card">

                        <span class="badge">
                            <?= h($event['event_type'] ?: 'Event') ?>
                        </span>

                        <h3><?= h($event['title']) ?></h3>

                        <p>
                            <strong>Date:</strong>
                            <?= h(formatDate($event['event_date'])) ?>
                        </p>

                        <p>
                            <strong>Location:</strong>
                            <?= h($event['location'] ?: 'Not specified') ?>
                        </p>

                        <p class="muted">
                            Organiser:
                            <?= h($event['organiser_name']) ?>
                        </p>

                        <p>
                            <?= h(mb_strimwidth(
                                (string) ($event['description'] ?? ''),
                                0,
                                140,
                                '...'
                            )) ?>
                        </p>

                        <a
                            class="btn"
                            href="<?= h(assetUrl(
                                'customer/event-details.php?id=' .
                                (int) $event['id']
                            )) ?>">
                            View Event
                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </section>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
