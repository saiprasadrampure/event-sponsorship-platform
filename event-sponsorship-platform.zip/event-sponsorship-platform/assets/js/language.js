
/* EventConnect AI - English / Marathi */

(() => {
    const STORAGE_KEY = "ec-language";
    const root = document.documentElement;

    function applyLanguage(language) {
        const selectedLanguage = language === "mr" ? "mr" : "en";

        root.lang = selectedLanguage;

        document.querySelectorAll("[data-en][data-mr]").forEach(element => {
            const translation = element.dataset[selectedLanguage];

            if (translation !== undefined) {
                element.textContent = translation;
            }
        });

        document.querySelectorAll("[data-language-toggle]").forEach(button => {
            button.textContent =
                selectedLanguage === "en" ? "मराठी" : "English";

            button.setAttribute(
                "aria-label",
                selectedLanguage === "en"
                    ? "Switch language to Marathi"
                    : "Switch language to English"
            );
        });

        try {
            localStorage.setItem(STORAGE_KEY, selectedLanguage);
        } catch (error) {
            console.warn("Language preference could not be saved.");
        }
    }

    document.addEventListener("DOMContentLoaded", () => {
        let savedLanguage = "en";

        try {
            savedLanguage = localStorage.getItem(STORAGE_KEY) || "en";
        } catch (error) {
            // Continue with English.
        }

        applyLanguage(savedLanguage);

        document.addEventListener("click", event => {
            const button = event.target.closest("[data-language-toggle]");

            if (!button) return;

            applyLanguage(root.lang === "mr" ? "en" : "mr");
        });
    });
})();
