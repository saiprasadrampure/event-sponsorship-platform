
/* EventConnect AI - Main Application */

document.addEventListener("DOMContentLoaded", () => {
    initializeMobileMenu();
    initializeCurrentYear();
    initializeConfirmActions();

    console.log("EventConnect AI initialized successfully.");
});

function initializeMobileMenu() {
    const toggle = document.querySelector("[data-menu-toggle]");
    const menu = document.querySelector("[data-mobile-menu]");

    if (!toggle || !menu) return;

    toggle.addEventListener("click", () => {
        const isOpen = toggle.getAttribute("aria-expanded") === "true";

        toggle.setAttribute("aria-expanded", String(!isOpen));
        menu.hidden = isOpen;
    });
}

function initializeCurrentYear() {
    document.querySelectorAll("[data-current-year]").forEach(element => {
        element.textContent = new Date().getFullYear();
    });
}

function initializeConfirmActions() {
    document.querySelectorAll("[data-confirm]").forEach(element => {
        element.addEventListener("click", event => {
            const message = element.dataset.confirm;

            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
}
