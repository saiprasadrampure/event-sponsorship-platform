
/* EventConnect AI - Notifications */

(() => {
    function getContainer() {
        let container = document.getElementById("notification-container");

        if (!container) {
            container = document.createElement("div");
            container.id = "notification-container";
            container.setAttribute("aria-live", "polite");
            container.setAttribute("aria-atomic", "false");

            Object.assign(container.style, {
                position: "fixed",
                top: "20px",
                right: "20px",
                zIndex: "9999",
                display: "grid",
                gap: "10px",
                width: "min(360px, calc(100vw - 40px))"
            });

            document.body.appendChild(container);
        }

        return container;
    }

    function showNotification(message, type = "info", duration = 4000) {
        const allowedTypes = ["success", "error", "warning", "info"];

        if (!allowedTypes.includes(type)) {
            type = "info";
        }

        const notification = document.createElement("div");
        notification.className = `app-notification notification-${type}`;
        notification.setAttribute(
            "role",
            type === "error" ? "alert" : "status"
        );

        const text = document.createElement("span");
        text.textContent = String(message);

        const close = document.createElement("button");
        close.type = "button";
        close.textContent = "×";
        close.setAttribute("aria-label", "Dismiss notification");

        Object.assign(notification.style, {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "12px",
            padding: "14px 16px",
            borderRadius: "12px",
            border: "1px solid var(--border, #ddd)",
            background: "var(--surface, #fff)",
            color: "var(--text, #182033)",
            boxShadow: "0 8px 25px rgba(0,0,0,.12)"
        });

        close.style.cssText =
            "background:transparent;color:inherit;border:0;" +
            "font-size:22px;padding:0 4px;cursor:pointer";

        notification.append(text, close);
        getContainer().appendChild(notification);

        let timer;

        function dismiss() {
            if (timer) clearTimeout(timer);
            notification.remove();
        }

        close.addEventListener("click", dismiss);

        if (duration > 0) {
            timer = setTimeout(dismiss, duration);
        }

        return { dismiss };
    }

    window.showNotification = showNotification;
})();
