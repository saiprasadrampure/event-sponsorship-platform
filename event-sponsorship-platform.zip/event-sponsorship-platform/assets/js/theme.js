
/* EventConnect AI - Dark / Light Mode */

(() => {
    const STORAGE_KEY = "ec-theme";
    const root = document.documentElement;

    function applyTheme(theme) {
        const selectedTheme = theme === "dark" ? "dark" : "light";

        root.dataset.theme = selectedTheme;

        const button = document.querySelector("[data-theme-toggle]");

        if (button) {
            button.textContent =
                selectedTheme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode";

            button.setAttribute(
                "aria-label",
                selectedTheme === "dark"
                    ? "Switch to light mode"
                    : "Switch to dark mode"
            );

            button.setAttribute("aria-pressed", String(selectedTheme === "dark"));
        }

        try {
            localStorage.setItem(STORAGE_KEY, selectedTheme);
        } catch (error) {
            console.warn("Theme preference could not be saved.");
        }
    }

    function initializeTheme() {
        let savedTheme = "light";

        try {
            savedTheme = localStorage.getItem(STORAGE_KEY) || "light";
        } catch (error) {
            // Continue with the default theme.
        }

        applyTheme(savedTheme);
    }

    document.addEventListener("DOMContentLoaded", () => {
        initializeTheme();

        document.addEventListener("click", event => {
            const button = event.target.closest("[data-theme-toggle]");

            if (!button) return;

            const currentTheme = root.dataset.theme || "light";

            applyTheme(currentTheme === "dark" ? "light" : "dark");
        });
    });
})();
