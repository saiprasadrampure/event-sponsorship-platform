
/* EventConnect AI - Form Validation */

document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll("form[data-validate]").forEach(form => {
        form.addEventListener("submit", event => {
            clearErrors(form);

            const fields = form.querySelectorAll("[data-validate-field]");
            let firstInvalid = null;

            fields.forEach(field => {
                const error = validateField(field);

                if (error) {
                    showError(field, error);
                    if (!firstInvalid) firstInvalid = field;
                }
            });

            if (firstInvalid) {
                event.preventDefault();
                firstInvalid.focus();
            }
        });

        form.querySelectorAll("[data-validate-field]").forEach(field => {
            field.addEventListener("input", () => {
                clearFieldError(field);
            });

            field.addEventListener("change", () => {
                clearFieldError(field);
            });
        });
    });
});

function validateField(field) {
    const value = field.value.trim();

    if (field.required && !value) {
        return "This field is required.";
    }

    if (!value) return "";

    if (field.type === "email") {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(value)) {
            return "Enter a valid email address.";
        }
    }

    if (field.name === "password" && value.length < 8) {
        return "Password must be at least 8 characters.";
    }

    if (
        field.name === "confirm_password" &&
        value !== field.form.elements.password?.value
    ) {
        return "Passwords do not match.";
    }

    if (field.type === "number") {
        const number = Number(value);

        if (!Number.isFinite(number)) {
            return "Enter a valid number.";
        }

        if (field.min !== "" && number < Number(field.min)) {
            return `Value must be at least ${field.min}.`;
        }

        if (field.max !== "" && number > Number(field.max)) {
            return `Value must not exceed ${field.max}.`;
        }
    }

    return "";
}

function showError(field, message) {
    field.setAttribute("aria-invalid", "true");

    const error = document.createElement("small");
    error.className = "form-error";
    error.dataset.validationError = "true";
    error.textContent = message;

    field.insertAdjacentElement("afterend", error);
}

function clearFieldError(field) {
    field.removeAttribute("aria-invalid");

    const next = field.nextElementSibling;

    if (next?.dataset.validationError === "true") {
        next.remove();
    }
}

function clearErrors(form) {
    form.querySelectorAll("[data-validation-error]").forEach(error => {
        error.remove();
    });

    form.querySelectorAll('[aria-invalid="true"]').forEach(field => {
        field.removeAttribute("aria-invalid");
    });
}
