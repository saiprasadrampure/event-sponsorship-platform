
<?php

// ========================================
// DATABASE, AUTHENTICATION AND FUNCTIONS
// ========================================

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';


// ========================================
// ORGANISER AUTHENTICATION
// ========================================

requireRole('event_organiser');

$user = currentUser();

$id = (int) $user['id'];

$pageTitle = 'Organiser Dashboard';
$activePage = 'dashboard';


// ========================================
// INITIALIZE DASHBOARD DATA
// ========================================

$stats = [
    'total' => 0,
    'published' => 0,
    'completed' => 0,
    'applications' => 0
];

$events = [];

$errorMessage = '';


// ========================================
// FETCH DASHBOARD STATISTICS
// ========================================

try {

    // Event statistics
    $stmt = $pdo->prepare("
        SELECT
            COUNT(*) AS total,
            COALESCE(SUM(status = 'published'), 0) AS published,
            COALESCE(SUM(status = 'completed'), 0) AS completed
        FROM events
        WHERE user_id = ?
    ");

    $stmt->execute([$id]);

    $result = $stmt->fetch();

    if ($result) {
        $stats = array_merge($stats, $result);
    }


    // Sponsorship application count
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM sponsorship_applications sa
        INNER JOIN events e ON e.id = sa.event_id
        WHERE e.user_id = ?
    ");

    $stmt->execute([$id]);

    $stats['applications'] = (int) $stmt->fetchColumn();


    // Recent events
    $stmt = $pdo->prepare("
        SELECT
            id,
            title,
            event_type,
            event_date,
            location,
            status
        FROM events
        WHERE user_id = ?
        ORDER BY event_date DESC
        LIMIT 5
    ");

    $stmt->execute([$id]);

    $events = $stmt->fetchAll();


} catch (PDOException $e) {

    error_log(
        'Organiser dashboard error: ' . $e->getMessage()
    );

    $errorMessage = 'Dashboard data could not be loaded. Please check your database tables.';

}


// ========================================
// PAGE HEADER AND SIDEBAR
// ========================================

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';

?>

<!-- ========================================
     ORGANISER DASHBOARD
========================================= -->

<section class="dashboard-container">

    <h1>
        Welcome, <?= h($user['name']) ?>!
    </h1>

    <p>
        Manage your events and discover potential sponsors.
    </p>


    <?php if ($errorMessage !== ''): ?>

        <p class="alert alert-error">
            <?= h($errorMessage) ?>
        </p>

    <?php endif; ?>


    <!-- ========================================
         DASHBOARD STATISTICS
    ========================================= -->

    <div style="
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
        gap:16px;
        margin:24px 0;
    ">

        <?php

        $dashboardStats = [
            'Total Events' => $stats['total'],
            'Published Events' => $stats['published'],
            'Completed Events' => $stats['completed'],
            'Sponsorship Applications' => $stats['applications']
        ];

        ?>

        <?php foreach ($dashboardStats as $label => $value): ?>

            <article class="card" style="padding:22px">

                <p>
                    <?= h($label) ?>
                </p>

                <h2>
                    <?= (int) $value ?>
                </h2>

            </article>

        <?php endforeach; ?>

    </div>


    <!-- ========================================
         QUICK ACTION BUTTONS
    ========================================= -->

    <div style="
        display:flex;
        gap:12px;
        flex-wrap:wrap;
        margin-bottom:24px;
    ">

        <a
            class="btn btn-primary"
            href="<?= h(assetUrl('organiser/create-event.php')) ?>"
        >
            + Create Event
        </a>


        <a
            class="btn btn-secondary"
            href="<?= h(assetUrl('organiser/ai-sponsors.php')) ?>"
        >
            Find AI Sponsors
        </a>


        <a
            class="btn btn-secondary"
            href="<?= h(assetUrl('organiser/sponsorship-applications.php')) ?>"
        >
            View Applications
        </a>

    </div>


    <!-- ========================================
         RECENT EVENTS
    ========================================= -->

    <h2>Your Recent Events</h2>


    <div class="card" style="
        padding:20px;
        overflow-x:auto;
    ">

        <table style="
            width:100%;
            border-collapse:collapse;
        ">

            <thead>

                <tr>

                    <th align="left">Event</th>

                    <th align="left">Date</th>

                    <th align="left">Status</th>

                    <th align="left">Action</th>

                </tr>

            </thead>


            <tbody>

                <?php if (!empty($events)): ?>

                    <?php foreach ($events as $event): ?>

                        <tr>

                            <td>
                                <?= h($event['title']) ?>
                            </td>


                            <td>
                                <?= h(
                                    formatDate($event['event_date'])
                                ) ?>
                            </td>


                            <td>
                                <?= h(
                                    ucfirst($event['status'])
                                ) ?>
                            </td>


                            <td>

                                <a href="<?= h(
                                    assetUrl(
                                        'organiser/event-details.php?id=' .
                                        (int) $event['id']
                                    )
                                ) ?>">
                                    View
                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="4">
                            No events yet. Create your first event!
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</section>


<?php

// ========================================
// PAGE FOOTER
// ========================================

require_once __DIR__ . '/../includes/footer.php';

?>
