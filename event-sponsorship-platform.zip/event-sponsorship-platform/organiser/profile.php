
<?php

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';


// ========================================
// ORGANISER AUTHENTICATION
// ========================================

requireRole('event_organiser');

$user = currentUser();
$id = (int) $user['id'];

$pageTitle = 'Organiser Profile';
$activePage = 'profile';

$errors = [];
$success = '';


// ========================================
// FETCH ORGANISER PROFILE
// ========================================

try {

    $stmt = $pdo->prepare("
        SELECT name, email
        FROM users
        WHERE id = :id
        LIMIT 1
    ");

    $stmt->execute([
        ':id' => $id
    ]);

    $profile = $stmt->fetch();

    if (!$profile) {
        http_response_code(404);
        exit('Profile not found.');
    }

} catch (PDOException $e) {

    error_log('Organiser profile fetch error: ' . $e->getMessage());

    exit('Unable to load organiser profile.');
}


// ========================================
// HANDLE PROFILE UPDATE
// ========================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrfToken = $_POST['csrf_token'] ?? null;

    if (!verifyCsrfToken($csrfToken)) {

        $errors[] = 'Invalid or expired security token. Please refresh the page.';

    } else {

        $name = trim((string) ($_POST['name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));

        $password = (string) ($_POST['password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        // Validate name
        if (
            $name === '' ||
            mb_strlen($name, 'UTF-8') > 100
        ) {
            $errors[] = 'Enter a name up to 100 characters.';
        }

        // Validate email
        if (
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            strlen($email) > 190
        ) {
            $errors[] = 'Enter a valid email address.';
        }

        // Validate password if provided
        if ($password !== '') {

            if (strlen($password) < 8) {
                $errors[] = 'Password must be at least 8 characters.';
            }

            if ($password !== $confirm) {
                $errors[] = 'Passwords do not match.';
            }
        }

        // Update profile if validation succeeds
        if (empty($errors)) {

            try {

                // Check whether email is already registered
                $stmt = $pdo->prepare("
                    SELECT id
                    FROM users
                    WHERE email = :email
                      AND id <> :id
                    LIMIT 1
                ");

                $stmt->execute([
                    ':email' => $email,
                    ':id' => $id
                ]);

                if ($stmt->fetch()) {

                    $errors[] = 'This email address is already registered.';

                } else {

                    // Update profile with new password
                    if ($password !== '') {

                        $passwordHash = password_hash(
                            $password,
                            PASSWORD_DEFAULT
                        );

                        $stmt = $pdo->prepare("
                            UPDATE users
                            SET name = :name,
                                email = :email,
                                password_hash = :password_hash
                            WHERE id = :id
                        ");

                        $stmt->execute([
                            ':name' => $name,
                            ':email' => $email,
                            ':password_hash' => $passwordHash,
                            ':id' => $id
                        ]);

                    } else {

                        // Update name and email only
                        $stmt = $pdo->prepare("
                            UPDATE users
                            SET name = :name,
                                email = :email
                            WHERE id = :id
                        ");

                        $stmt->execute([
                            ':name' => $name,
                            ':email' => $email,
                            ':id' => $id
                        ]);
                    }

                    // Update session information
                    $_SESSION['user_name'] = $name;

                    // Update displayed profile
                    $profile = [
                        'name' => $name,
                        'email' => $email
                    ];

                    $success = 'Profile updated successfully.';
                }

            } catch (PDOException $e) {

                error_log('Organiser profile update error: ' . $e->getMessage());

                $errors[] = 'Unable to update profile. Please try again.';
            }
        }

        // Preserve entered values when validation fails
        if (!empty($errors)) {

            $profile['name'] = $name;
            $profile['email'] = $email;
        }
    }
}


// ========================================
// LOAD HEADER AND SIDEBAR
// ========================================

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';

?>

<section class="dashboard-container">

    <h1>My Profile</h1>

    <p>Manage your organiser account details.</p>


    <!-- PROFILE FORM -->

    <div class="card" style="max-width:650px; padding:24px;">


        <!-- SUCCESS MESSAGE -->

        <?php if ($success): ?>

            <p class="alert alert-success">
                <?= h($success) ?>
            </p>

        <?php endif; ?>


        <!-- ERROR MESSAGES -->

        <?php if (!empty($errors)): ?>

            <div class="alert alert-error">

                <?php foreach ($errors as $error): ?>

                    <p><?= h($error) ?></p>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <!-- EDIT PROFILE FORM -->

        <form
            method="POST"
            action="<?= h(assetUrl('organiser/profile.php')) ?>"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h(csrfToken()) ?>"
            >


            <!-- FULL NAME -->

            <div class="form-group">

                <label for="name">
                    Full Name
                </label>

                <input
                    type="text"
                    id="name"
                    name="name"
                    maxlength="100"
                    value="<?= h($profile['name']) ?>"
                    placeholder="Enter your full name"
                    required
                >

            </div>


            <!-- EMAIL -->

            <div class="form-group">

                <label for="email">
                    Email Address
                </label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    maxlength="190"
                    value="<?= h($profile['email']) ?>"
                    placeholder="Enter your email"
                    required
                >

            </div>


            <!-- NEW PASSWORD -->

            <div class="form-group">

                <label for="password">
                    New Password (Optional)
                </label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    minlength="8"
                    autocomplete="new-password"
                    placeholder="Enter new password"
                >

                <small class="muted">
                    Leave blank if you do not want to change your password.
                </small>

            </div>


            <!-- CONFIRM PASSWORD -->

            <div class="form-group">

                <label for="confirm_password">
                    Confirm New Password
                </label>

                <input
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    minlength="8"
                    autocomplete="new-password"
                    placeholder="Confirm your new password"
                >

            </div>


            <!-- SAVE BUTTON -->

            <button
                type="submit"
                class="btn btn-primary"
            >
                Save Profile
            </button>

        </form>

    </div>

</section>


<?php require_once __DIR__ . '/../includes/footer.php'; ?>
