
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('event_organiser');

$pageTitle = 'Sponsor Search';
$activePage = 'sponsor-search';

$search = trim((string)($_GET['q'] ?? ''));
$businesses = [];
$errorMessage = '';

try {
    $sql = "
        SELECT id, name, email
        FROM users
        WHERE role = 'business_manager'
          AND is_active = 1
          AND (
              :q = ''
              OR name LIKE :name_q
              OR email LIKE :email_q
          )
        ORDER BY name ASC
        LIMIT 100
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        'q' => $search,
        'name_q' => '%' . $search . '%',
        'email_q' => '%' . $search . '%',
    ]);

    $businesses = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Sponsor Search Error: ' . $e->getMessage());
    $errorMessage = 'Unable to load businesses right now. Please try again.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>Search Sponsors</h1>

    <p>
        Find registered businesses that may be interested
        in sponsoring your events.
    </p>

    <form method="GET"
          action="<?= h(assetUrl('organiser/sponsor-search.php')) ?>"
          class="card"
          style="padding:16px;display:flex;gap:10px;flex-wrap:wrap;">

        <input
            type="search"
            name="q"
            value="<?= h($search) ?>"
            placeholder="Search by business name or email"
            aria-label="Search businesses"
            style="flex:1;min-width:200px;"
        >

        <button type="submit" class="btn btn-primary">
            Search
        </button>

        <?php if ($search !== ''): ?>
            <a href="<?= h(assetUrl('organiser/sponsor-search.php')) ?>"
               class="btn">
                Clear
            </a>
        <?php endif; ?>

    </form>

    <?php if ($errorMessage !== ''): ?>

        <div class="card" style="padding:16px;margin-top:20px;">
            <p><?= h($errorMessage) ?></p>
        </div>

    <?php else: ?>

        <h2 style="margin-top:24px;">
            Registered Businesses
            (<?= count($businesses) ?>)
        </h2>

        <div style="
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
            gap:16px;
            margin-top:20px;
        ">

            <?php foreach ($businesses as $business): ?>

                <article class="card" style="padding:20px;">

                    <h3><?= h($business['name']) ?></h3>

                    <p>
                        <strong>Email:</strong>
                        <?= h($business['email']) ?>
                    </p>

                    <a
                        href="<?= h(assetUrl('organiser/ai-sponsors.php')) ?>"
                        class="btn btn-primary"
                    >
                        View AI Recommendations
                    </a>

                </article>

            <?php endforeach; ?>

            <?php if (empty($businesses)): ?>

                <div class="card" style="padding:20px;">
                    <h3>No businesses found</h3>
                    <p>
                        Try another business name or email address.
                    </p>
                </div>

            <?php endif; ?>

        </div>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
