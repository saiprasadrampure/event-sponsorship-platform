
<?php

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';


// ========================================
// ORGANISER AUTHENTICATION
// ========================================

requireRole('event_organiser');

$user = currentUser();

$userId = (int) $user['id'];

$pageTitle = 'Event Details';
$activePage = 'my-events';


// ========================================
// VALIDATE EVENT ID
// ========================================

$eventId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$eventId || $eventId < 1) {

    http_response_code(400);

    exit('Valid event ID required.');
}


// ========================================
// FETCH EVENT DETAILS
// ========================================

try {

    $stmt = $pdo->prepare("
        SELECT
            id,
            user_id,
            title,
            event_type,
            event_date,
            location,
            description,
            sponsorship_amount,
            status,
            created_at

        FROM events

        WHERE id = :event_id
          AND user_id = :user_id

        LIMIT 1
    ");

    $stmt->execute([
        ':event_id' => $eventId,
        ':user_id' => $userId
    ]);

    $event = $stmt->fetch();

    if (!$event) {

        http_response_code(404);

        exit('Event not found.');
    }


    // ========================================
    // COUNT SPONSORSHIP APPLICATIONS
    // ========================================

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM sponsorship_applications
        WHERE event_id = :event_id
    ");

    $stmt->execute([
        ':event_id' => $eventId
    ]);

    $applicationCount = (int) $stmt->fetchColumn();


    // ========================================
    // COUNT APPLICATION STATUSES
    // ========================================

    $stmt = $pdo->prepare("
        SELECT
            status,
            COUNT(*) AS total

        FROM sponsorship_applications

        WHERE event_id = :event_id

        GROUP BY status
    ");

    $stmt->execute([
        ':event_id' => $eventId
    ]);

    $applicationStatuses = [
        'pending' => 0,
        'accepted' => 0,
        'rejected' => 0
    ];

    foreach ($stmt->fetchAll() as $row) {

        $status = (string) $row['status'];

        if (array_key_exists($status, $applicationStatuses)) {

            $applicationStatuses[$status] = (int) $row['total'];
        }
    }

} catch (PDOException $e) {

    error_log('Event details error: ' . $e->getMessage());

    http_response_code(500);

    exit('Unable to load event details. Please try again.');
}


// ========================================
// LOAD HEADER AND SIDEBAR
// ========================================

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';

?>

<section class="dashboard-container">


    <!-- PAGE HEADING -->

    <p>
        <a href="<?= h(assetUrl('organiser/my-events.php')) ?>">
            ← Back to My Events
        </a>
    </p>

    <h1><?= h($event['title']) ?></h1>

    <p>View your event information and sponsorship activity.</p>


    <!-- EVENT INFORMATION -->

    <article class="card"
             style="padding:24px; max-width:850px; margin-bottom:24px;">


        <h2>Event Information</h2>


        <p>
            <strong>Event ID:</strong>
            <?= (int) $event['id'] ?>
        </p>


        <p>
            <strong>Event Category:</strong>
            <?= h($event['event_type'] ?? 'Not specified') ?>
        </p>


        <p>
            <strong>Event Date:</strong>
            <?= h(formatDate($event['event_date'])) ?>
        </p>


        <p>
            <strong>Location:</strong>
            <?= h($event['location'] ?? 'Not specified') ?>
        </p>


        <p>
            <strong>Status:</strong>
            <?= h(ucfirst((string) $event['status'])) ?>
        </p>


        <p>
            <strong>Sponsorship Budget:</strong>

            <?php if (
                isset($event['sponsorship_amount']) &&
                $event['sponsorship_amount'] !== null
            ): ?>

                <?= h(formatINR($event['sponsorship_amount'])) ?>

            <?php else: ?>

                Not specified

            <?php endif; ?>

        </p>


        <h3>Description</h3>

        <p>
            <?= nl2br(h(
                $event['description'] ?? 'No description supplied.'
            )) ?>
        </p>


        <?php if (!empty($event['created_at'])): ?>

            <p>
                <strong>Created:</strong>
                <?= h(formatDate($event['created_at'])) ?>
            </p>

        <?php endif; ?>


    </article>


    <!-- SPONSORSHIP APPLICATION STATISTICS -->

    <h2>Sponsorship Overview</h2>

    <div style="
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
        gap:16px;
        margin-bottom:24px;
    ">


        <article class="card" style="padding:20px;">

            <h3>Total Applications</h3>

            <p style="font-size:28px;font-weight:bold;">
                <?= $applicationCount ?>
            </p>

        </article>


        <article class="card" style="padding:20px;">

            <h3>Pending</h3>

            <p style="font-size:28px;font-weight:bold;">
                <?= $applicationStatuses['pending'] ?>
            </p>

        </article>


        <article class="card" style="padding:20px;">

            <h3>Accepted</h3>

            <p style="font-size:28px;font-weight:bold;">
                <?= $applicationStatuses['accepted'] ?>
            </p>

        </article>


        <article class="card" style="padding:20px;">

            <h3>Rejected</h3>

            <p style="font-size:28px;font-weight:bold;">
                <?= $applicationStatuses['rejected'] ?>
            </p>

        </article>


    </div>


    <!-- ACTION BUTTONS -->

    <div style="display:flex;gap:12px;flex-wrap:wrap;">

        <a
            class="btn btn-primary"
            href="<?= h(assetUrl(
                'organiser/ai-sponsors.php?event_id=' . (int) $event['id']
            )) ?>"
        >
            Find Suitable Sponsors
        </a>


        <a
            class="btn btn-secondary"
            href="<?= h(assetUrl('organiser/sponsorship-applications.php')) ?>"
        >
            View Sponsorship Applications
        </a>


        <a
            class="btn btn-secondary"
            href="<?= h(assetUrl('organiser/my-events.php')) ?>"
        >
            Back to My Events
        </a>

    </div>


</section>


<?php require_once __DIR__ . '/../includes/footer.php'; ?>
