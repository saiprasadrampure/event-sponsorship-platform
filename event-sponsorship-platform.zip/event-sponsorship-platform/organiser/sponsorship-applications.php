
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('event_organiser');

$user = currentUser();

$pageTitle = 'Sponsorship Applications';
$activePage = 'sponsorship-applications';

$errors = [];
$success = '';


// Handle Accept / Reject actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrfToken = $_POST['csrf_token'] ?? null;

    if (!verifyCsrfToken($csrfToken)) {

        $errors[] = 'Invalid or expired security token. Please refresh the page and try again.';

    } else {

        $applicationId = filter_input(
            INPUT_POST,
            'application_id',
            FILTER_VALIDATE_INT
        );

        $newStatus = (string) ($_POST['status'] ?? '');

        if (
            !$applicationId ||
            !in_array($newStatus, ['accepted', 'rejected'], true)
        ) {

            $errors[] = 'Invalid application action.';

        } else {

            try {

                $stmt = $pdo->prepare("
                    UPDATE sponsorship_applications sa
                    INNER JOIN events e ON e.id = sa.event_id
                    SET sa.status = :status
                    WHERE sa.id = :application_id
                      AND e.user_id = :user_id
                      AND sa.status = 'pending'
                ");

                $stmt->execute([
                    ':status' => $newStatus,
                    ':application_id' => $applicationId,
                    ':user_id' => (int) $user['id']
                ]);

                if ($stmt->rowCount() > 0) {

                    $success = 'Application status updated successfully.';

                } else {

                    $errors[] = 'Application not found, already processed, or not yours to manage.';
                }

            } catch (PDOException $e) {

                error_log('Application status update error: ' . $e->getMessage());

                $errors[] = 'Unable to update the application. Please try again.';
            }
        }
    }
}


// Fetch applications belonging to this organiser
$applications = [];

try {

    $stmt = $pdo->prepare("
        SELECT
            sa.id,
            sa.status,
            e.id AS event_id,
            e.title AS event_title,
            u.name AS business_name,
            u.email AS business_email

        FROM sponsorship_applications sa

        INNER JOIN events e
            ON e.id = sa.event_id

        INNER JOIN users u
            ON u.id = sa.business_manager_id

        WHERE e.user_id = :user_id

        ORDER BY sa.id DESC

        LIMIT 100
    ");

    $stmt->execute([
        ':user_id' => (int) $user['id']
    ]);

    $applications = $stmt->fetchAll();

} catch (PDOException $e) {

    error_log('Fetch sponsorship applications error: ' . $e->getMessage());

    $errors[] = 'Unable to load sponsorship applications.';
}


require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>Sponsorship Applications</h1>

    <p>Review businesses interested in supporting your events.</p>


    <?php if ($success): ?>

        <p class="alert alert-success">
            <?= h($success) ?>
        </p>

    <?php endif; ?>


    <?php if (!empty($errors)): ?>

        <div class="alert alert-error">

            <?php foreach ($errors as $error): ?>

                <p><?= h($error) ?></p>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>


    <div style="display:grid; gap:16px;">

        <?php if (!empty($applications)): ?>

            <?php foreach ($applications as $app): ?>

                <article class="card" style="padding:20px;">

                    <h2><?= h($app['event_title']) ?></h2>

                    <p>
                        <strong>Business:</strong>
                        <?= h($app['business_name']) ?>
                    </p>

                    <p>
                        <strong>Email:</strong>
                        <?= h($app['business_email']) ?>
                    </p>

                    <p>
                        <strong>Status:</strong>
                        <?= h(ucfirst($app['status'])) ?>
                    </p>


                    <?php if ($app['status'] === 'pending'): ?>

                        <form method="POST"
                              action="<?= h(assetUrl('organiser/sponsorship-applications.php')) ?>"
                              style="display:flex; gap:10px; flex-wrap:wrap;">

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= h(csrfToken()) ?>"
                            >

                            <input
                                type="hidden"
                                name="application_id"
                                value="<?= (int) $app['id'] ?>"
                            >

                            <button
                                class="btn btn-primary"
                                name="status"
                                value="accepted"
                                type="submit"
                            >
                                Accept
                            </button>

                            <button
                                class="btn btn-secondary"
                                name="status"
                                value="rejected"
                                type="submit"
                            >
                                Reject
                            </button>

                        </form>

                    <?php endif; ?>

                </article>

            <?php endforeach; ?>

        <?php else: ?>

            <p>No sponsorship applications yet.</p>

        <?php endif; ?>

    </div>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
