
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('event_organiser');

$user = currentUser();

$pageTitle = 'AI Sponsor Recommendations';
$activePage = 'ai-sponsors';

$eventId = filter_input(INPUT_GET, 'event_id', FILTER_VALIDATE_INT);

$event = null;
$events = [];
$businesses = [];
$recommendations = [];
$errorMessage = '';

try {

    // If an event ID is provided, verify that it belongs to this organiser.
    if ($eventId !== null && $eventId !== false && $eventId > 0) {

        $stmt = $pdo->prepare("
            SELECT id, user_id, title, event_type, event_date,
                   location, description, sponsorship_amount, status
            FROM events
            WHERE id = :event_id AND user_id = :user_id
            LIMIT 1
        ");

        $stmt->execute([
            ':event_id' => $eventId,
            ':user_id' => (int) $user['id']
        ]);

        $event = $stmt->fetch();

        if (!$event) {
            http_response_code(404);
            exit('Event not found.');
        }

    } else {

        // Fetch events belonging to the logged-in organiser.
        $stmt = $pdo->prepare("
            SELECT id, title, event_type, event_date, location
            FROM events
            WHERE user_id = :user_id
            ORDER BY event_date DESC, id DESC
            LIMIT 20
        ");

        $stmt->execute([
            ':user_id' => (int) $user['id']
        ]);

        $events = $stmt->fetchAll();
    }

    // Generate starter sponsor recommendations.
    if ($event) {

        $stmt = $pdo->prepare("
            SELECT id, name, email
            FROM users
            WHERE role = 'business_manager'
              AND is_active = 1
            ORDER BY name ASC
            LIMIT 100
        ");

        $stmt->execute();

        $businesses = $stmt->fetchAll();

        foreach ($businesses as $business) {

            // Prototype matching score.
            // Actual AI matching will be connected later.
            $score = 1;

            $recommendations[] = [
                'id' => (int) $business['id'],
                'name' => $business['name'],
                'email' => $business['email'],
                'score' => $score,
                'reasons' => [
                    'Registered business account'
                ]
            ];
        }
    }

} catch (PDOException $e) {

    error_log('Sponsor recommendations error: ' . $e->getMessage());

    $errorMessage = 'Unable to generate recommendations. Please check your database configuration and try again.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>AI Sponsor Recommendations</h1>

    <p>Find potential business sponsors for your events.</p>

    <?php if ($errorMessage): ?>

        <p class="alert alert-error">
            <?= h($errorMessage) ?>
        </p>

    <?php endif; ?>


    <?php if (!$event): ?>

        <h2>Choose an Event</h2>

        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:16px;">

            <?php if (!empty($events)): ?>

                <?php foreach ($events as $item): ?>

                    <article class="card" style="padding:20px;">

                        <h3><?= h($item['title']) ?></h3>

                        <p>
                            <?= h($item['event_type']) ?>
                            ·
                            <?= h(formatDate($item['event_date'])) ?>
                        </p>

                        <p>
                            <strong>Location:</strong>
                            <?= h($item['location']) ?>
                        </p>

                        <a class="btn btn-primary"
                           href="<?= h(assetUrl('organiser/ai-sponsors.php?event_id=' . (int) $item['id'])) ?>">
                            Find Sponsors
                        </a>

                    </article>

                <?php endforeach; ?>

            <?php else: ?>

                <p>You have not created any events yet.</p>

                <a class="btn btn-primary"
                   href="<?= h(assetUrl('organiser/create-event.php')) ?>">
                    + Create Event
                </a>

            <?php endif; ?>

        </div>


    <?php else: ?>

        <div class="card" style="padding:20px; margin:20px 0;">

            <h2><?= h($event['title']) ?></h2>

            <p>
                <strong>Event Type:</strong>
                <?= h($event['event_type']) ?>
            </p>

            <p>
                <strong>Event Date:</strong>
                <?= h(formatDate($event['event_date'])) ?>
            </p>

            <p>
                <strong>Location:</strong>
                <?= h($event['location'] ?? '') ?>
            </p>

            <p>
                These are starter suggestions based on registered business accounts.
                Category, location, sponsorship budget and business preferences
                can be used to improve matching when the AI engine is connected.
            </p>

            <a class="btn btn-secondary"
               href="<?= h(assetUrl('organiser/ai-sponsors.php')) ?>">
                Choose Another Event
            </a>

        </div>


        <h2>Potential Sponsors</h2>

        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:16px;">

            <?php if (!empty($recommendations)): ?>

                <?php foreach ($recommendations as $business): ?>

                    <article class="card" style="padding:20px;">

                        <h3><?= h($business['name']) ?></h3>

                        <p>
                            <strong>Email:</strong>
                            <?= h($business['email']) ?>
                        </p>

                        <p>
                            <strong>Match Score:</strong>
                            <?= (int) $business['score'] ?>/100
                            <span>(Prototype)</span>
                        </p>

                        <p>
                            Potential sponsor identified from registered business accounts.
                        </p>

                        <ul>
                            <?php foreach ($business['reasons'] as $reason): ?>
                                <li><?= h($reason) ?></li>
                            <?php endforeach; ?>
                        </ul>

                    </article>

                <?php endforeach; ?>

            <?php else: ?>

                <p>No active business accounts found.</p>

            <?php endif; ?>

        </div>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
