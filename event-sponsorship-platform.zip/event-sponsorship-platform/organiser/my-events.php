
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('event_organiser');

$user = currentUser();

$pageTitle = 'My Events';
$activePage = 'my-events';

// Fetch events created by the logged-in organiser
$stmt = $pdo->prepare("
    SELECT id, title, event_type, event_date, location, status
    FROM events
    WHERE user_id = :user_id
    ORDER BY event_date DESC, id DESC
");

$stmt->execute([
    ':user_id' => (int) $user['id']
]);

$events = $stmt->fetchAll();

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>My Events</h1>
    <p>Manage the events you have submitted.</p>

    <p>
        <a class="btn btn-primary"
           href="<?= h(assetUrl('organiser/create-event.php')) ?>">
            + Create Event
        </a>
    </p>

    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:18px;">

        <?php if (!empty($events)): ?>

            <?php foreach ($events as $event): ?>

                <article class="card" style="padding:20px;">

                    <span class="role-badge">
                        <?= h($event['event_type']) ?>
                    </span>

                    <h2><?= h($event['title']) ?></h2>

                    <p>
                        <strong>Date:</strong>
                        <?= h(formatDate($event['event_date'])) ?>
                    </p>

                    <p>
                        <strong>Location:</strong>
                        <?= h($event['location']) ?>
                    </p>

                    <p>
                        <strong>Status:</strong>
                        <?= h(ucfirst($event['status'])) ?>
                    </p>

                    <a class="btn btn-secondary"
                       href="<?= h(assetUrl('organiser/event-details.php?id=' . (int) $event['id'])) ?>">
                        View Details
                    </a>

                </article>

            <?php endforeach; ?>

        <?php else: ?>

            <p>You have not created any events yet.</p>

        <?php endif; ?>

    </div>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
