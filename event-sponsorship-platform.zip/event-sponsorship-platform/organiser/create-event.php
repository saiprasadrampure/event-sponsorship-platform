
<?php

// ========================================
// DATABASE, AUTHENTICATION AND FUNCTIONS
// ========================================

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';


// ========================================
// ORGANISER ACCESS
// ========================================

requireRole('event_organiser');

$user = currentUser();

$pageTitle = 'Create Event';
$activePage = 'create-event';


// ========================================
// INITIALIZE FORM DATA
// ========================================

$errors = [];
$success = '';

$types = [
    'Wedding',
    'Birthday',
    'Corporate',
    'Education',
    'Sports',
    'Music',
    'Cultural',
    'Charity',
    'Technology',
    'Other'
];

$title = '';
$type = '';
$date = '';
$location = '';
$description = '';
$sponsorshipAmount = '';


// ========================================
// FORM SUBMISSION
// ========================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Validate CSRF token
    $token = $_POST['csrf_token'] ?? null;

    if (!verifyCsrfToken(is_string($token) ? $token : null)) {

        $errors[] = 'Invalid request. Please refresh the page and try again.';

    } else {

        // Collect form data
        $title = trim((string) ($_POST['title'] ?? ''));

        $type = trim((string) ($_POST['event_type'] ?? ''));

        $date = trim((string) ($_POST['event_date'] ?? ''));

        $location = trim((string) ($_POST['location'] ?? ''));

        $description = trim((string) ($_POST['description'] ?? ''));

        $sponsorshipAmount = trim(
            (string) ($_POST['sponsorship_amount'] ?? '')
        );


        // ========================================
        // VALIDATE EVENT TITLE
        // ========================================

        $titleLength = function_exists('mb_strlen')
            ? mb_strlen($title, 'UTF-8')
            : strlen($title);

        if ($title === '' || $titleLength > 180) {

            $errors[] = 'Enter an event title (maximum 180 characters).';
        }


        // ========================================
        // VALIDATE EVENT TYPE
        // ========================================

        if (!in_array($type, $types, true)) {

            $errors[] = 'Select a valid event type.';
        }


        // ========================================
        // VALIDATE EVENT DATE
        // ========================================

        $dateObj = DateTimeImmutable::createFromFormat(
            '!Y-m-d',
            $date
        );

        if (
            !$dateObj ||
            $dateObj->format('Y-m-d') !== $date
        ) {

            $errors[] = 'Select a valid event date.';
        }


        // ========================================
        // VALIDATE LOCATION
        // ========================================

        $locationLength = function_exists('mb_strlen')
            ? mb_strlen($location, 'UTF-8')
            : strlen($location);

        if ($location === '' || $locationLength > 180) {

            $errors[] = 'Enter a location (maximum 180 characters).';
        }


        // ========================================
        // VALIDATE DESCRIPTION
        // ========================================

        $descriptionLength = function_exists('mb_strlen')
            ? mb_strlen($description, 'UTF-8')
            : strlen($description);

        if (
            $description === '' ||
            $descriptionLength > 5000
        ) {

            $errors[] = 'Description is required and must be under 5,000 characters.';
        }


        // ========================================
        // VALIDATE SPONSORSHIP AMOUNT
        // ========================================

        $amount = null;

        if ($sponsorshipAmount !== '') {

            if (
                !is_numeric($sponsorshipAmount) ||
                !is_finite((float) $sponsorshipAmount) ||
                (float) $sponsorshipAmount < 0 ||
                (float) $sponsorshipAmount > 1000000000
            ) {

                $errors[] = 'Enter a valid sponsorship amount.';

            } else {

                $amount = (float) $sponsorshipAmount;
            }
        }


        // ========================================
        // SAVE EVENT TO DATABASE
        // ========================================

        if (empty($errors)) {

            try {

                $stmt = $pdo->prepare("
                    INSERT INTO events (
                        user_id,
                        title,
                        event_type,
                        event_date,
                        location,
                        description,
                        sponsorship_amount,
                        status
                    )
                    VALUES (
                        :user_id,
                        :title,
                        :event_type,
                        :event_date,
                        :location,
                        :description,
                        :sponsorship_amount,
                        'draft'
                    )
                ");

                $stmt->execute([

                    'user_id' => (int) $user['id'],

                    'title' => $title,

                    'event_type' => $type,

                    'event_date' => $date,

                    'location' => $location,

                    'description' => $description,

                    'sponsorship_amount' => $amount

                ]);


                // Success message
                $success = 'Event saved successfully as a draft. Review it in My Events.';


                // Clear form after successful submission
                $title = '';
                $type = '';
                $date = '';
                $location = '';
                $description = '';
                $sponsorshipAmount = '';


            } catch (PDOException $e) {

                error_log(
                    'EventConnect Create Event Error: ' .
                    $e->getMessage()
                );

                $errors[] = 'Event could not be saved. Please check your events table structure.';
            }
        }
    }
}


// ========================================
// LOAD HEADER AND SIDEBAR
// ========================================

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';

?>


<!-- ========================================
     CREATE EVENT PAGE
========================================= -->

<section class="dashboard-container">

    <h1>Create an Event</h1>

    <p>
        Provide event details so suitable sponsors can discover your opportunity.
    </p>


    <!-- ========================================
         EVENT FORM CARD
    ========================================= -->

    <div class="card" style="
        max-width:850px;
        padding:24px;
    ">


        <!-- SUCCESS MESSAGE -->

        <?php if ($success !== ''): ?>

            <p class="alert alert-success">
                <?= h($success) ?>
            </p>

        <?php endif; ?>


        <!-- ERROR MESSAGES -->

        <?php if (!empty($errors)): ?>

            <div class="alert alert-error">

                <?php foreach ($errors as $error): ?>

                    <p>
                        <?= h($error) ?>
                    </p>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <!-- ========================================
             EVENT CREATION FORM
        ========================================= -->

        <form method="post" action="">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h(csrfToken()) ?>"
            >


            <!-- EVENT TITLE -->

            <div class="form-group">

                <label for="title">
                    Event Title
                </label>

                <input
                    id="title"
                    type="text"
                    name="title"
                    maxlength="180"
                    placeholder="Enter your event title"
                    value="<?= h($title) ?>"
                    required
                >

            </div>


            <!-- EVENT TYPE -->

            <div class="form-group">

                <label for="event_type">
                    Event Type
                </label>

                <select
                    id="event_type"
                    name="event_type"
                    required
                >

                    <option value="">
                        Choose a category
                    </option>

                    <?php foreach ($types as $t): ?>

                        <option
                            value="<?= h($t) ?>"
                            <?= $type === $t ? 'selected' : '' ?>
                        >
                            <?= h($t) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <!-- EVENT DATE -->

            <div class="form-group">

                <label for="event_date">
                    Event Date
                </label>

                <input
                    id="event_date"
                    type="date"
                    name="event_date"
                    value="<?= h($date) ?>"
                    required
                >

            </div>


            <!-- EVENT LOCATION -->

            <div class="form-group">

                <label for="location">
                    Event Location
                </label>

                <input
                    id="location"
                    type="text"
                    name="location"
                    maxlength="180"
                    placeholder="Enter event location"
                    value="<?= h($location) ?>"
                    required
                >

            </div>


            <!-- SPONSORSHIP AMOUNT -->

            <div class="form-group">

                <label for="sponsorship_amount">
                    Requested Sponsorship Amount (₹)
                </label>

                <input
                    id="sponsorship_amount"
                    type="number"
                    name="sponsorship_amount"
                    min="0"
                    max="1000000000"
                    step="0.01"
                    placeholder="Enter required sponsorship amount"
                    value="<?= h($sponsorshipAmount) ?>"
                >

                <small>
                    Enter the total sponsorship funding required for your event.
                </small>

            </div>


            <!-- EVENT DESCRIPTION -->

            <div class="form-group">

                <label for="description">
                    Event Description and Sponsorship Needs
                </label>

                <textarea
                    id="description"
                    name="description"
                    rows="6"
                    maxlength="5000"
                    placeholder="Describe your event, audience, expected visitors and sponsorship requirements..."
                    required
                ><?= h($description) ?></textarea>

            </div>


            <!-- SUBMIT BUTTON -->

            <button
                class="btn btn-primary"
                type="submit"
            >
                Save Event Draft
            </button>


        </form>

    </div>

</section>


<?php

// ========================================
// PAGE FOOTER
// ========================================

require_once __DIR__ . '/../includes/footer.php';

?>
