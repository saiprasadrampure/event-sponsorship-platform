
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('event_organiser');

$user = currentUser();
$pageTitle = 'Organiser Posts';

$uploadDir = __DIR__ . '/../uploads/organiser-posts/';
$uploadUrl = 'uploads/organiser-posts/';

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

$message = '';
$messageType = 'success';

function removeOrganiserMediaFile(string $path): void
{
    $prefix = 'uploads/organiser-posts/';

    if (strpos($path, $prefix) !== 0) {
        return;
    }

    $file = dirname(__DIR__) . '/' . $path;

    if (is_file($file)) {
        unlink($file);
    }
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        if (!verifyCsrfToken($_POST['csrf_token'] ?? null)) {
            throw new RuntimeException('Invalid security token. Refresh the page.');
        }

        $action = $_POST['action'] ?? '';

        // CREATE OR UPDATE POST
        if ($action === 'save') {
            $postId = (int)($_POST['post_id'] ?? 0);
            $title = trim($_POST['title'] ?? '');
            $content = trim($_POST['content'] ?? '');
            $eventId = !empty($_POST['event_id'])
                ? (int)$_POST['event_id']
                : null;

            if ($title === '' || $content === '') {
                throw new RuntimeException('Please enter a title and post content.');
            }

            if (mb_strlen($title) > 200) {
                throw new RuntimeException('Title cannot exceed 200 characters.');
            }

            if ($eventId !== null) {
                $eventCheck = $pdo->prepare("
                    SELECT id FROM events
                    WHERE id = ? AND user_id = ?
                ");
                $eventCheck->execute([$eventId, $user['id']]);

                if (!$eventCheck->fetch()) {
                    throw new RuntimeException('Invalid event selected.');
                }
            }

            if ($postId > 0) {
                $check = $pdo->prepare("
                    SELECT id FROM organiser_posts
                    WHERE id = ? AND user_id = ?
                ");
                $check->execute([$postId, $user['id']]);

                if (!$check->fetch()) {
                    throw new RuntimeException('Post not found or access denied.');
                }

                $stmt = $pdo->prepare("
                    UPDATE organiser_posts
                    SET title = ?, content = ?, event_id = ?
                    WHERE id = ? AND user_id = ?
                ");

                $stmt->execute([
                    $title, $content, $eventId,
                    $postId, $user['id']
                ]);

            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO organiser_posts
                    (user_id, event_id, title, content, status)
                    VALUES (?, ?, ?, ?, 'published')
                ");

                $stmt->execute([
                    $user['id'], $eventId, $title, $content
                ]);

                $postId = (int)$pdo->lastInsertId();
            }

            // Upload multiple photos/videos.
            if (!empty($_FILES['media']['name'][0])) {

                $allowed = [
                    'image/jpeg' => ['jpg', 'jpeg'],
                    'image/png' => ['png'],
                    'image/webp' => ['webp'],
                    'image/gif' => ['gif'],
                    'video/mp4' => ['mp4'],
                    'video/webm' => ['webm']
                ];

                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $total = count($_FILES['media']['name']);

                if ($total > 10) {
                    throw new RuntimeException('Maximum 10 files per upload.');
                }

                for ($i = 0; $i < $total; $i++) {
                    if ($_FILES['media']['error'][$i] === UPLOAD_ERR_NO_FILE) {
                        continue;
                    }

                    if ($_FILES['media']['error'][$i] !== UPLOAD_ERR_OK) {
                        throw new RuntimeException('A file could not be uploaded.');
                    }

                    $tmp = $_FILES['media']['tmp_name'][$i];
                    $size = (int)$_FILES['media']['size'][$i];
                    $originalName = $_FILES['media']['name'][$i];

                    if ($size <= 0 || $size > 50 * 1024 * 1024) {
                        throw new RuntimeException('Each file must be smaller than 50 MB.');
                    }

                    $mime = $finfo->file($tmp);
                    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

                    if (!isset($allowed[$mime]) ||
                        !in_array($extension, $allowed[$mime], true)) {
                        throw new RuntimeException('Unsupported photo or video format.');
                    }

                    // Additional image integrity check.
                    if (strpos($mime, 'image/') === 0 && !getimagesize($tmp)) {
                        throw new RuntimeException('Invalid image file.');
                    }

                    $type = strpos($mime, 'image/') === 0 ? 'image' : 'video';
                    $filename = bin2hex(random_bytes(16)) . '.' . $extension;
                    $destination = $uploadDir . $filename;

                    if (!move_uploaded_file($tmp, $destination)) {
                        throw new RuntimeException('Could not save uploaded file.');
                    }

                    $relativePath = $uploadUrl . $filename;

                    try {
                        $mediaStmt = $pdo->prepare("
                            INSERT INTO organiser_post_media
                            (post_id, media_type, media_path)
                            VALUES (?, ?, ?)
                        ");

                        $mediaStmt->execute([
                            $postId, $type, $relativePath
                        ]);
                    } catch (Throwable $e) {
                        removeOrganiserMediaFile($relativePath);
                        throw $e;
                    }
                }
            }

            $message = 'Your post has been saved successfully.';
        }

        // DELETE POST
        elseif ($action === 'delete') {
            $postId = (int)($_POST['post_id'] ?? 0);

            $check = $pdo->prepare("
                SELECT id FROM organiser_posts
                WHERE id = ? AND user_id = ?
            ");
            $check->execute([$postId, $user['id']]);

            if (!$check->fetch()) {
                throw new RuntimeException('Post not found or access denied.');
            }

            $mediaStmt = $pdo->prepare("
                SELECT media_path FROM organiser_post_media
                WHERE post_id = ?
            ");
            $mediaStmt->execute([$postId]);
            $files = $mediaStmt->fetchAll(PDO::FETCH_COLUMN);

            $delete = $pdo->prepare("
                DELETE FROM organiser_posts
                WHERE id = ? AND user_id = ?
            ");
            $delete->execute([$postId, $user['id']]);

            foreach ($files as $file) {
                removeOrganiserMediaFile($file);
            }

            $message = 'Post deleted successfully.';
        }

        // DELETE ONE MEDIA FILE
        elseif ($action === 'delete_media') {
            $mediaId = (int)($_POST['media_id'] ?? 0);

            $stmt = $pdo->prepare("
                SELECT m.id, m.media_path
                FROM organiser_post_media m
                INNER JOIN organiser_posts p ON p.id = m.post_id
                WHERE m.id = ? AND p.user_id = ?
            ");

            $stmt->execute([$mediaId, $user['id']]);
            $media = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$media) {
                throw new RuntimeException('Media not found or access denied.');
            }

            $delete = $pdo->prepare("
                DELETE FROM organiser_post_media WHERE id = ?
            ");
            $delete->execute([$mediaId]);

            removeOrganiserMediaFile($media['media_path']);

            $message = 'Media deleted successfully.';
        }

        // HIDE OR PUBLISH POST
        elseif ($action === 'toggle_status') {
            $postId = (int)($_POST['post_id'] ?? 0);

            $stmt = $pdo->prepare("
                UPDATE organiser_posts
                SET status = CASE
                    WHEN status = 'published' THEN 'hidden'
                    ELSE 'published'
                END
                WHERE id = ? AND user_id = ?
            ");

            $stmt->execute([$postId, $user['id']]);

            if (!$stmt->rowCount()) {
                throw new RuntimeException('Post not found or status unchanged.');
            }

            $message = 'Post visibility updated.';
        }
    }

} catch (Throwable $e) {
    error_log('Organiser posts error: ' . $e->getMessage());
    $message = $e instanceof RuntimeException
        ? $e->getMessage()
        : 'Unable to process your post. Please check the server error log.';
    $messageType = 'error';
}

// Load post for editing.
$editPost = null;

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("
        SELECT * FROM organiser_posts
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([(int)$_GET['edit'], $user['id']]);
    $editPost = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Load organiser's events for optional post linking.
$eventsStmt = $pdo->prepare("
    SELECT id, title FROM events
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$eventsStmt->execute([$user['id']]);
$myEvents = $eventsStmt->fetchAll(PDO::FETCH_ASSOC);

// Load organiser posts.
$postsStmt = $pdo->prepare("
    SELECT p.*, e.title AS event_title
    FROM organiser_posts p
    LEFT JOIN events e ON e.id = p.event_id
    WHERE p.user_id = ?
    ORDER BY p.created_at DESC
");
$postsStmt->execute([$user['id']]);
$posts = $postsStmt->fetchAll(PDO::FETCH_ASSOC);

// Load media for all posts.
$mediaByPost = [];

if ($posts) {
    $ids = array_column($posts, 'id');
    $placeholders = implode(',', array_fill(0, count($ids), '?'));

    $mediaStmt = $pdo->prepare("
        SELECT * FROM organiser_post_media
        WHERE post_id IN ($placeholders)
        ORDER BY created_at ASC
    ");

    $mediaStmt->execute($ids);

    foreach ($mediaStmt->fetchAll(PDO::FETCH_ASSOC) as $media) {
        $mediaByPost[$media['post_id']][] = $media;
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-section">

    <div class="page-heading">
        <h1>Organiser Posts</h1>
        <p>Share announcements, event updates, photos and videos.</p>
    </div>

    <?php if ($message): ?>
        <div class="alert <?= $messageType === 'success' ? 'alert-success' : 'alert-danger' ?>">
            <?= h($message) ?>
        </div>
    <?php endif; ?>

    <div class="content-card">
        <h2><?= $editPost ? 'Edit Post' : 'Create New Post' ?></h2>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="post_id"
                   value="<?= (int)($editPost['id'] ?? 0) ?>">

            <label>Post Title</label>
            <input type="text" name="title" maxlength="200"
                   value="<?= h($editPost['title'] ?? '') ?>"
                   placeholder="Enter post title" required>

            <label>Post Description</label>
            <textarea name="content" rows="5"
                      placeholder="Write your announcement or event update..."
                      required><?= h($editPost['content'] ?? '') ?></textarea>

            <label>Link to Event (Optional)</label>
            <select name="event_id">
                <option value="">No event selected</option>
                <?php foreach ($myEvents as $event): ?>
                    <option value="<?= (int)$event['id'] ?>"
                        <?= isset($editPost['event_id']) &&
                            (int)$editPost['event_id'] === (int)$event['id']
                            ? 'selected' : '' ?>>
                        <?= h($event['title']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Upload Photos and Videos</label>
            <input type="file" name="media[]" multiple
                   accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm">

            <small>
                Maximum 10 files per upload, 50 MB per file.
                Supported: JPG, PNG, WEBP, GIF, MP4 and WEBM.
            </small>

            <br><br>

            <button type="submit" class="btn btn-primary">
                <?= $editPost ? 'Update Post' : 'Publish Post' ?>
            </button>

            <?php if ($editPost): ?>
                <a href="<?= h(assetUrl('organiser/posts.php')) ?>"
                   class="btn btn-secondary">Cancel Edit</a>
            <?php endif; ?>
        </form>
    </div>

    <h2>My Posts</h2>

    <?php if (!$posts): ?>
        <div class="content-card">
            <p>You haven't created any posts yet.</p>
        </div>
    <?php endif; ?>

    <?php foreach ($posts as $post): ?>
        <div class="content-card" style="margin-bottom:20px;">

            <h3><?= h($post['title']) ?></h3>

            <p><?= nl2br(h($post['content'])) ?></p>

            <?php if ($post['event_title']): ?>
                <p><strong>Related Event:</strong>
                    <?= h($post['event_title']) ?>
                </p>
            <?php endif; ?>

            <p>
                <small>
                    <?= h(formatDate($post['created_at'])) ?>
                    · <?= h(ucfirst($post['status'])) ?>
                </small>
            </p>

            <?php if (!empty($post['image_url'])): ?>
                <img
                    src="<?= h(assetUrl($post['image_url'])) ?>"
                    alt="Post image"
                    style="max-width:100%;height:auto;border-radius:10px;">
            <?php endif; ?>

            <?php foreach ($mediaByPost[$post['id']] ?? [] as $media): ?>
                <div style="margin:12px 0;">

                    <?php if ($media['media_type'] === 'image'): ?>
                        <img
                            src="<?= h(assetUrl($media['media_path'])) ?>"
                            alt="<?= h($post['title']) ?>"
                            style="max-width:100%;max-height:350px;border-radius:10px;">
                    <?php else: ?>
                        <video controls preload="metadata"
                               style="width:100%;max-height:400px;">
                            <source
                                src="<?= h(assetUrl($media['media_path'])) ?>">
                            Your browser does not support video playback.
                        </video>
                    <?php endif; ?>

                    <form method="POST" style="margin-top:5px;"
                          onsubmit="return confirm('Delete this media file?');">
                        <input type="hidden" name="csrf_token"
                               value="<?= h(csrfToken()) ?>">
                        <input type="hidden" name="action" value="delete_media">
                        <input type="hidden" name="media_id"
                               value="<?= (int)$media['id'] ?>">
                        <button type="submit" class="btn btn-sm btn-danger">
                            Delete Media
                        </button>
                    </form>
                </div>
            <?php endforeach; ?>

            <hr>

            <a class="btn btn-primary"
               href="<?= h(assetUrl('organiser/posts.php?edit=' . (int)$post['id'])) ?>">
                Edit Post
            </a>

            <form method="POST" style="display:inline;"
                  onsubmit="return confirm('Delete this post and its media?');">
                <input type="hidden" name="csrf_token"
                       value="<?= h(csrfToken()) ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="post_id"
                       value="<?= (int)$post['id'] ?>">
                <button type="submit" class="btn btn-danger">
                    Delete Post
                </button>
            </form>

            <form method="POST" style="display:inline;">
                <input type="hidden" name="csrf_token"
                       value="<?= h(csrfToken()) ?>">
                <input type="hidden" name="action" value="toggle_status">
                <input type="hidden" name="post_id"
                       value="<?= (int)$post['id'] ?>">
                <button type="submit" class="btn btn-secondary">
                    <?= $post['status'] === 'published' ? 'Hide Post' : 'Publish Post' ?>
                </button>
            </form>

        </div>
    <?php endforeach; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
<style>
/* Organiser Posts page only */
#organiser-posts-page {
    max-width: 1150px;
    margin: 0 auto;
    padding: 30px 24px 55px;
    color: var(--text-color, #172033);
}

#organiser-posts-page .page-heading {
    margin-bottom: 28px;
}

#organiser-posts-page .page-heading h1 {
    font-size: 30px;
    font-weight: 800;
    margin-bottom: 8px;
}

#organiser-posts-page .page-heading p {
    color: #778197;
}

#organiser-posts-page .content-card {
    background: var(--card-bg, #fff);
    border: 1px solid var(--border-color, #e6eaf1);
    border-radius: 18px;
    padding: 26px;
    margin-bottom: 25px;
    box-shadow: 0 8px 28px rgba(25, 35, 55, .055);
}

#organiser-posts-page .content-card h2,
#organiser-posts-page .content-card h3 {
    margin-top: 0;
    font-weight: 750;
}

#organiser-posts-page form label {
    display: block;
    font-size: 14px;
    font-weight: 650;
    margin: 18px 0 8px;
}

#organiser-posts-page input[type="text"],
#organiser-posts-page textarea,
#organiser-posts-page select {
    display: block;
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
    padding: 13px 15px;
    border: 1px solid #dce1eb;
    border-radius: 10px;
    background: var(--input-bg, #fff);
    color: var(--text-color, #172033);
    font: inherit;
    outline: none;
    transition: border-color .2s, box-shadow .2s;
}

#organiser-posts-page input:focus,
#organiser-posts-page textarea:focus,
#organiser-posts-page select:focus {
    border-color: #6858e8;
    box-shadow: 0 0 0 3px rgba(104, 88, 232, .12);
}

#organiser-posts-page textarea {
    min-height: 135px;
    resize: vertical;
}

#organiser-posts-page input[type="file"] {
    display: block;
    width: 100%;
    box-sizing: border-box;
    padding: 15px;
    border: 1px dashed #a9a2e9;
    border-radius: 12px;
    background: #f8f7ff;
    margin-top: 8px;
}

#organiser-posts-page small {
    display: block;
    color: #778197;
    margin-top: 8px;
    line-height: 1.6;
}

#organiser-posts-page .btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 11px 19px;
    border: 0;
    border-radius: 9px;
    font-weight: 650;
    text-decoration: none;
    cursor: pointer;
    margin: 5px 5px 5px 0;
    transition: transform .2s, opacity .2s;
}

#organiser-posts-page .btn:hover {
    transform: translateY(-2px);
    opacity: .9;
}

#organiser-posts-page .btn-primary {
    background: #6658e8;
    color: #fff;
}

#organiser-posts-page .btn-secondary {
    background: #edf0f7;
    color: #344054;
}

#organiser-posts-page .btn-danger {
    background: #fee4e2;
    color: #b42318;
}

#organiser-posts-page .btn-sm {
    padding: 8px 12px;
    font-size: 12px;
}

#organiser-posts-page > h2 {
    font-size: 23px;
    margin: 32px 0 18px;
}

#organiser-posts-page .content-card img {
    display: block;
    width: auto;
    max-width: 100%;
    max-height: 380px;
    object-fit: cover;
    border-radius: 12px;
    margin: 14px 0;
}

#organiser-posts-page video {
    display: block;
    width: 100%;
    max-height: 420px;
    border-radius: 12px;
    background: #111;
}

#organiser-posts-page .alert {
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
}

#organiser-posts-page .alert-success {
    background: #dcfce7;
    color: #166534;
}

#organiser-posts-page .alert-danger {
    background: #fee2e2;
    color: #991b1b;
}

#organiser-posts-page hr {
    border: 0;
    border-top: 1px solid #e8eaf0;
    margin: 22px 0;
}

@media (max-width: 650px) {
    #organiser-posts-page {
        padding: 20px 12px 40px;
    }

    #organiser-posts-page .content-card {
        padding: 17px;
    }

    #organiser-posts-page .page-heading h1 {
        font-size: 25px;
    }

    #organiser-posts-page .btn {
        margin-bottom: 8px;
    }
}
</style>

<section class="dashboard-section" id="organiser-posts-page">