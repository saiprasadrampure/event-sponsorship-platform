
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

adminPostGuard();
$error = '';

$allowedStatuses = ['draft', 'published', 'rejected', 'completed'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $eventId = filter_input(INPUT_POST, 'event_id', FILTER_VALIDATE_INT);
    $status = $_POST['status'] ?? '';

    if (!$eventId || !in_array($status, $allowedStatuses, true)) {
        $error = 'Invalid event moderation request.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'UPDATE events SET status = ? WHERE id = ?'
            );
            $stmt->execute([$status, $eventId]);

            if ($stmt->rowCount() === 0) {
                $check = $pdo->prepare('SELECT id FROM events WHERE id = ?');
                $check->execute([$eventId]);

                if (!$check->fetch()) {
                    $error = 'Event not found.';
                }
            }
        } catch (PDOException $e) {
            error_log('Event moderation error: ' . $e->getMessage());
            $error = 'Unable to update event status. Check your events table schema.';
        }
    }
}

$q = trim($_GET['q'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$sql = 'SELECT e.id, e.title, e.event_type, e.event_date, e.location,
               e.status, u.name AS organiser_name
        FROM events e
        LEFT JOIN users u ON u.id = e.user_id
        WHERE 1=1';
$params = [];

if ($q !== '') {
    $sql .= ' AND (e.title LIKE ? OR e.location LIKE ? OR u.name LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}

if (in_array($statusFilter, $allowedStatuses, true)) {
    $sql .= ' AND e.status = ?';
    $params[] = $statusFilter;
}

$sql .= ' ORDER BY e.id DESC LIMIT 300';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

adminPageStart('Manage Events');
?>

<?php if ($error !== ''): ?>
    <p class="alert alert-error"><?= h($error) ?></p>
<?php endif; ?>

<form method="get" class="filter-form">
    <input type="search" name="q" placeholder="Search events or organisers"
           value="<?= h($q) ?>">

    <select name="status">
        <option value="">All statuses</option>
        <?php foreach ($allowedStatuses as $item): ?>
            <option value="<?= h($item) ?>"
                <?= $statusFilter === $item ? 'selected' : '' ?>>
                <?= h(ucfirst($item)) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit">Filter</button>
</form>

<div class="table-responsive">
<table>
    <thead>
        <tr>
            <th>Event</th><th>Organiser</th><th>Date</th>
            <th>Location</th><th>Status</th><th>Moderate</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($events as $event): ?>
        <tr>
            <td>
                <?= h($event['title']) ?><br>
                <small><?= h($event['event_type'] ?? '') ?></small>
            </td>
            <td><?= h($event['organiser_name'] ?? 'Unknown') ?></td>
            <td><?= h($event['event_date'] ?? '') ?></td>
            <td><?= h($event['location'] ?? '') ?></td>
            <td><?= h(ucfirst($event['status'])) ?></td>
            <td>
                <form method="post">
                    <?php adminCsrfField(); ?>
                    <input type="hidden" name="event_id"
                           value="<?= (int) $event['id'] ?>">

                    <select name="status">
                        <?php foreach ($allowedStatuses as $item): ?>
                            <option value="<?= h($item) ?>"
                                <?= $event['status'] === $item ? 'selected' : '' ?>>
                                <?= h(ucfirst($item)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Save</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>

    <?php if (!$events): ?>
        <tr><td colspan="6">No events found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php adminPageEnd(); ?>
