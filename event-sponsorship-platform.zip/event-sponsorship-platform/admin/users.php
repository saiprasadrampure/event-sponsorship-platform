
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

adminPostGuard();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
    $action = $_POST['action'] ?? '';

    if (!$userId || !in_array($action, ['activate', 'suspend'], true)) {
        $error = 'Invalid account action.';
    } elseif ($userId === (int) currentUser()['id']) {
        $error = 'You cannot change your own account status.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'UPDATE users SET is_active = ? WHERE id = ? AND role <> ?'
            );
            $stmt->execute([
                $action === 'activate' ? 1 : 0,
                $userId,
                'admin'
            ]);

            if ($stmt->rowCount() > 0) {
                $message = 'Account status updated.';
            } else {
                $message = 'No account was changed. Check the user ID or current status.';
            }
        } catch (PDOException $e) {
            error_log('Admin user update error: ' . $e->getMessage());
            $error = 'Unable to update this account.';
        }
    }
}

$q = trim($_GET['q'] ?? '');
$role = $_GET['role'] ?? '';
$allowedRoles = ['admin', 'business_manager', 'event_organiser', 'customer'];

$sql = 'SELECT id, name, email, role, is_active FROM users WHERE 1=1';
$params = [];

if ($q !== '') {
    $sql .= ' AND (name LIKE ? OR email LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}

if (in_array($role, $allowedRoles, true)) {
    $sql .= ' AND role = ?';
    $params[] = $role;
}

$sql .= ' ORDER BY id DESC LIMIT 300';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

adminPageStart('Manage Users');
?>

<?php if ($error !== ''): ?>
    <p class="alert alert-error"><?= h($error) ?></p>
<?php endif; ?>

<form method="get" class="filter-form">
    <input type="search" name="q" placeholder="Search name or email"
           value="<?= h($q) ?>">

    <select name="role">
        <option value="">All roles</option>
        <?php foreach ($allowedRoles as $item): ?>
            <option value="<?= h($item) ?>"
                <?= $role === $item ? 'selected' : '' ?>>
                <?= h(ucwords(str_replace('_', ' ', $item))) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit">Search</button>
</form>

<div class="table-responsive">
<table>
    <thead>
        <tr>
            <th>ID</th><th>Name</th><th>Email</th>
            <th>Role</th><th>Status</th><th>Action</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($users as $user): ?>
        <tr>
            <td><?= (int) $user['id'] ?></td>
            <td><?= h($user['name']) ?></td>
            <td><?= h($user['email']) ?></td>
            <td><?= h(ucwords(str_replace('_', ' ', $user['role']))) ?></td>
            <td><?= (int) $user['is_active'] === 1 ? 'Active' : 'Suspended' ?></td>
            <td>
                <?php if ($user['role'] !== 'admin'): ?>
                    <form method="post">
                        <?php adminCsrfField(); ?>
                        <input type="hidden" name="user_id"
                               value="<?= (int) $user['id'] ?>">
                        <input type="hidden" name="action"
                               value="<?= (int) $user['is_active'] === 1 ? 'suspend' : 'activate' ?>">
                        <button type="submit">
                            <?= (int) $user['is_active'] === 1 ? 'Suspend' : 'Activate' ?>
                        </button>
                    </form>
                <?php else: ?>
                    Admin account
                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; ?>

    <?php if (!$users): ?>
        <tr><td colspan="6">No users found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php adminPageEnd(); ?>
