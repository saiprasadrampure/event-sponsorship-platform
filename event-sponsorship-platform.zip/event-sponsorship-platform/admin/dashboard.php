
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$stats = [
    'users' => 0,
    'organisers' => 0,
    'businesses' => 0,
    'events' => 0,
    'pending_events' => 0,
    'subscriptions' => 0,
];

try {
    $stats['users'] = (int) $pdo->query(
        'SELECT COUNT(*) FROM users'
    )->fetchColumn();

    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM users WHERE role = ?"
    );
    $stmt->execute(['event_organiser']);
    $stats['organisers'] = (int) $stmt->fetchColumn();

    $stmt->execute(['business_manager']);
    $stats['businesses'] = (int) $stmt->fetchColumn();

    $stats['events'] = (int) $pdo->query(
        'SELECT COUNT(*) FROM events'
    )->fetchColumn();

    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM events WHERE status = ?"
    );
    $stmt->execute(['draft']);
    $stats['pending_events'] = (int) $stmt->fetchColumn();

    $stats['subscriptions'] = (int) $pdo->query(
        "SELECT COUNT(*) FROM subscriptions WHERE status = 'active'"
    )->fetchColumn();
} catch (PDOException $e) {
    error_log('Admin dashboard error: ' . $e->getMessage());
}

adminPageStart('Admin Dashboard');
?>

<div class="stats-grid">
    <?php foreach ([
        'Total Users' => $stats['users'],
        'Event Organisers' => $stats['organisers'],
        'Business Managers' => $stats['businesses'],
        'Total Events' => $stats['events'],
        'Draft Events' => $stats['pending_events'],
        'Active Subscriptions' => $stats['subscriptions'],
    ] as $label => $value): ?>
        <article class="stat-card">
            <h3><?= h($label) ?></h3>
            <p class="stat-number"><?= number_format($value) ?></p>
        </article>
    <?php endforeach; ?>
</div>

<h2>Administration</h2>
<div class="dashboard-grid">
    <a class="dashboard-card" href="<?= h(assetUrl('admin/users.php')) ?>">
        <h3>Manage Users</h3>
        <p>Search, review and manage platform accounts.</p>
    </a>

    <a class="dashboard-card" href="<?= h(assetUrl('admin/verify-organisers.php')) ?>">
        <h3>Verify Organisers</h3>
        <p>Review organiser verification requests.</p>
    </a>

    <a class="dashboard-card" href="<?= h(assetUrl('admin/verify-businesses.php')) ?>">
        <h3>Verify Businesses</h3>
        <p>Review business verification requests.</p>
    </a>

    <a class="dashboard-card" href="<?= h(assetUrl('admin/events.php')) ?>">
        <h3>Manage Events</h3>
        <p>Moderate event listings and publication status.</p>
    </a>

    <a class="dashboard-card" href="<?= h(assetUrl('admin/reports.php')) ?>">
        <h3>Reports</h3>
        <p>Review platform activity and totals.</p>
    </a>

    <a class="dashboard-card" href="<?= h(assetUrl('admin/subscriptions.php')) ?>">
        <h3>Subscriptions</h3>
        <p>Review subscription plans and statuses.</p>
    </a>
</div>

<?php adminPageEnd(); ?>
