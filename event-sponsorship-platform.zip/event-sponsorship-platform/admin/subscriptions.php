
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

adminPostGuard();
$error = '';

$allowedStatuses = ['pending', 'active', 'cancelled', 'expired'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subscriptionId = filter_input(
        INPUT_POST,
        'subscription_id',
        FILTER_VALIDATE_INT
    );
    $status = $_POST['status'] ?? '';

    if (
        !$subscriptionId ||
        !in_array($status, $allowedStatuses, true)
    ) {
        $error = 'Invalid subscription update.';
    } else {
        try {
            $stmt = $pdo->prepare(
                'UPDATE subscriptions SET status = ? WHERE id = ?'
            );
            $stmt->execute([$status, $subscriptionId]);

            if ($stmt->rowCount() === 0) {
                $check = $pdo->prepare(
                    'SELECT id FROM subscriptions WHERE id = ?'
                );
                $check->execute([$subscriptionId]);

                if (!$check->fetch()) {
                    $error = 'Subscription record not found.';
                }
            }
        } catch (PDOException $e) {
            error_log('Subscription update error: ' . $e->getMessage());
            $error = 'Unable to update subscription status.';
        }
    }
}

$q = trim($_GET['q'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$sql = 'SELECT s.id, s.user_id, s.plan_name, s.amount, s.status,
               s.starts_at, s.expires_at, s.created_at,
               u.name, u.email
        FROM subscriptions s
        LEFT JOIN users u ON u.id = s.user_id
        WHERE 1=1';
$params = [];

if ($q !== '') {
    $sql .= ' AND (u.name LIKE ? OR u.email LIKE ? OR s.plan_name LIKE ?)';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
    $params[] = '%' . $q . '%';
}

if (in_array($statusFilter, $allowedStatuses, true)) {
    $sql .= ' AND s.status = ?';
    $params[] = $statusFilter;
}

$sql .= ' ORDER BY s.id DESC LIMIT 300';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$subscriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

adminPageStart('Manage Subscriptions');
?>

<?php if ($error !== ''): ?>
    <p class="alert alert-error"><?= h($error) ?></p>
<?php endif; ?>

<form method="get" class="filter-form">
    <input type="search" name="q"
           placeholder="Search user or plan"
           value="<?= h($q) ?>">

    <select name="status">
        <option value="">All statuses</option>
        <?php foreach ($allowedStatuses as $item): ?>
            <option value="<?= h($item) ?>"
                <?= $statusFilter === $item ? 'selected' : '' ?>>
                <?= h(ucfirst($item)) ?>
            </option>
        <?php endforeach; ?>
    </select>

    <button type="submit">Filter</button>
</form>

<div class="table-responsive">
<table>
    <thead>
        <tr>
            <th>User</th><th>Plan</th><th>Amount</th>
            <th>Dates</th><th>Status</th><th>Update</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($subscriptions as $subscription): ?>
        <tr>
            <td>
                <?= h($subscription['name'] ?? 'Unknown user') ?><br>
                <small><?= h($subscription['email'] ?? '') ?></small>
            </td>
            <td><?= h($subscription['plan_name']) ?></td>
            <td><?= h(formatINR($subscription['amount'])) ?></td>
            <td>
                Started: <?= h($subscription['starts_at'] ?? 'Not set') ?><br>
                Expires: <?= h($subscription['expires_at'] ?? 'Not set') ?>
            </td>
            <td><?= h(ucfirst($subscription['status'])) ?></td>
            <td>
                <form method="post">
                    <?php adminCsrfField(); ?>
                    <input type="hidden" name="subscription_id"
                           value="<?= (int) $subscription['id'] ?>">

                    <select name="status">
                        <?php foreach ($allowedStatuses as $item): ?>
                            <option value="<?= h($item) ?>"
                                <?= $subscription['status'] === $item ? 'selected' : '' ?>>
                                <?= h(ucfirst($item)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Save</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>

    <?php if (!$subscriptions): ?>
        <tr><td colspan="6">No subscriptions found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php adminPageEnd(); ?>
