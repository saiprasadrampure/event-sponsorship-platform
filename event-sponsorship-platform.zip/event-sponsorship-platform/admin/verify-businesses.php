
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

adminPostGuard();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
    $status = $_POST['status'] ?? '';

    if (!$userId || !in_array($status, ['approved', 'rejected', 'pending'], true)) {
        $error = 'Invalid verification request.';
    } else {
        try {
            $stmt = $pdo->prepare(
                "SELECT id FROM users WHERE id = ? AND role = 'business_manager'"
            );
            $stmt->execute([$userId]);

            if (!$stmt->fetch()) {
                $error = 'Business account not found.';
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO business_profiles (user_id, verification_status)
                     VALUES (?, ?)
                     ON DUPLICATE KEY UPDATE verification_status = VALUES(verification_status)'
                );
                $stmt->execute([$userId, $status]);
            }
        } catch (PDOException $e) {
            error_log('Business verification error: ' . $e->getMessage());
            $error = 'Unable to update verification status.';
        }
    }
}

$stmt = $pdo->query(
    "SELECT u.id, u.name, u.email,
            p.business_name,
            COALESCE(p.verification_status, 'pending') AS verification_status
     FROM users u
     LEFT JOIN business_profiles p ON p.user_id = u.id
     WHERE u.role = 'business_manager'
     ORDER BY CASE
        WHEN COALESCE(p.verification_status, 'pending') = 'pending' THEN 0
        ELSE 1
     END, u.id DESC"
);
$businesses = $stmt->fetchAll(PDO::FETCH_ASSOC);

adminPageStart('Verify Businesses');
?>

<?php if ($error !== ''): ?>
    <p class="alert alert-error"><?= h($error) ?></p>
<?php endif; ?>

<div class="table-responsive">
<table>
    <thead>
        <tr>
            <th>Business</th><th>Account Name</th><th>Email</th>
            <th>Verification</th><th>Update</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($businesses as $business): ?>
        <tr>
            <td><?= h($business['business_name'] ?: 'Not provided') ?></td>
            <td><?= h($business['name']) ?></td>
            <td><?= h($business['email']) ?></td>
            <td><?= h(ucfirst($business['verification_status'])) ?></td>
            <td>
                <form method="post">
                    <?php adminCsrfField(); ?>
                    <input type="hidden" name="user_id"
                           value="<?= (int) $business['id'] ?>">
                    <select name="status">
                        <?php foreach (['pending', 'approved', 'rejected'] as $status): ?>
                            <option value="<?= h($status) ?>"
                                <?= $business['verification_status'] === $status ? 'selected' : '' ?>>
                                <?= h(ucfirst($status)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Save</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>

    <?php if (!$businesses): ?>
        <tr><td colspan="5">No business accounts found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php adminPageEnd(); ?>
