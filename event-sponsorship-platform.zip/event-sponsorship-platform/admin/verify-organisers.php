
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

adminPostGuard();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
    $status = $_POST['status'] ?? '';

    if (!$userId || !in_array($status, ['approved', 'rejected', 'pending'], true)) {
        $error = 'Invalid verification request.';
    } else {
        try {
            $stmt = $pdo->prepare(
                "SELECT id FROM users WHERE id = ? AND role = 'event_organiser'"
            );
            $stmt->execute([$userId]);

            if (!$stmt->fetch()) {
                $error = 'Organiser account not found.';
            } else {
                $stmt = $pdo->prepare(
                    'INSERT INTO organiser_profiles (user_id, verification_status)
                     VALUES (?, ?)
                     ON DUPLICATE KEY UPDATE verification_status = VALUES(verification_status)'
                );
                $stmt->execute([$userId, $status]);
            }
        } catch (PDOException $e) {
            error_log('Organiser verification error: ' . $e->getMessage());
            $error = 'Unable to update verification status.';
        }
    }
}

$stmt = $pdo->query(
    "SELECT u.id, u.name, u.email,
            COALESCE(p.verification_status, 'pending') AS verification_status
     FROM users u
     LEFT JOIN organiser_profiles p ON p.user_id = u.id
     WHERE u.role = 'event_organiser'
     ORDER BY CASE
        WHEN COALESCE(p.verification_status, 'pending') = 'pending' THEN 0
        ELSE 1
     END, u.id DESC"
);
$organisers = $stmt->fetchAll(PDO::FETCH_ASSOC);

adminPageStart('Verify Event Organisers');
?>

<?php if ($error !== ''): ?>
    <p class="alert alert-error"><?= h($error) ?></p>
<?php endif; ?>

<div class="table-responsive">
<table>
    <thead>
        <tr>
            <th>Name</th><th>Email</th><th>Verification</th><th>Update</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($organisers as $organiser): ?>
        <tr>
            <td><?= h($organiser['name']) ?></td>
            <td><?= h($organiser['email']) ?></td>
            <td><?= h(ucfirst($organiser['verification_status'])) ?></td>
            <td>
                <form method="post">
                    <?php adminCsrfField(); ?>
                    <input type="hidden" name="user_id"
                           value="<?= (int) $organiser['id'] ?>">
                    <select name="status">
                        <?php foreach (['pending', 'approved', 'rejected'] as $status): ?>
                            <option value="<?= h($status) ?>"
                                <?= $organiser['verification_status'] === $status ? 'selected' : '' ?>>
                                <?= h(ucfirst($status)) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit">Save</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>

    <?php if (!$organisers): ?>
        <tr><td colspan="4">No organiser accounts found.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<?php adminPageEnd(); ?>
