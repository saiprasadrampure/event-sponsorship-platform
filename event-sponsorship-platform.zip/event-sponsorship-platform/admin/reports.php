
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

$report = [
    'users' => 0,
    'organisers' => 0,
    'businesses' => 0,
    'customers' => 0,
    'events' => 0,
    'applications' => null,
    'registrations' => null,
    'subscriptions' => null,
];
$eventBreakdown = [];
$errors = [];

try {
    $report['users'] = (int) $pdo->query(
        'SELECT COUNT(*) FROM users'
    )->fetchColumn();

    $stmt = $pdo->query(
        "SELECT role, COUNT(*) AS total FROM users GROUP BY role"
    );

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        if ($row['role'] === 'event_organiser') {
            $report['organisers'] = (int) $row['total'];
        } elseif ($row['role'] === 'business_manager') {
            $report['businesses'] = (int) $row['total'];
        } elseif ($row['role'] === 'customer') {
            $report['customers'] = (int) $row['total'];
        }
    }

    $report['events'] = (int) $pdo->query(
        'SELECT COUNT(*) FROM events'
    )->fetchColumn();

    $stmt = $pdo->query(
        'SELECT status, COUNT(*) AS total
         FROM events GROUP BY status ORDER BY status'
    );
    $eventBreakdown = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log('Admin reports core query error: ' . $e->getMessage());
    $errors[] = 'Some user or event totals could not be loaded.';
}

$optionalQueries = [
    'applications' => 'SELECT COUNT(*) FROM sponsorship_applications',
    'registrations' => 'SELECT COUNT(*) FROM event_registrations',
    'subscriptions' => "SELECT COUNT(*) FROM subscriptions WHERE status = 'active'",
];

foreach ($optionalQueries as $key => $sql) {
    try {
        $report[$key] = (int) $pdo->query($sql)->fetchColumn();
    } catch (PDOException $e) {
        // Optional tables may not have been created yet.
        $report[$key] = null;
    }
}

adminPageStart('Platform Reports');
?>

<?php foreach ($errors as $error): ?>
    <p class="alert alert-error"><?= h($error) ?></p>
<?php endforeach; ?>

<div class="stats-grid">
    <?php
    $cards = [
        'Total Users' => $report['users'],
        'Organisers' => $report['organisers'],
        'Business Managers' => $report['businesses'],
        'Customers' => $report['customers'],
        'Total Events' => $report['events'],
        'Sponsorship Applications' => $report['applications'],
        'Customer Registrations' => $report['registrations'],
        'Active Subscriptions' => $report['subscriptions'],
    ];
    ?>

    <?php foreach ($cards as $label => $value): ?>
        <article class="stat-card">
            <h3><?= h($label) ?></h3>
            <p class="stat-number">
                <?= $value === null ? 'Not available' : number_format($value) ?>
            </p>
        </article>
    <?php endforeach; ?>
</div>

<h2>Events by Status</h2>

<div class="table-responsive">
<table>
    <thead>
        <tr><th>Status</th><th>Number of Events</th></tr>
    </thead>
    <tbody>
    <?php foreach ($eventBreakdown as $row): ?>
        <tr>
            <td><?= h(ucfirst($row['status'])) ?></td>
            <td><?= number_format((int) $row['total']) ?></td>
        </tr>
    <?php endforeach; ?>

    <?php if (!$eventBreakdown): ?>
        <tr><td colspan="2">No event status data available.</td></tr>
    <?php endif; ?>
    </tbody>
</table>
</div>

<p>
    <small>
        “Not available” means the corresponding table or query is not available
        in the current database. It does not mean the total is zero.
    </small>
</p>

<?php adminPageEnd(); ?>
