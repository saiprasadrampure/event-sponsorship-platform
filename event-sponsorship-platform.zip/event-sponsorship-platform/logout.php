
<?php

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';

// Allow only POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit('Method not allowed.');
}

// Get CSRF token
$token = $_POST['csrf_token'] ?? '';

// Verify CSRF token
if (!verifyCsrfToken($token)) {
    http_response_code(403);
    exit('Invalid request. Please return to the homepage and try again.');
}

// Clear session variables
$_SESSION = [];

// Expire session cookie
if (ini_get('session.use_cookies')) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        [
            'expires' => time() - 42000,
            'path' => $params['path'],
            'domain' => $params['domain'],
            'secure' => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => $params['samesite'] ?? 'Lax'
        ]
    );
}

// Destroy session
session_destroy();

// Redirect to homepage
header('Location: ' . BASE_URL . '/index.php');
exit;
