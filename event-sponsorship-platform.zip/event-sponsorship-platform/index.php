<?php
/*
 * EventConnect - refreshed homepage
 * Place this file at:
 * C:\xampp\htdocs\event-sponsorship-platform\index.php
 *
 * Uses the existing database connection in includes/db.php ($pdo).
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

if (file_exists(__DIR__ . '/includes/functions.php')) {
    require_once __DIR__ . '/includes/functions.php';
}

$events = [];
$dbMessage = '';
$eventQueryFailed = false;

try {
    if (isset($pdo) && $pdo instanceof PDO) {
        // The query matches the events/users tables in the EventConnect schema.
        $sql = "SELECT e.id, e.title, e.event_type, e.event_date, e.location,
                       e.description, e.sponsorship_amount, e.status,
                       u.name AS organiser_name
                FROM events e
                LEFT JOIN users u ON u.id = e.user_id
                ORDER BY e.event_date ASC
                LIMIT 6";
        $stmt = $pdo->query($sql);
        $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $eventQueryFailed = true;
        $dbMessage = 'The database connection is not available.';
    }
} catch (Throwable $e) {
    // Keep the homepage visible if the events query or optional join fails.
    $eventQueryFailed = true;
    $dbMessage = 'Events are temporarily unavailable. Please check your database setup.';
}

function ec_h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function ec_date($value): string {
    if (!$value) return 'Date to be announced';
    try {
        return (new DateTime((string)$value))->format('d M Y');
    } catch (Throwable $e) {
        return ec_h($value);
    }
}

$baseUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : '/event-sponsorship-platform';
$appName = defined('APP_NAME') ? APP_NAME : 'EventConnect';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ec_h($appName) ?> | Discover. Connect. Sponsor.</title>
    <meta name="description" content="Discover events, connect with organisers and find sponsorship opportunities with EventConnect.">
    <style>
        :root {
            --bg: #f6f7fb;
            --surface: #ffffff;
            --surface-soft: #f0f1ff;
            --text: #17182b;
            --muted: #70738a;
            --line: #e8e9f1;
            --primary: #6257e8;
            --primary-dark: #4b40cf;
            --accent: #ff9b70;
            --shadow: 0 18px 50px rgba(28, 30, 70, .09);
            --radius: 22px;
        }
        body.dark {
            --bg: #111225;
            --surface: #1b1d35;
            --surface-soft: #252747;
            --text: #f5f5ff;
            --muted: #b0b2c8;
            --line: #30324e;
            --primary: #9188ff;
            --primary-dark: #7569f0;
            --accent: #ffad89;
            --shadow: 0 18px 50px rgba(0, 0, 0, .25);
        }
        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
            margin: 0;
            background: var(--bg);
            color: var(--text);
            font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            line-height: 1.6;
            transition: background .2s, color .2s;
        }
        a { color: inherit; text-decoration: none; }
        button, select { font: inherit; }
        .container { width: min(1160px, calc(100% - 40px)); margin: auto; }
        .topbar {
            position: sticky; top: 0; z-index: 20;
            background: color-mix(in srgb, var(--surface) 92%, transparent);
            border-bottom: 1px solid var(--line);
            backdrop-filter: blur(14px);
        }
        .nav { min-height: 76px; display: flex; align-items: center; justify-content: space-between; gap: 22px; }
        .brand { display: flex; align-items: center; gap: 10px; font-weight: 850; font-size: 1.25rem; letter-spacing: -.5px; }
        .brand-mark {
            width: 40px; height: 40px; border-radius: 13px; display: grid; place-items: center;
            color: white; background: linear-gradient(135deg, #756af2, #4d43c9);
            box-shadow: 0 8px 20px rgba(98,87,232,.28);
        }
        .brand span:last-child { color: var(--primary); }
        .nav-links { display: flex; align-items: center; gap: 27px; color: var(--muted); font-size: .94rem; font-weight: 650; }
        .nav-links a:hover { color: var(--primary); }
        .nav-actions { display: flex; align-items: center; gap: 10px; }
        .icon-btn, .language {
            border: 1px solid var(--line); background: var(--surface); color: var(--text);
            border-radius: 12px; padding: 9px 12px; cursor: pointer;
        }
        .btn {
            display: inline-flex; align-items: center; justify-content: center; gap: 8px;
            padding: 12px 19px; border-radius: 13px; border: 1px solid transparent;
            background: var(--primary); color: #fff; font-weight: 750; cursor: pointer;
            transition: transform .2s, background .2s;
        }
        .btn:hover { background: var(--primary-dark); transform: translateY(-2px); }
        .btn-outline { background: transparent; color: var(--text); border-color: var(--line); }
        .btn-outline:hover { color: #fff; border-color: var(--primary); }
        .hero { padding: 76px 0 58px; overflow: hidden; }
        .hero-grid { display: grid; grid-template-columns: 1.08fr .92fr; gap: 54px; align-items: center; }
        .eyebrow {
            display: inline-flex; gap: 8px; align-items: center; padding: 7px 12px;
            border-radius: 999px; color: var(--primary); background: var(--surface-soft);
            font-size: .82rem; font-weight: 800;
        }
        h1 { font-size: clamp(2.7rem, 5.5vw, 4.65rem); line-height: 1.06; letter-spacing: -2.7px; margin: 20px 0; }
        .gradient-text { background: linear-gradient(100deg, var(--primary), #a15de8 65%, #ee8a9d); -webkit-background-clip: text; background-clip: text; color: transparent; }
        .hero-copy { max-width: 570px; color: var(--muted); font-size: 1.1rem; }
        .hero-buttons { display: flex; flex-wrap: wrap; gap: 12px; margin: 28px 0 30px; }
        .trust-row { display: flex; align-items: center; gap: 14px; color: var(--muted); font-size: .88rem; }
        .avatar-stack { display: flex; }
        .avatar {
            width: 32px; height: 32px; border-radius: 50%; border: 2px solid var(--bg);
            display: grid; place-items: center; margin-left: -8px; color: white; font-size: .72rem; font-weight: 800;
            background: linear-gradient(135deg, #ff9a75, #e35d91);
        }
        .avatar:first-child { margin-left: 0; background: linear-gradient(135deg, #6c65e8, #a65ee0); }
        .hero-art {
            min-height: 410px; border-radius: 32px; padding: 26px; position: relative;
            background: radial-gradient(circle at 80% 15%, rgba(255,255,255,.32), transparent 24%),
                        linear-gradient(135deg, #6b60eb, #5147c8 55%, #8b58ce);
            box-shadow: 0 28px 65px rgba(84, 72, 205, .25);
        }
        .art-orb { position: absolute; border-radius: 50%; background: rgba(255,255,255,.12); }
        .orb-one { width: 210px; height: 210px; right: -35px; top: 35px; }
        .orb-two { width: 110px; height: 110px; left: 20px; bottom: -25px; }
        .event-preview {
            position: relative; z-index: 1; max-width: 355px; margin: 20px auto;
            background: #fff; color: #20213a; border-radius: 23px; padding: 15px;
            box-shadow: 0 22px 50px rgba(20, 18, 70, .25); transform: rotate(-3deg);
        }
        .preview-image {
            height: 175px; border-radius: 16px; display: flex; align-items: end; padding: 17px;
            color: white; font-size: 1.25rem; font-weight: 850;
            background: linear-gradient(0deg, rgba(15,16,40,.65), transparent 65%),
                        linear-gradient(135deg, #ffb17e, #ed7192 48%, #7b6be9);
        }
        .preview-meta { display: flex; justify-content: space-between; gap: 10px; margin-top: 14px; font-size: .82rem; color: #777991; }
        .preview-title { font-weight: 850; margin-top: 10px; font-size: 1.08rem; }
        .floating-note {
            position: absolute; z-index: 2; right: 5px; bottom: 34px; background: white; color: #252642;
            padding: 13px 16px; border-radius: 15px; box-shadow: var(--shadow); font-size: .83rem; font-weight: 750;
        }
        .floating-note strong { display: block; color: #6257e8; font-size: 1.2rem; }
        .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin: 4px 0 65px; }
        .stat { padding: 20px; background: var(--surface); border: 1px solid var(--line); border-radius: 18px; }
        .stat strong { display: block; font-size: 1.55rem; letter-spacing: -.8px; }
        .stat span { color: var(--muted); font-size: .88rem; }
        section { padding: 35px 0 65px; }
        .section-head { display: flex; justify-content: space-between; align-items: end; gap: 20px; margin-bottom: 25px; }
        .section-kicker { color: var(--primary); text-transform: uppercase; font-size: .76rem; letter-spacing: 1.5px; font-weight: 850; }
        h2 { font-size: clamp(1.8rem, 3vw, 2.5rem); line-height: 1.15; letter-spacing: -1px; margin: 7px 0; }
        .section-sub { color: var(--muted); margin: 5px 0 0; }
        .event-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .event-card { overflow: hidden; background: var(--surface); border: 1px solid var(--line); border-radius: 20px; box-shadow: var(--shadow); transition: transform .2s; }
        .event-card:hover { transform: translateY(-5px); }
        .event-cover { height: 155px; padding: 15px; display: flex; align-items: start; justify-content: space-between; color: white; }
        .event-cover.one { background: linear-gradient(135deg, #ff9d76, #e65d8e); }
        .event-cover.two { background: linear-gradient(135deg, #4d9fd1, #6359d9); }
        .event-cover.three { background: linear-gradient(135deg, #36b79b, #3977bc); }
        .event-cover.four { background: linear-gradient(135deg, #e6a34e, #d65f74); }
        .event-cover.five { background: linear-gradient(135deg, #8e75d9, #d36fba); }
        .event-cover.six { background: linear-gradient(135deg, #58a6b5, #5262c9); }
        .type-pill { background: rgba(255,255,255,.2); border: 1px solid rgba(255,255,255,.35); padding: 5px 10px; border-radius: 999px; font-size: .75rem; font-weight: 800; }
        .event-body { padding: 18px; }
        .event-date { color: var(--primary); font-size: .8rem; font-weight: 800; }
        .event-title { font-size: 1.12rem; line-height: 1.3; font-weight: 850; margin: 7px 0; }
        .event-description { color: var(--muted); font-size: .88rem; min-height: 44px; }
        .event-info { display: flex; flex-wrap: wrap; gap: 12px; color: var(--muted); font-size: .8rem; margin: 14px 0; }
        .event-footer { border-top: 1px solid var(--line); padding-top: 13px; display: flex; align-items: center; justify-content: space-between; gap: 8px; }
        .amount { font-weight: 850; font-size: .9rem; }
        .text-link { color: var(--primary); font-weight: 800; font-size: .86rem; }
        .empty-state { background: var(--surface); border: 1px dashed var(--line); border-radius: 20px; padding: 40px 20px; text-align: center; color: var(--muted); grid-column: 1 / -1; }
        .alert { padding: 12px 15px; margin-bottom: 20px; border-radius: 12px; background: #fff4e5; color: #87540c; font-size: .9rem; }
        body.dark .alert { background: #3a3022; color: #ffd28a; }
        .role-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; }
        .role-card { padding: 25px; background: var(--surface); border: 1px solid var(--line); border-radius: 20px; }
        .role-icon { width: 48px; height: 48px; display: grid; place-items: center; border-radius: 15px; background: var(--surface-soft); font-size: 1.4rem; }
        .role-card h3 { margin: 15px 0 6px; }
        .role-card p { color: var(--muted); font-size: .91rem; }
        .cta {
            padding: 42px; border-radius: 28px; color: white;
            background: linear-gradient(115deg, #6257e8, #8b55d4 70%, #bd69a5);
            display: flex; justify-content: space-between; align-items: center; gap: 25px;
        }
        .cta h2 { max-width: 590px; margin: 0 0 8px; }
        .cta p { margin: 0; color: rgba(255,255,255,.82); }
        .cta .btn { background: white; color: #5146cf; flex-shrink: 0; }
        footer { margin-top: 65px; padding: 35px 0; border-top: 1px solid var(--line); color: var(--muted); }
        .footer-inner { display: flex; justify-content: space-between; align-items: center; gap: 20px; flex-wrap: wrap; }
        .footer-links { display: flex; gap: 20px; flex-wrap: wrap; font-size: .88rem; }
        @media (max-width: 900px) {
            .hero-grid { grid-template-columns: 1fr; gap: 30px; }
            .hero-art { max-width: 620px; width: 100%; margin: auto; }
            .event-grid { grid-template-columns: repeat(2, 1fr); }
            .nav-links { display: none; }
        }
        @media (max-width: 620px) {
            .container { width: min(100% - 28px, 1160px); }
            .nav { min-height: 66px; }
            .brand { font-size: 1.05rem; }
            .nav-actions .btn { padding: 9px 11px; font-size: .82rem; }
            .language { display: none; }
            .hero { padding: 48px 0 35px; }
            h1 { letter-spacing: -1.7px; }
            .hero-art { min-height: 340px; padding: 15px; }
            .event-preview { max-width: 290px; }
            .preview-image { height: 140px; }
            .floating-note { right: -3px; bottom: 16px; }
            .stats { gap: 8px; margin-bottom: 35px; }
            .stat { padding: 13px 10px; }
            .stat strong { font-size: 1.2rem; }
            .stat span { font-size: .72rem; }
            .section-head { align-items: start; flex-direction: column; }
            .event-grid, .role-grid { grid-template-columns: 1fr; }
            .event-description { min-height: 0; }
            .cta { padding: 28px 22px; align-items: start; flex-direction: column; }
        }
    </style>
</head>
<body>
<header class="topbar">
    <div class="container nav">
        <a class="brand" href="<?= ec_h($baseUrl) ?>/">
            <span class="brand-mark">✦</span>
            <span>Event<span>Connect</span></span>
        </a>
        <nav class="nav-links" aria-label="Main navigation">
            <a href="#home" data-en="Home" data-mr="मुख्यपृष्ठ">Home</a>
            <a href="#events" data-en="Explore Events" data-mr="कार्यक्रम शोधा">Explore Events</a>
            <a href="#how" data-en="How it works" data-mr="कसे कार्य करते">How it works</a>
            <a href="#about" data-en="About" data-mr="आमच्याबद्दल">About</a>
        </nav>
        <div class="nav-actions">
            <select class="language" id="languageSelect" aria-label="Select language">
                <option value="en">English</option>
                <option value="mr">मराठी</option>
            </select>
            <button class="icon-btn" id="themeToggle" type="button" aria-label="Toggle dark mode">☾</button>
            <a class="btn btn-outline" href="<?= ec_h($baseUrl) ?>/login.php" data-en="Log in" data-mr="लॉग इन">Log in</a>
            <a class="btn" href="<?= ec_h($baseUrl) ?>/register.php" data-en="Get started" data-mr="सुरू करा">Get started</a>
        </div>
    </div>
</header>

<main>
    <section class="hero" id="home">
        <div class="container hero-grid">
            <div>
                <span class="eyebrow">✦ <span data-en="One platform. Endless possibilities." data-mr="एक व्यासपीठ. अमर्याद संधी.">One platform. Endless possibilities.</span></span>
                <h1 data-en-html="Bring great events<br>and great brands <span class='gradient-text'>together.</span>" data-mr-html="उत्तम कार्यक्रम आणि ब्रँड्सना <span class='gradient-text'>एकत्र आणा.</span>">Bring great events<br>and great brands <span class="gradient-text">together.</span></h1>
                <p class="hero-copy" data-en="Discover exciting events, connect with organisers and create meaningful sponsorship partnerships. Your next great collaboration starts here." data-mr="रोमांचक कार्यक्रम शोधा, आयोजकांशी जोडा आणि अर्थपूर्ण प्रायोजकत्व भागीदारी तयार करा. तुमची पुढील उत्तम भागीदारी येथे सुरू होते.">Discover exciting events, connect with organisers and create meaningful sponsorship partnerships. Your next great collaboration starts here.</p>
                <div class="hero-buttons">
                    <a class="btn" href="#events" data-en="Explore events →" data-mr="कार्यक्रम शोधा →">Explore events →</a>
                    <a class="btn btn-outline" href="<?= ec_h($baseUrl) ?>/register.php" data-en="Join EventConnect" data-mr="EventConnect मध्ये सामील व्हा">Join EventConnect</a>
                </div>
                <div class="trust-row">
                    <div class="avatar-stack"><span class="avatar">EC</span><span class="avatar">SP</span><span class="avatar">EV</span><span class="avatar">+</span></div>
                    <span data-en="A shared space for organisers, sponsors and attendees" data-mr="आयोजक, प्रायोजक आणि सहभागी यांच्यासाठी एक व्यासपीठ">A shared space for organisers, sponsors and attendees</span>
                </div>
            </div>
            <div class="hero-art" aria-label="Featured event preview">
                <span class="art-orb orb-one"></span><span class="art-orb orb-two"></span>
                <div class="event-preview">
                    <div class="preview-image"><span data-en="Ideas. People. Possibilities." data-mr="कल्पना. लोक. संधी.">Ideas. People. Possibilities.</span></div>
                    <div class="preview-meta"><span>✦ FEATURED EXPERIENCE</span><span>● Upcoming</span></div>
                    <div class="preview-title" data-en="Where connections become opportunities" data-mr="जिथे संबंध संधींमध्ये बदलतात">Where connections become opportunities</div>
                    <div class="preview-meta"><span>📍 Across your community</span><span>↗ Discover</span></div>
                </div>
                <div class="floating-note"><strong>✦</strong><span data-en="Make connections count" data-mr="संबंधांना महत्त्व द्या">Make connections count</span></div>
            </div>
        </div>
    </section>

    <div class="container stats">
        <div class="stat"><strong>Discover</strong><span data-en="Events worth attending" data-mr="सहभागी होण्यासारखे कार्यक्रम">Events worth attending</span></div>
        <div class="stat"><strong>Connect</strong><span data-en="Organisers and businesses" data-mr="आयोजक आणि व्यवसाय">Organisers and businesses</span></div>
        <div class="stat"><strong>Grow</strong><span data-en="Partnerships that matter" data-mr="महत्त्वाच्या भागीदारी">Partnerships that matter</span></div>
    </div>

    <section id="events">
        <div class="container">
            <div class="section-head">
                <div>
                    <div class="section-kicker" data-en="Find your next experience" data-mr="तुमचा पुढील अनुभव शोधा">Find your next experience</div>
                    <h2 data-en="Explore upcoming events" data-mr="आगामी कार्यक्रम शोधा">Explore upcoming events</h2>
                    <p class="section-sub" data-en="Discover events and sponsorship opportunities from the community." data-mr="समुदायातील कार्यक्रम आणि प्रायोजकत्वाच्या संधी शोधा.">Discover events and sponsorship opportunities from the community.</p>
                </div>
                <a class="text-link" href="<?= ec_h($baseUrl) ?>/events.php" data-en="View all events →" data-mr="सर्व कार्यक्रम पहा →">View all events →</a>
            </div>

            <?php if ($eventQueryFailed): ?>
                <div class="alert"><?= ec_h($dbMessage) ?> The homepage is visible, but event listings need a working database connection.</div>
            <?php endif; ?>

            <div class="event-grid">
                <?php if (!$events): ?>
                    <div class="empty-state">
                        <div style="font-size:2rem">✦</div>
                        <h3 data-en="Your next favourite event is on its way" data-mr="तुमचा आवडता पुढील कार्यक्रम लवकरच येथे असेल">Your next favourite event is on its way</h3>
                        <p data-en="There are no events to display right now. Please check back soon." data-mr="सध्या दाखवण्यासाठी कार्यक्रम नाहीत. कृपया पुन्हा भेट द्या.">There are no events to display right now. Please check back soon.</p>
                        <a class="btn" href="<?= ec_h($baseUrl) ?>/register.php" data-en="Join the community" data-mr="समुदायात सामील व्हा">Join the community</a>
                    </div>
                <?php else: ?>
                    <?php foreach ($events as $index => $event): ?>
                        <?php
                            $coverClass = ['one','two','three','four','five','six'][$index % 6];
                            $description = trim((string)($event['description'] ?? ''));
                            if (mb_strlen($description) > 105) $description = mb_substr($description, 0, 102) . '...';
                            $amount = $event['sponsorship_amount'] ?? null;
                        ?>
                        <article class="event-card">
                            <div class="event-cover <?= $coverClass ?>">
                                <span class="type-pill"><?= ec_h($event['event_type'] ?: 'Community event') ?></span>
                                <span aria-hidden="true">✦</span>
                            </div>
                            <div class="event-body">
                                <div class="event-date"><?= ec_h(ec_date($event['event_date'] ?? null)) ?></div>
                                <div class="event-title"><?= ec_h($event['title'] ?? 'Untitled event') ?></div>
                                <p class="event-description"><?= ec_h($description ?: 'Discover the details and connect with the event organiser.') ?></p>
                                <div class="event-info">
                                    <span>📍 <?= ec_h($event['location'] ?: 'Location to be announced') ?></span>
                                    <?php if (!empty($event['organiser_name'])): ?>
                                        <span>♙ <?= ec_h($event['organiser_name']) ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="event-footer">
                                    <span class="amount">
                                        <?php if ($amount !== null && $amount !== ''): ?>
                                            ₹<?= ec_h(number_format((float)$amount)) ?> <span style="color:var(--muted);font-weight:500" data-en="sponsorship goal" data-mr="प्रायोजकत्व उद्दिष्ट">sponsorship goal</span>
                                        <?php else: ?>
                                            <span data-en="Sponsorship opportunity" data-mr="प्रायोजकत्वाची संधी">Sponsorship opportunity</span>
                                        <?php endif; ?>
                                    </span>
                                    <a class="text-link" href="<?= ec_h($baseUrl) ?>/event-details.php?id=<?= (int)$event['id'] ?>" data-en="Details →" data-mr="तपशील →">Details →</a>
                                </div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section id="how">
        <div class="container">
            <div class="section-head">
                <div>
                    <div class="section-kicker" data-en="Built for every role" data-mr="प्रत्येक भूमिकेसाठी">Built for every role</div>
                    <h2 data-en="One community, three ways to grow" data-mr="एक समुदाय, प्रगतीचे तीन मार्ग">One community, three ways to grow</h2>
                    <p class="section-sub" data-en="Whether you create, sponsor or attend, EventConnect helps you make it happen." data-mr="तुम्ही कार्यक्रम आयोजित करा, प्रायोजित करा किंवा सहभागी व्हा—EventConnect तुम्हाला मदत करते.">Whether you create, sponsor or attend, EventConnect helps you make it happen.</p>
                </div>
            </div>
            <div class="role-grid">
                <article class="role-card">
                    <div class="role-icon">🎤</div>
                    <h3 data-en="Event organisers" data-mr="कार्यक्रम आयोजक">Event organisers</h3>
                    <p data-en="Publish events, reach potential sponsors, manage applications and grow your audience." data-mr="कार्यक्रम प्रकाशित करा, प्रायोजकांपर्यंत पोहोचा, अर्ज व्यवस्थापित करा आणि प्रेक्षक वाढवा.">Publish events, reach potential sponsors, manage applications and grow your audience.</p>
                    <a class="text-link" href="<?= ec_h($baseUrl) ?>/register.php" data-en="Join as an organiser →" data-mr="आयोजक म्हणून सामील व्हा →">Join as an organiser →</a>
                </article>
                <article class="role-card">
                    <div class="role-icon">🤝</div>
                    <h3 data-en="Business sponsors" data-mr="व्यवसाय प्रायोजक">Business sponsors</h3>
                    <p data-en="Find relevant events, connect with organisers and build brand visibility through sponsorship." data-mr="योग्य कार्यक्रम शोधा, आयोजकांशी संपर्क साधा आणि प्रायोजकत्वातून ब्रँडची ओळख वाढवा.">Find relevant events, connect with organisers and build brand visibility through sponsorship.</p>
                    <a class="text-link" href="<?= ec_h($baseUrl) ?>/register.php" data-en="Join as a sponsor →" data-mr="प्रायोजक म्हणून सामील व्हा →">Join as a sponsor →</a>
                </article>
                <article class="role-card">
                    <div class="role-icon">🎟️</div>
                    <h3 data-en="Event attendees" data-mr="कार्यक्रम सहभागी">Event attendees</h3>
                    <p data-en="Explore experiences, save events you love and keep track of your registrations." data-mr="नवीन अनुभव शोधा, आवडते कार्यक्रम जतन करा आणि नोंदणीचा मागोवा ठेवा.">Explore experiences, save events you love and keep track of your registrations.</p>
                    <a class="text-link" href="<?= ec_h($baseUrl) ?>/register.php" data-en="Join as an attendee →" data-mr="सहभागी म्हणून सामील व्हा →">Join as an attendee →</a>
                </article>
            </div>
        </div>
    </section>

    <section id="about">
        <div class="container">
            <div class="cta">
                <div>
                    <h2 data-en="Your next great partnership starts with a connection." data-mr="तुमची पुढील उत्तम भागीदारी एका संपर्काने सुरू होते.">Your next great partnership starts with a connection.</h2>
                    <p data-en="Create your free account and discover what you can make possible." data-mr="मोफत खाते तयार करा आणि नवीन संधी शोधा.">Create your free account and discover what you can make possible.</p>
                </div>
                <a class="btn" href="<?= ec_h($baseUrl) ?>/register.php" data-en="Get started free →" data-mr="मोफत सुरुवात करा →">Get started free →</a>
            </div>
        </div>
    </section>
</main>

<footer>
    <div class="container footer-inner">
        <a class="brand" href="<?= ec_h($baseUrl) ?>/"><span class="brand-mark">✦</span><span>Event<span>Connect</span></span></a>
        <div>© <?= date('Y') ?> EventConnect. <span data-en="All rights reserved." data-mr="सर्व हक्क राखीव.">All rights reserved.</span></div>
        
    </div>
</footer>

<script>
(function () {
    const body = document.body;
    const themeButton = document.getElementById('themeToggle');
    const languageSelect = document.getElementById('languageSelect');

    // Restore the visitor's theme preference.
    try {
        if (localStorage.getItem('eventconnect-theme') === 'dark') body.classList.add('dark');
    } catch (e) {}

    function updateThemeButton() {
        themeButton.textContent = body.classList.contains('dark') ? '☀' : '☾';
        themeButton.setAttribute('aria-label', body.classList.contains('dark') ? 'Switch to light mode' : 'Switch to dark mode');
    }
    updateThemeButton();

    themeButton.addEventListener('click', function () {
        body.classList.toggle('dark');
        updateThemeButton();
        try { localStorage.setItem('eventconnect-theme', body.classList.contains('dark') ? 'dark' : 'light'); } catch (e) {}
    });

    function setLanguage(language) {
        document.documentElement.lang = language;
        document.querySelectorAll('[data-en][data-mr]').forEach(function (element) {
            element.textContent = language === 'mr' ? element.getAttribute('data-mr') : element.getAttribute('data-en');
        });
        document.querySelectorAll('[data-en-html][data-mr-html]').forEach(function (element) {
            element.innerHTML = language === 'mr' ? element.getAttribute('data-mr-html') : element.getAttribute('data-en-html');
        });
        try { localStorage.setItem('eventconnect-language', language); } catch (e) {}
    }

    let savedLanguage = 'en';
    try { savedLanguage = localStorage.getItem('eventconnect-language') || 'en'; } catch (e) {}
    languageSelect.value = savedLanguage;
    setLanguage(savedLanguage);
    languageSelect.addEventListener('change', function () { setLanguage(this.value); });
})();
</script>
</body>
</html>