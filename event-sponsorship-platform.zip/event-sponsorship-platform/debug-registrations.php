
<?php
require_once __DIR__ . '/includes/db.php';

echo '<h2>EventConnect Database Diagnostic</h2>';

try {
    echo '<p style="color:green">Database connection loaded successfully.</p>';

    foreach (['event_registrations', 'events', 'users'] as $table) {
        echo '<h3>Table: ' . htmlspecialchars($table) . '</h3>';

        $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo '<ul>';
        foreach ($columns as $column) {
            echo '<li>' . htmlspecialchars($column['Field']) .
                 ' — ' . htmlspecialchars($column['Type']) . '</li>';
        }
        echo '</ul>';
    }

} catch (Throwable $e) {
    echo '<h3 style="color:red">Database error:</h3>';
    echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
}
