
<?php

// ========================================
// DATABASE AND SESSION
// ========================================

require_once __DIR__ . '/includes/db.php';

// Session is already started by config.php.


// ========================================
// CSRF TOKEN
// ========================================

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


// ========================================
// REDIRECT LOGGED-IN USERS
// ========================================

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}


// ========================================
// REGISTRATION PROCESSING
// ========================================

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {

        $error = 'Invalid request. Refresh the page and try again.';

    } else {

        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? '';

        $allowedRoles = [
            'business_manager',
            'event_organiser',
            'customer'
        ];

        if (
            $name === '' ||
            strlen($name) > 100 ||
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            strlen($email) > 190 ||
            !is_string($password) ||
            strlen($password) < 8 ||
            strlen($password) > 72 ||
            !in_array($role, $allowedRoles, true)
        ) {

            $error = 'Enter valid details. Password must be at least 8 characters.';

        } else {

            try {

                // Hash password securely
                $hash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                // Insert new user
                $stmt = $pdo->prepare(
                    'INSERT INTO users
                    (name, email, password_hash, role)
                    VALUES
                    (:name, :email, :password_hash, :role)'
                );

                $stmt->execute([
                    'name' => $name,
                    'email' => $email,
                    'password_hash' => $hash,
                    'role' => $role
                ]);

                // Create secure session
                session_regenerate_id(true);

                $_SESSION['user_id'] = (int) $pdo->lastInsertId();

                $_SESSION['user_name'] = $name;

                $_SESSION['user_role'] = $role;

                // Generate a new CSRF token
                $_SESSION['csrf_token'] = bin2hex(
                    random_bytes(32)
                );

                // Redirect after registration
                header('Location: index.php');
                exit;

            } catch (PDOException $e) {

                if ($e->getCode() === '23000') {

                    $error = 'This email is already registered.';

                } else {

                    error_log(
                        'EventConnect Registration Error: ' .
                        $e->getMessage()
                    );

                    $error = 'Registration failed. Please try again.';
                }
            }
        }
    }
}


// ========================================
// HTML ESCAPE FUNCTION
// ========================================

function e(string $value): string
{
    return htmlspecialchars(
        $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Create Account | EventConnect AI</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f3f5fb;
    color: #192033;
    min-height: 100vh;
    display: grid;
    place-items: center;
    padding: 20px;
}

.card {
    width: 100%;
    max-width: 480px;
    background: white;
    padding: 30px;
    border-radius: 18px;
    box-shadow: 0 10px 40px #17255412;
}

h1 {
    margin: 0 0 8px;
}

.muted {
    color: #64748b;
}

label {
    display: block;
    margin: 16px 0 7px;
    font-weight: 600;
}

input,
select {
    width: 100%;
    padding: 12px;
    border: 1px solid #d8deea;
    border-radius: 9px;
    font-size: 15px;
    background: white;
    color: #192033;
}

button {
    width: 100%;
    margin-top: 22px;
    padding: 13px;
    background: #635bff;
    color: white;
    border: 0;
    border-radius: 9px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #5048e5;
}

.error {
    padding: 12px;
    background: #fff0f0;
    color: #a11;
    border-radius: 8px;
}

a {
    color: #635bff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

</style>

</head>

<body>

<main class="card">

    <h1>Create your account</h1>

    <p class="muted">
        Join the EventConnect AI platform.
    </p>


    <?php if ($error !== ''): ?>

        <p class="error">
            <?= e($error) ?>
        </p>

    <?php endif; ?>


    <form method="post" action="register.php">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e($_SESSION['csrf_token']) ?>"
        >


        <label for="name">
            Full name
        </label>

        <input
            id="name"
            name="name"
            maxlength="100"
            autocomplete="name"
            required
            value="<?= e($_POST['name'] ?? '') ?>"
        >


        <label for="email">
            Email address
        </label>

        <input
            id="email"
            type="email"
            name="email"
            maxlength="190"
            autocomplete="email"
            required
            value="<?= e($_POST['email'] ?? '') ?>"
        >


        <label for="role">
            I want to join as
        </label>

        <select id="role" name="role" required>

            <option value="">
                Select your role
            </option>

            <option
                value="business_manager"
                <?= (($_POST['role'] ?? '') === 'business_manager') ? 'selected' : '' ?>
            >
                Business Manager
            </option>

            <option
                value="event_organiser"
                <?= (($_POST['role'] ?? '') === 'event_organiser') ? 'selected' : '' ?>
            >
                Event Organiser
            </option>

            <option
                value="customer"
                <?= (($_POST['role'] ?? '') === 'customer') ? 'selected' : '' ?>
            >
                Customer / Event Attendee
            </option>

        </select>


        <label for="password">
            Password (minimum 8 characters)
        </label>

        <input
            id="password"
            type="password"
            name="password"
            minlength="8"
            maxlength="72"
            autocomplete="new-password"
            required
        >


        <button type="submit">
            Create Account
        </button>

    </form>


    <p class="muted">
        Already registered?

        <a href="login.php">
            Login here
        </a>
    </p>


    <p>
        <a href="index.php">
            ← Back to homepage
        </a>
    </p>

</main>

</body>
</html>
