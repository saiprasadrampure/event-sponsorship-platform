
<?php

echo "<h2>MySQL Password Test</h2>";

$passwords = [
    "EventConnect@2026",
    ""
];

foreach ($passwords as $password) {

    try {
        $pdo = new PDO(
            "mysql:host=127.0.0.1;port=3306;dbname=event_platform;charset=utf8mb4",
            "root",
            $password,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );

        echo "<p style='color:green'>SUCCESS: MySQL connection works with ";

        echo ($password === "")
            ? "EMPTY password"
            : "EventConnect@2026";

        echo ".</p>";

    } catch (PDOException $e) {

        echo "<p style='color:red'>FAILED: ";

        echo ($password === "")
            ? "EMPTY password"
            : "EventConnect@2026";

        echo "</p>";
    }
}
