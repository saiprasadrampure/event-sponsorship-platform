
"""Explainable organiser scoring for EventConnect AI."""


def _number(value, default=0.0):
    try:
        number = float(value)
        if number < 0:
            return default
        return number
    except (TypeError, ValueError):
        return default


def score_organiser(organiser: dict) -> dict:
    """
    Score an organiser from 0 to 100.

    Expected optional fields:
      verified: bool
      completed_events: number
      published_events: number
      successful_sponsorships: number
      profile_completeness: number from 0 to 100
    """
    verified = organiser.get("verified", False) is True

    completed = _number(organiser.get("completed_events"))
    published = _number(organiser.get("published_events"))
    successful = _number(organiser.get("successful_sponsorships"))
    completeness = min(
        100.0, _number(organiser.get("profile_completeness"))
    )

    # Each component is capped to prevent one metric dominating the score.
    verification_points = 20 if verified else 0
    completed_points = min(completed / 10.0, 1.0) * 30
    published_points = min(published / 10.0, 1.0) * 15
    sponsorship_points = min(successful / 10.0, 1.0) * 25
    profile_points = completeness / 100.0 * 10

    score = round(
        verification_points
        + completed_points
        + published_points
        + sponsorship_points
        + profile_points,
        2,
    )

    reasons = []

    if verified:
        reasons.append("Verified organiser")
    else:
        reasons.append("Verification not confirmed")

    if completed > 0:
        reasons.append(f"{int(completed)} completed event(s)")

    if successful > 0:
        reasons.append(f"{int(successful)} successful sponsorship(s)")

    if completeness >= 80:
        reasons.append("Detailed profile")

    return {
        "score": score,
        "rating": (
            "strong" if score >= 75
            else "promising" if score >= 45
            else "developing"
        ),
        "reasons": reasons,
        "components": {
            "verification": round(verification_points, 2),
            "completed_events": round(completed_points, 2),
            "published_events": round(published_points, 2),
            "successful_sponsorships": round(sponsorship_points, 2),
            "profile_completeness": round(profile_points, 2),
        },
    }
