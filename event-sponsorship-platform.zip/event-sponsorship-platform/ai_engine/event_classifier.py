
"""Keyword-based event classification for EventConnect AI."""

import re
from collections import Counter


CATEGORY_KEYWORDS = {
    "wedding": {
        "wedding", "marriage", "bridal", "engagement", "reception",
        "mehendi", "haldi", "sangeet", "matrimony",
    },
    "birthday": {
        "birthday", "cake", "birthday party", "sweet sixteen",
        "anniversary", "celebration",
    },
    "corporate": {
        "corporate", "business conference", "seminar", "networking",
        "summit", "workshop", "product launch", "trade show",
        "conference", "exhibition",
    },
    "music": {
        "music", "concert", "singer", "band", "dj", "live performance",
        "festival", "musical", "gig",
    },
    "sports": {
        "sports", "cricket", "football", "soccer", "marathon",
        "tournament", "badminton", "basketball", "athletics",
    },
    "education": {
        "education", "school", "college", "university", "graduation",
        "training", "academic", "hackathon", "science fair",
    },
    "charity": {
        "charity", "fundraiser", "fundraising", "donation",
        "volunteer", "social cause", "awareness campaign", "ngo",
    },
    "food": {
        "food", "cuisine", "restaurant", "food festival",
        "tasting", "culinary", "cookery", "baking",
    },
    "arts": {
        "art", "painting", "photography", "craft", "theatre",
        "theater", "dance", "cultural", "fashion show", "exhibition",
    },
    "technology": {
        "technology", "tech", "software", "artificial intelligence",
        "ai", "startup", "coding", "robotics", "innovation",
    },
}


def _normalise(text: str) -> str:
    """Convert text to a predictable search form."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def classify_event(
    title: str,
    description: str = "",
    event_type: str = "",
) -> dict:
    """
    Return the most likely category and a keyword-based confidence estimate.

    The confidence value is a heuristic, not a calibrated ML probability.
    """
    title = _normalise(title)
    description = _normalise(description)
    event_type = _normalise(event_type)

    combined = f"{title} {description} {event_type}".strip()

    if not combined:
        return {
            "category": "other",
            "confidence": 0.0,
            "alternatives": [],
            "method": "keyword",
        }

    scores = Counter()

    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            keyword = _normalise(keyword)

            # Exact category/type matches receive additional weight.
            if event_type and keyword == event_type:
                scores[category] += 4

            if title and keyword in title:
                scores[category] += 3

            if keyword in description:
                scores[category] += 1

            if not title and not description and keyword in event_type:
                scores[category] += 3

    if not scores:
        return {
            "category": "other",
            "confidence": 0.25,
            "alternatives": [],
            "method": "keyword",
        }

    ranked = scores.most_common()
    best_category, best_score = ranked[0]
    second_score = ranked[1][1] if len(ranked) > 1 else 0

    # This is a simple ranking-based estimate, not a true probability.
    confidence = best_score / (best_score + second_score + 1)
    confidence = round(min(confidence, 0.99), 3)

    alternatives = [
        {"category": category, "score": score}
        for category, score in ranked[1:4]
    ]

    return {
        "category": best_category,
        "confidence": confidence,
        "alternatives": alternatives,
        "method": "keyword",
    }
