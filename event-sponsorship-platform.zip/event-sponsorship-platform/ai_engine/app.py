
"""Flask API for the EventConnect AI engine."""

import hmac
import os

from flask import Flask, jsonify, request
from flask_cors import CORS

from event_classifier import classify_event
from organiser_scoring import score_organiser
from recommendation import recommend_organisers, recommend_sponsors

app = Flask(__name__)

app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024

# Set EVENTCONNECT_ALLOWED_ORIGINS to your frontend's exact origin(s).
# Example: http://localhost,http://127.0.0.1
allowed_origins = [
    origin.strip()
    for origin in os.getenv(
        "EVENTCONNECT_ALLOWED_ORIGINS",
        "http://localhost,http://127.0.0.1",
    ).split(",")
    if origin.strip()
]

CORS(
    app,
    resources={r"/*": {"origins": allowed_origins}},
    methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "X-API-Key"],
)

API_KEY = os.getenv("EVENTCONNECT_AI_API_KEY", "")

if not API_KEY:
    app.logger.warning(
        "EVENTCONNECT_AI_API_KEY is not set. API key authentication "
        "is disabled; use only for local development."
    )


def require_api_key():
    """Require a shared key when one has been configured."""
    if not API_KEY:
        return None

    provided = request.headers.get("X-API-Key", "")

    if not hmac.compare_digest(provided, API_KEY):
        return jsonify({
            "success": False,
            "message": "Unauthorized API request.",
        }), 401

    return None


def read_payload():
    """Read and validate a JSON object."""
    if not request.is_json:
        return None, (
            jsonify({
                "success": False,
                "message": "Content-Type must be application/json.",
            }),
            415,
        )

    payload = request.get_json(silent=True)

    if not isinstance(payload, dict):
        return None, (
            jsonify({
                "success": False,
                "message": "Request body must be a JSON object.",
            }),
            400,
        )

    return payload, None


def text_field(data, key, default="", max_length=5000):
    value = data.get(key, default)

    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string.")

    value = value.strip()

    if len(value) > max_length:
        raise ValueError(f"{key} exceeds the maximum length.")

    return value


def list_of_objects(data, key):
    value = data.get(key)

    if not isinstance(value, list):
        raise ValueError(f"{key} must be a list.")

    if len(value) > 500:
        raise ValueError(f"{key} may contain at most 500 records.")

    if not all(isinstance(item, dict) for item in value):
        raise ValueError(f"Every item in {key} must be an object.")

    return value


@app.before_request
def authenticate_api():
    # Health checks are intentionally public and reveal no account data.
    if request.endpoint == "health":
        return None

    auth_error = require_api_key()
    if auth_error is not None:
        return auth_error

    if request.method not in ("GET", "POST", "OPTIONS"):
        return jsonify({
            "success": False,
            "message": "Method not allowed.",
        }), 405

    return None


@app.get("/health")
def health():
    return jsonify({
        "success": True,
        "service": "EventConnect AI",
        "status": "running",
    })


@app.post("/classify")
def classify():
    data, error = read_payload()
    if error:
        return error

    try:
        title = text_field(data, "title", max_length=200)
        description = text_field(data, "description")
        event_type = text_field(data, "event_type", max_length=100)

        result = classify_event(title, description, event_type)

        return jsonify({
            "success": True,
            "data": result,
        })
    except ValueError as exc:
        return jsonify({
            "success": False,
            "message": str(exc),
        }), 422


@app.post("/match-sponsors")
def match_sponsors():
    data, error = read_payload()
    if error:
        return error

    try:
        event = data.get("event")
        if not isinstance(event, dict):
            raise ValueError("event must be an object.")

        businesses = list_of_objects(data, "businesses")

        # Validate fields used for matching.
        event = dict(event)
        event["title"] = text_field(event, "title", max_length=200)
        event["description"] = text_field(event, "description")
        event["event_type"] = text_field(event, "event_type", max_length=100)
        event["location"] = text_field(event, "location", max_length=255)

        for business in businesses:
            if "name" in business and not isinstance(business["name"], str):
                raise ValueError("Each business name must be a string.")

        result = recommend_sponsors(event, businesses)

        return jsonify({
            "success": True,
            "data": result,
        })
    except ValueError as exc:
        return jsonify({
            "success": False,
            "message": str(exc),
        }), 422


@app.post("/score-organiser")
def score_organiser():
    data, error = read_payload()
    if error:
        return error

    organiser = data.get("organiser")
    if not isinstance(organiser, dict):
        return jsonify({
            "success": False,
            "message": "organiser must be an object.",
        }), 422

    return jsonify({
        "success": True,
        "data": score_organiser(organiser),
    })


@app.post("/recommend-organisers")
def recommend_organisers_endpoint():
    data, error = read_payload()
    if error:
        return error

    try:
        organisers = list_of_objects(data, "organisers")
        result = recommend_organisers(organisers)

        return jsonify({
            "success": True,
            "data": result,
        })
    except ValueError as exc:
        return jsonify({
            "success": False,
            "message": str(exc),
        }), 422


@app.errorhandler(413)
def request_too_large(_error):
    return jsonify({
        "success": False,
        "message": "Request body is too large.",
    }), 413


@app.errorhandler(500)
def internal_error(_error):
    app.logger.exception("Unhandled AI API error")
    return jsonify({
        "success": False,
        "message": "Internal AI service error.",
    }), 500


if __name__ == "__main__":
    # Local development only. Do not expose the development server publicly.
    app.run(host="127.0.0.1", port=5000, debug=False)
