
"""Sponsor matching and ranking for EventConnect AI."""

import re


def _normalise(value) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).lower()).strip()


def _as_number(value):
    try:
        number = float(value)
        return number if number >= 0 else None
    except (TypeError, ValueError):
        return None


def _as_list(value):
    if isinstance(value, list):
        return [_normalise(item) for item in value if _normalise(item)]
    if isinstance(value, str) and value.strip():
        return [_normalise(item) for item in value.split(",") if item.strip()]
    return []


def _category_score(event_category: str, business: dict) -> float:
    category = _normalise(event_category)

    preferred = _as_list(
        business.get("preferred_event_types")
        or business.get("event_categories")
    )

    industries = _as_list(
        business.get("business_category")
        or business.get("industry")
    )

    if not category:
        return 10.0

    if category in preferred:
        return 35.0

    if category in industries:
        return 30.0

    # Support broader text values, e.g. "music events" or "music sponsor".
    if any(category in item or item in category for item in preferred + industries):
        return 22.0

    if not preferred and not industries:
        return 10.0

    return 0.0


def _location_score(event: dict, business: dict) -> float:
    event_location = _normalise(event.get("location"))
    business_location = _normalise(business.get("location"))

    if not event_location or not business_location:
        return 5.0

    if event_location == business_location:
        return 20.0

    # A broad city/region comparison can be supplied explicitly.
    event_region = _normalise(event.get("region"))
    business_regions = _as_list(business.get("preferred_regions"))

    if event_region and event_region in business_regions:
        return 16.0

    if event_location in business_location or business_location in event_location:
        return 12.0

    return 0.0


def _budget_score(event: dict, business: dict) -> float:
    amount = _as_number(event.get("sponsorship_amount"))
    minimum = _as_number(business.get("min_sponsorship_budget"))
    maximum = _as_number(business.get("max_sponsorship_budget"))

    # Budget data is optional. Avoid treating missing data as a mismatch.
    if amount is None or (minimum is None and maximum is None):
        return 10.0

    if minimum is not None and amount < minimum:
        return 0.0

    if maximum is not None and amount > maximum:
        return 0.0

    return 20.0


def match_sponsor(event: dict, business: dict) -> dict:
    """Return a match score from 0 to 100 with an explanation."""
    category = _category_score(
        event.get("event_category") or event.get("event_type", ""),
        business,
    )
    location = _location_score(event, business)
    budget = _budget_score(event, business)

    verified = business.get("verified") is True
    verification = 15.0 if verified else 0.0

    active = business.get("is_active", True) is True
    activity = 10.0 if active else 0.0

    score = round(category + location + budget + verification + activity, 2)

    reasons = []
    if category >= 22:
        reasons.append("Relevant business or event category")
    elif category > 0:
        reasons.append("Category compatibility is uncertain")

    if location >= 16:
        reasons.append("Good location match")
    elif location > 0:
        reasons.append("Partial location match")

    if budget == 20:
        reasons.append("Sponsorship budget fits stated range")
    elif budget == 0:
        reasons.append("Sponsorship budget is outside the stated range")
    else:
        reasons.append("Budget compatibility cannot be fully assessed")

    if verified:
        reasons.append("Business is verified")
    else:
        reasons.append("Business verification not confirmed")

    if not active:
        reasons.append("Business account is inactive")

    return {
        "business_id": business.get("id"),
        "business_name": (
            business.get("business_name")
            or business.get("name")
            or "Business"
        ),
        "score": score,
        "eligible": active,
        "reasons": reasons,
        "components": {
            "category": category,
            "location": location,
            "budget": budget,
            "verification": verification,
            "activity": activity,
        },
    }


def rank_sponsors(event: dict, businesses: list[dict]) -> list[dict]:
    """Return active sponsor candidates in descending match-score order."""
    results = [
        match_sponsor(event, business)
        for business in businesses
    ]

    results = [item for item in results if item["eligible"]]
    results.sort(key=lambda item: item["score"], reverse=True)

    for rank, item in enumerate(results, start=1):
        item["rank"] = rank

    return results
