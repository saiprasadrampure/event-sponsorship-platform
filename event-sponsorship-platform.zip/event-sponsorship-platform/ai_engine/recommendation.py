
"""Recommendation orchestration for EventConnect AI."""

from event_classifier import classify_event
from organiser_scoring import score_organiser
from sponsor_matching import rank_sponsors


def recommend_sponsors(event: dict, businesses: list[dict]) -> dict:
    """Classify an event, rank businesses, and return the recommendations."""
    classification = classify_event(
        title=str(event.get("title", "")),
        description=str(event.get("description", "")),
        event_type=str(event.get("event_type", "")),
    )

    enriched_event = dict(event)
    enriched_event["event_category"] = (
        event.get("event_category") or classification["category"]
    )

    matches = rank_sponsors(enriched_event, businesses)

    return {
        "event_category": classification,
        "total_candidates": len(matches),
        "recommendations": matches[:20],
    }


def recommend_organisers(organisers: list[dict]) -> dict:
    """Rank organisers using their available profile and activity metrics."""
    results = []

    for organiser in organisers:
        scored = score_organiser(organiser)

        results.append({
            "organiser_id": organiser.get("id"),
            "name": organiser.get("name", "Organiser"),
            **scored,
        })

    results.sort(key=lambda item: item["score"], reverse=True)

    for rank, item in enumerate(results, start=1):
        item["rank"] = rank

    return {
        "total_candidates": len(results),
        "recommendations": results[:20],
    }
