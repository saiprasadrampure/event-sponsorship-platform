
<?php

// ========================================
// APPLICATION CONFIGURATION
// ========================================

define('APP_NAME', 'EventConnect AI');
define('APP_ENV', 'development');
define('BASE_URL', '/event-sponsorship-platform');


// ========================================
// LOAD .ENV FILE
// ========================================

function envValue($key, $default = '')
{
    static $env = null;

    if ($env === null) {

        $env = [];

        $envFile = dirname(__DIR__) . '/.env';

        if (file_exists($envFile)) {

            $lines = file(
                $envFile,
                FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
            );

            foreach ($lines as $line) {

                $line = trim($line);

                if ($line === '' || str_starts_with($line, '#')) {
                    continue;
                }

                if (strpos($line, '=') !== false) {

                    [$name, $value] = explode('=', $line, 2);

                    $env[trim($name)] = trim(trim($value), "\"'");
                }
            }
        }
    }

    return $env[$key] ?? $default;
}


// ========================================
// DATABASE CONFIGURATION
// ========================================

define('DB_HOST', envValue('DB_HOST', '127.0.0.1'));
define('DB_PORT', envValue('DB_PORT', '3306'));
define('DB_NAME', envValue('DB_NAME', 'event_platform'));
define('DB_USER', envValue('DB_USER', 'root'));

// MySQL root password is currently EMPTY
define('DB_PASS', envValue('DB_PASS', ''));


// ========================================
// TIMEZONE CONFIGURATION
// ========================================

date_default_timezone_set('Asia/Kolkata');


// ========================================
// SESSION CONFIGURATION
// ========================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

