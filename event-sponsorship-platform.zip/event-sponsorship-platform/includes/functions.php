
<?php

require_once __DIR__ . '/config.php';

/**
 * Escape text before displaying it in HTML.
 */
function h(mixed $value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

/**
 * Redirect to a project URL.
 */
function redirectTo(string $path): never
{
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}

/**
 * Store a one-time message.
 */
function setFlash(string $type, string $message): void
{
    $_SESSION['flash_message'] = [
        'type' => $type,
        'message' => $message,
    ];
}

/**
 * Retrieve and remove a one-time message.
 */
function getFlash(): ?array
{
    if (!isset($_SESSION['flash_message'])) {
        return null;
    }

    $message = $_SESSION['flash_message'];

    unset($_SESSION['flash_message']);

    return is_array($message) ? $message : null;
}

/**
 * Format an amount in Indian rupees.
 */
function formatINR(int|float|string $amount): string
{
    return '₹' . number_format(
        (float) $amount,
        2,
        '.',
        ','
    );
}

/**
 * Build a URL to a project asset.
 */
function assetUrl(string $path): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

/**
 * Convert a database date into a readable date.
 */
function formatDate(?string $date): string
{
    if (!$date) {
        return 'Not specified';
    }

    try {
        return (new DateTimeImmutable($date))->format('d M Y');

    } catch (Throwable $exception) {

        return 'Not specified';
    }
}

