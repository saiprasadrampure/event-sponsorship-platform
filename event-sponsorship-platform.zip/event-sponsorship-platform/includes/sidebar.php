
<?php

// ========================================
// AUTHENTICATION AND FUNCTIONS
// ========================================

require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';


// ========================================
// CHECK LOGIN
// ========================================

requireLogin();

$user = currentUser();

$role = $user['role'] ?? '';


// ========================================
// ROLE-BASED NAVIGATION MENUS
// ========================================

$menus = [

    // BUSINESS MANAGER MENU
    'business_manager' => [

        ['dashboard', 'dashboard.php', 'Dashboard'],

        ['organisers', 'find-organisers.php', 'Find Organisers'],

        ['events', 'event-discovery.php', 'Discover Events'],

        ['applications', 'applications.php', 'Sponsorship Applications'],

        ['posts', 'posts.php', 'Business Posts'],

        ['packages', 'packages.php', 'Premium Plans'],

    ],


    // EVENT ORGANISER MENU
    'event_organiser' => [

        ['dashboard', 'dashboard.php', 'Dashboard'],

        ['create-event', 'create-event.php', 'Create Event'],

        ['my-events', 'my-events.php', 'My Events'],

        ['ai-sponsors', 'ai-sponsors.php', 'AI Sponsor Matches'],

        ['applications', 'sponsorship-applications.php', 'Applications'],

        ['posts', 'posts.php', 'My Posts'],

    ],


    // CUSTOMER MENU
    'customer' => [

        ['dashboard', 'dashboard.php', 'Dashboard'],

        ['explore', 'explore-events.php', 'Explore Events'],

        ['saved', 'saved-events.php', 'Saved Events'],

        ['registrations', 'my-registrations.php', 'My Registrations'],

    ],


    // ADMIN MENU
    'admin' => [

        ['dashboard', 'dashboard.php', 'Dashboard'],

        ['users', 'users.php', 'Manage Users'],

        ['organisers', 'verify-organisers.php', 'Verify Organisers'],

        ['businesses', 'verify-businesses.php', 'Verify Businesses'],

        ['events', 'events.php', 'Manage Events'],

        ['subscriptions', 'subscriptions.php', 'Subscriptions'],

        ['reports', 'reports.php', 'Reports'],

    ],

];


// ========================================
// GET CURRENT MENU ITEMS
// ========================================

$menuItems = $menus[$role] ?? [];


// ========================================
// ACTIVE PAGE
// ========================================

$activePage = $activePage ?? 'dashboard';


// ========================================
// ROLE DIRECTORY
// ========================================

$roleDirectories = [

    'business_manager' => 'business',

    'event_organiser' => 'organiser',

    'customer' => 'customer',

    'admin' => 'admin',

];

$roleDirectory = $roleDirectories[$role] ?? 'customer';

?>

<!-- ========================================
     SIDEBAR NAVIGATION
========================================= -->

<aside class="sidebar">


    <!-- SIDEBAR HEADING -->

    <h3
        data-en="Navigation"
        data-mr="नेव्हिगेशन"
    >
        Navigation
    </h3>


    <!-- NAVIGATION LINKS -->

    <nav aria-label="Dashboard navigation">

        <?php foreach ($menuItems as [$key, $path, $label]): ?>

            <a
                href="<?= h(assetUrl($roleDirectory . '/' . $path)) ?>"
                class="<?= $activePage === $key ? 'active' : '' ?>"
                <?= $activePage === $key ? 'aria-current="page"' : '' ?>
            >

                <span>
                    <?= h($label) ?>
                </span>

            </a>

        <?php endforeach; ?>

    </nav>

</aside>
