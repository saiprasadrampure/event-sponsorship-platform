
<?php

// ========================================
// HEADER CONFIGURATION
// ========================================

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';


// ========================================
// PAGE INFORMATION
// ========================================

$pageTitle = $pageTitle ?? APP_NAME;

$user = currentUser();


// ========================================
// USER ROLE LABELS
// ========================================

$roleLabels = [
    'business_manager' => 'Business Manager',
    'event_organiser' => 'Event Organiser',
    'customer' => 'Customer',
    'admin' => 'Administrator',
];

$roleLabel = $roleLabels[$user['role'] ?? ''] ?? 'Member';

?>

<!DOCTYPE html>
<html lang="en" data-theme="light">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description"
          content="EventConnect AI - Smarter Events. Better Partnerships.">

    <title>
        <?= h($pageTitle) ?> | <?= h(APP_NAME) ?>
    </title>


    <!-- ========================================
         CSS STYLESHEETS
    ========================================= -->

    <link
        rel="stylesheet"
        href="<?= h(assetUrl('assets/css/style.css')) ?>"
    >

    <link
        rel="stylesheet"
        href="<?= h(assetUrl('assets/css/dashboard.css')) ?>"
    >

    <link
        rel="stylesheet"
        href="<?= h(assetUrl('assets/css/forms.css')) ?>"
    >

    <link
        rel="stylesheet"
        href="<?= h(assetUrl('assets/css/responsive.css')) ?>"
    >


    <!-- ========================================
         THEME INITIALIZATION
    ========================================= -->

    <script>
    (() => {
        try {
            const theme = localStorage.getItem('ec-theme');

            document.documentElement.dataset.theme =
                theme === 'dark' ? 'dark' : 'light';

        } catch (error) {
            document.documentElement.dataset.theme = 'light';
        }
    })();
    </script>

</head>


<body>


<!-- ========================================
     MAIN NAVIGATION
========================================= -->

<header class="site-nav">

    <!-- LOGO -->

    <a
        class="logo"
        href="<?= h(assetUrl('index.php')) ?>"
    >
        EventConnect AI
    </a>


    <!-- NAVIGATION LINKS -->

    <nav class="nav-links" aria-label="Main navigation">


        <!-- HOME -->

        <a
            href="<?= h(assetUrl('index.php')) ?>"
            data-en="Home"
            data-mr="मुख्यपृष्ठ"
        >
            Home
        </a>


        <!-- DARK MODE BUTTON -->

        <button
            type="button"
            class="btn-secondary"
            data-theme-toggle
            aria-label="Toggle dark mode"
        >
            🌙 Dark Mode
        </button>


        <!-- LANGUAGE TOGGLE BUTTON -->

        <button
            type="button"
            class="btn-secondary"
            data-language-toggle
        >
            मराठी
        </button>


        <?php if ($user): ?>


            <!-- LOGGED-IN USER INFORMATION -->

            <span class="user-info">

                <?= h($user['name']) ?>

                <small class="muted">
                    (<?= h($roleLabel) ?>)
                </small>

            </span>


            <!-- LOGOUT FORM -->

            <form
                action="<?= h(assetUrl('logout.php')) ?>"
                method="POST"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= h(csrfToken()) ?>"
                >

                <button
                    type="submit"
                    class="btn-secondary"
                    data-en="Logout"
                    data-mr="बाहेर पडा"
                >
                    Logout
                </button>

            </form>


        <?php else: ?>


            <!-- GUEST LOGIN -->

            <a
                href="<?= h(assetUrl('login.php')) ?>"
                data-en="Login"
                data-mr="लॉगिन"
            >
                Login
            </a>


            <!-- GUEST REGISTRATION -->

            <a
                class="btn"
                href="<?= h(assetUrl('register.php')) ?>"
                data-en="Register"
                data-mr="नोंदणी करा"
            >
                Register
            </a>


        <?php endif; ?>


    </nav>

</header>


<!-- ========================================
     MAIN PAGE CONTENT
========================================= -->

<main class="page-content">
