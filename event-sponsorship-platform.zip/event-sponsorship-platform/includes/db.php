
<?php

// ========================================
// DATABASE CONNECTION
// ========================================

require_once __DIR__ . '/config.php';


// ========================================
// CONNECT TO MYSQL DATABASE
// ========================================

try {

    $dsn = "mysql:host=" . DB_HOST .
           ";port=" . DB_PORT .
           ";dbname=" . DB_NAME .
           ";charset=utf8mb4";

    $pdo = new PDO(
        $dsn,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,

            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );


} catch (PDOException $e) {

    // Save actual error in PHP error log
    error_log(
        "EventConnect AI Database Error: " . $e->getMessage()
    );

    // Show safe error message
    die(
        "Database connection failed. Please check MySQL configuration."
    );

}

