
<?php

require_once __DIR__ . '/config.php';

/**
 * Start application session safely.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check whether the user is authenticated.
 */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/**
 * Return the current logged-in user.
 */
function currentUser(): ?array
{
    if (!isLoggedIn()) {
        return null;
    }

    return [
        'id' => (int) $_SESSION['user_id'],
        'name' => (string) ($_SESSION['user_name'] ?? ''),
        'role' => (string) ($_SESSION['user_role'] ?? ''),
    ];
}

/**
 * Redirect guests to the login page.
 */
function requireLogin(): void
{
    if (!isLoggedIn()) {

        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

/**
 * Allow only specified user roles.
 *
 * Examples:
 * requireRole('business_manager');
 * requireRole('event_organiser');
 * requireRole('customer');
 * requireRole('admin');
 */
function requireRole(string ...$allowedRoles): void
{
    requireLogin();

    $role = $_SESSION['user_role'] ?? '';

    if (!in_array($role, $allowedRoles, true)) {

        http_response_code(403);

        exit(
            'Access denied: you do not have permission to view this page.'
        );
    }
}

/**
 * Generate or return a CSRF token.
 */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {

        $_SESSION['csrf_token'] = bin2hex(
            random_bytes(32)
        );
    }

    return $_SESSION['csrf_token'];
}

/**
 * Validate a submitted CSRF token.
 */
function verifyCsrfToken(?string $token): bool
{
    return is_string($token)
        && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Escape text before displaying it in HTML.
 */
function escapeHtml(string $value): string
{
    return htmlspecialchars(
        $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

