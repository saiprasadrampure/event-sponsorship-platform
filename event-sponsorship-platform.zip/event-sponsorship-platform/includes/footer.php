
<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';
?>

</main>

<footer>
    <p>
        © <?= date('Y') ?> <?= h(APP_NAME) ?>.

        <span
            data-en="Smarter Events. Better Partnerships."
            data-mr="स्मार्ट कार्यक्रम. उत्तम भागीदारी."
        >
            Smarter Events. Better Partnerships.
        </span>
    </p>
</footer>

<script src="<?= h(assetUrl('js/theme.js')) ?>" defer></script>
<script src="<?= h(assetUrl('js/language.js')) ?>" defer></script>
<script src="<?= h(assetUrl('js/validation.js')) ?>" defer></script>
<script src="<?= h(assetUrl('js/notifications.js')) ?>" defer></script>
<script src="<?= h(assetUrl('js/app.js')) ?>" defer></script>

</body>
</html>
