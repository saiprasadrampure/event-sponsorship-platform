
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$user = currentUser();
$userId = (int) $user['id'];

$pageTitle = 'Business Posts';
$activePage = 'posts';

$errors = [];
$success = '';
$posts = [];

$title = '';
$content = '';

/*
|--------------------------------------------------------------------------
| Publish a business post
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $csrfTokenValue = $_POST['csrf_token'] ?? '';

    if (!verifyCsrfToken($csrfTokenValue)) {
        $errors[] = 'Invalid security token. Please refresh the page and try again.';
    }

    $title = trim((string) ($_POST['title'] ?? ''));
    $content = trim((string) ($_POST['content'] ?? ''));

    if ($title === '' || mb_strlen($title) > 150) {
        $errors[] = 'Title is required and must be at most 150 characters.';
    }

    if ($content === '' || mb_strlen($content) > 5000) {
        $errors[] = 'Post content is required and must be at most 5,000 characters.';
    }

    if (empty($errors)) {

        try {

            $stmt = $pdo->prepare("
                INSERT INTO business_posts
                    (business_manager_id, title, content)
                VALUES
                    (:user_id, :title, :content)
            ");

            $stmt->execute([
                'user_id' => $userId,
                'title' => $title,
                'content' => $content
            ]);

            $success = 'Post published successfully.';

            // Clear form after successful publishing.
            $title = '';
            $content = '';

        } catch (PDOException $e) {

            error_log('Business post publishing error: ' . $e->getMessage());

            $errors[] = 'Unable to publish your post. Please check the business_posts table.';
        }
    }
}

/*
|--------------------------------------------------------------------------
| Load posts belonging to this business
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare("
        SELECT id, title, content, created_at
        FROM business_posts
        WHERE business_manager_id = :user_id
        ORDER BY created_at DESC, id DESC
        LIMIT 50
    ");

    $stmt->execute([
        'user_id' => $userId
    ]);

    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log('Business posts loading error: ' . $e->getMessage());

    $posts = [];

    $errors[] = 'Unable to load posts. Please check the business_posts table.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>Business Posts</h1>

    <p>
        Share sponsorship announcements, business updates,
        and opportunities with the EventConnect AI community.
    </p>

    <!-- Success message -->

    <?php if ($success !== ''): ?>

        <div class="alert alert-success">
            <?= h($success) ?>
        </div>

    <?php endif; ?>

    <!-- Error messages -->

    <?php if (!empty($errors)): ?>

        <div class="alert alert-error">

            <?php foreach (array_unique($errors) as $error): ?>

                <p><?= h($error) ?></p>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

    <!-- Create post form -->

    <div class="card" style="padding:24px;margin:20px 0;">

        <h2>Create a Post</h2>

        <form method="POST">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h(csrfToken()) ?>"
            >

            <div class="form-group">

                <label for="title">Post Title</label>

                <input
                    type="text"
                    id="title"
                    name="title"
                    maxlength="150"
                    value="<?= h($title) ?>"
                    placeholder="Enter your post title"
                    required
                >

            </div>

            <div class="form-group">

                <label for="content">Message</label>

                <textarea
                    id="content"
                    name="content"
                    maxlength="5000"
                    rows="5"
                    placeholder="Write your announcement or update..."
                    required
                ><?= h($content) ?></textarea>

            </div>

            <button
                class="btn btn-primary"
                type="submit"
            >
                Publish Post
            </button>

        </form>

    </div>

    <!-- Published posts -->

    <div class="section-heading">

        <h2>Your Posts</h2>

        <span class="muted">
            <?= count($posts) ?> posts
        </span>

    </div>

    <?php if (!empty($posts)): ?>

        <?php foreach ($posts as $post): ?>

            <article
                class="card"
                style="padding:20px;margin:14px 0;"
            >

                <h3><?= h($post['title']) ?></h3>

                <p>
                    <?= nl2br(h($post['content'])) ?>
                </p>

                <small class="muted">
                    Published:
                    <?= h(formatDate($post['created_at'])) ?>
                </small>

            </article>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="card" style="padding:20px;">

            <h3>No posts published yet</h3>

            <p class="muted">
                Your business announcements and updates
                will appear here after publishing.
            </p>

        </div>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
