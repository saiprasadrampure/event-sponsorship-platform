
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$pageTitle = 'Event Discovery';
$activePage = 'event-discovery';

$search = trim((string) ($_GET['q'] ?? ''));
$type = trim((string) ($_GET['type'] ?? ''));

$events = [];
$errorMessage = '';

$eventTypes = [
    'Wedding',
    'Birthday',
    'Corporate',
    'Education',
    'Sports',
    'Music',
    'Cultural',
    'Charity',
    'Technology'
];

// Only allow known event types.
if ($type !== '' && !in_array($type, $eventTypes, true)) {
    $type = '';
}

/*
|--------------------------------------------------------------------------
| Search published upcoming events
|--------------------------------------------------------------------------
*/

try {
    $sql = "
        SELECT
            e.id,
            e.user_id,
            e.title,
            e.event_type,
            e.event_date,
            e.location,
            e.description,
            u.name AS organiser_name
        FROM events e
        INNER JOIN users u ON u.id = e.user_id
        WHERE e.status = 'published'
          AND e.event_date >= CURDATE()
          AND (
              :search = ''
              OR e.title LIKE :title_search
              OR e.location LIKE :location_search
          )
          AND (
              :type = ''
              OR e.event_type = :event_type
          )
        ORDER BY e.event_date ASC, e.id DESC
        LIMIT 100
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        'search' => $search,
        'title_search' => '%' . $search . '%',
        'location_search' => '%' . $search . '%',
        'type' => $type,
        'event_type' => $type,
    ]);

    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Event discovery error: ' . $e->getMessage());

    $errorMessage = 'Events could not be loaded. Please check your database configuration.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>Discover Events</h1>

    <p>
        Find upcoming events that may be suitable for your sponsorship.
    </p>

    <!-- Search and filters -->

    <form
        method="GET"
        action="<?= h(assetUrl('business/event-discovery.php')) ?>"
        class="card"
        style="padding:16px;display:flex;gap:12px;flex-wrap:wrap;"
    >

        <input
            type="search"
            name="q"
            value="<?= h($search) ?>"
            placeholder="Search event or location"
            aria-label="Search events"
            style="flex:1;min-width:180px;"
        >

        <select name="type" aria-label="Filter by event type">

            <option value="">All event types</option>

            <?php foreach ($eventTypes as $option): ?>

                <option
                    value="<?= h($option) ?>"
                    <?= $type === $option ? 'selected' : '' ?>
                >
                    <?= h($option) ?>
                </option>

            <?php endforeach; ?>

        </select>

        <button type="submit" class="btn btn-primary">
            Filter Events
        </button>

        <?php if ($search !== '' || $type !== ''): ?>

            <a
                href="<?= h(assetUrl('business/event-discovery.php')) ?>"
                class="btn"
            >
                Clear Filters
            </a>

        <?php endif; ?>

    </form>

    <!-- Error message -->

    <?php if ($errorMessage !== ''): ?>

        <div class="card" style="padding:16px;margin-top:20px;">
            <p class="alert alert-error">
                <?= h($errorMessage) ?>
            </p>
        </div>

    <?php else: ?>

        <div class="section-heading" style="margin-top:24px;">
            <h2>Available Events</h2>

            <span class="muted">
                <?= count($events) ?> events found
            </span>
        </div>

        <!-- Event cards -->

        <?php if (!empty($events)): ?>

            <div style="
                display:grid;
                grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
                gap:18px;
                margin-top:20px;
            ">

                <?php foreach ($events as $event): ?>

                    <article class="card" style="padding:20px;">

                        <span class="role-badge">
                            <?= h($event['event_type'] ?: 'Event') ?>
                        </span>

                        <h2><?= h($event['title']) ?></h2>

                        <p>
                            <strong>Date:</strong>
                            <?= h(formatDate($event['event_date'])) ?>
                        </p>

                        <p>
                            <strong>Location:</strong>
                            <?= h($event['location'] ?: 'Not specified') ?>
                        </p>

                        <p>
                            <strong>Organiser:</strong>
                            <?= h($event['organiser_name']) ?>
                        </p>

                        <p>
                            <?= h(mb_strimwidth(
                                (string) ($event['description'] ?? ''),
                                0,
                                180,
                                '...'
                            )) ?>
                        </p>

                        <a
                            class="btn btn-primary"
                            href="<?= h(assetUrl(
                                'business/event-details.php?id=' .
                                (int) $event['id']
                            )) ?>"
                        >
                            View Event Details
                        </a>

                        <a
                            href="<?= h(assetUrl(
                                'business/organiser-details.php?id=' .
                                (int) $event['user_id']
                            )) ?>"
                            style="display:inline-block;margin-top:10px;"
                        >
                            View Organiser Profile
                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="card" style="padding:24px;margin-top:20px;">

                <h3>No upcoming events found</h3>

                <p class="muted">
                    Try another search term or select a different event type.
                </p>

                <a
                    href="<?= h(assetUrl('business/event-discovery.php')) ?>"
                    class="btn"
                >
                    Show All Events
                </a>

            </div>

        <?php endif; ?>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
