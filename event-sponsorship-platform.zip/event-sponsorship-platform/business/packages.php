
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$pageTitle = 'Premium Packages';
$activePage = 'packages';

$packages = [
    [
        'name' => 'Basic',
        'price' => 599,
        'period' => 'month',
        'description' => 'For businesses getting started with event sponsorship.',
        'features' => [
            'Browse event listings',
            'Contact event organisers',
            'Basic sponsorship profile',
        ],
        'recommended' => false,
    ],
    [
        'name' => 'Professional',
        'price' => 1499,
        'period' => 'month',
        'description' => 'For businesses looking to grow their sponsorship reach.',
        'features' => [
            'Everything in Basic',
            'Enhanced business visibility',
            'Priority discovery placement',
        ],
        'recommended' => true,
    ],
    [
        'name' => 'Enterprise',
        'price' => 2999,
        'period' => 'month',
        'description' => 'For businesses managing larger sponsorship campaigns.',
        'features' => [
            'Everything in Professional',
            'Advanced sponsorship analytics',
            'Priority support',
        ],
        'recommended' => false,
    ],
];

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <div class="dashboard-topbar">
        <div>
            <h1>Premium Packages</h1>

            <p class="muted">
                Choose a package to support your sponsorship
                discovery workflow.
            </p>
        </div>
    </div>

    <!-- Subscription packages -->

    <div style="
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
        gap:20px;
        margin-top:24px;
        align-items:stretch;
    ">

        <?php foreach ($packages as $package): ?>

            <article
                class="card"
                style="
                    padding:24px;
                    display:flex;
                    flex-direction:column;
                    gap:14px;
                    border:<?= $package['recommended']
                        ? '2px solid var(--primary-color, #6366f1)'
                        : '1px solid var(--border-color, #ddd)' ?>;
                "
            >

                <?php if ($package['recommended']): ?>

                    <span class="role-badge">
                        Recommended
                    </span>

                <?php endif; ?>

                <div>
                    <h2><?= h($package['name']) ?></h2>

                    <p class="muted">
                        <?= h($package['description']) ?>
                    </p>
                </div>

                <div>

                    <strong style="font-size:30px;">
                        <?= h(formatINR($package['price'])) ?>
                    </strong>

                    <span class="muted">
                        / <?= h($package['period']) ?>
                    </span>

                </div>

                <div>
                    <h3>Package Features</h3>

                    <ul style="padding-left:20px;">

                        <?php foreach ($package['features'] as $feature): ?>

                            <li style="margin:10px 0;">
                                <?= h($feature) ?>
                            </li>

                        <?php endforeach; ?>

                    </ul>
                </div>

                <div style="margin-top:auto;">

                    <button
                        class="btn btn-primary"
                        type="button"
                        onclick="alert('Subscription checkout is not connected yet. Please contact the administrator.')"
                        style="width:100%;"
                    >
                        Select Package
                    </button>

                </div>

            </article>

        <?php endforeach; ?>

    </div>

    <!-- Payment information -->

    <div class="card" style="padding:20px;margin-top:28px;">

        <h3>Subscription Information</h3>

        <p class="muted">
            Package prices are illustrative. Online payment,
            subscription activation, renewal and cancellation
            are not yet configured.
        </p>

        <p class="muted">
            Selecting a package does not currently create
            or activate a subscription.
        </p>

    </div>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
