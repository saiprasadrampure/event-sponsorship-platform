
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$pageTitle = 'Organiser Details';
$activePage = 'find-organisers';

$organiserId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$organiserId || $organiserId < 1) {
    http_response_code(400);
    exit('A valid organiser ID is required.');
}

$organiser = null;
$events = [];
$completedCount = 0;
$upcomingCount = 0;
$errorMessage = '';

/*
|--------------------------------------------------------------------------
| Load organiser profile
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT id, name, email
        FROM users
        WHERE id = :id
          AND role = 'event_organiser'
        LIMIT 1
    ");

    $stmt->execute(['id' => $organiserId]);

    $organiser = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$organiser) {
        http_response_code(404);
        exit('Organiser not found.');
    }

    /*
    |--------------------------------------------------------------------------
    | Completed events
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM events
        WHERE user_id = :user_id
          AND status = 'completed'
    ");

    $stmt->execute(['user_id' => $organiserId]);

    $completedCount = (int) $stmt->fetchColumn();

    /*
    |--------------------------------------------------------------------------
    | Upcoming published events
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM events
        WHERE user_id = :user_id
          AND status = 'published'
          AND event_date >= CURDATE()
    ");

    $stmt->execute(['user_id' => $organiserId]);

    $upcomingCount = (int) $stmt->fetchColumn();

    /*
    |--------------------------------------------------------------------------
    | Organiser event history
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            id,
            title,
            event_type,
            event_date,
            location,
            description,
            status
        FROM events
        WHERE user_id = :user_id
        ORDER BY event_date DESC, id DESC
        LIMIT 30
    ");

    $stmt->execute(['user_id' => $organiserId]);

    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log('Organiser details error: ' . $e->getMessage());

    $errorMessage = 'Unable to load organiser information. Please try again.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <p>
        <a href="<?= h(assetUrl('business/find-organisers.php')) ?>">
            ← Back to organisers
        </a>
    </p>

    <?php if ($errorMessage !== ''): ?>

        <div class="card" style="padding:20px;">
            <p class="alert alert-error">
                <?= h($errorMessage) ?>
            </p>
        </div>

    <?php else: ?>

        <!-- Organiser profile -->

        <div class="dashboard-topbar">

            <div>
                <h1><?= h($organiser['name']) ?></h1>

                <p class="muted">
                    <?= h($organiser['email']) ?>
                </p>
            </div>

        </div>

        <!-- Organiser statistics -->

        <h2>Organiser Overview</h2>

        <div class="stats-grid">

            <article class="stat-card">
                <span class="stat-label">Completed Events</span>

                <span class="stat-value">
                    <?= number_format($completedCount) ?>
                </span>
            </article>

            <article class="stat-card">
                <span class="stat-label">Upcoming Events</span>

                <span class="stat-value">
                    <?= number_format($upcomingCount) ?>
                </span>
            </article>

            <article class="stat-card">
                <span class="stat-label">Total Listed Events</span>

                <span class="stat-value">
                    <?= number_format(count($events)) ?>
                </span>
            </article>

        </div>

        <!-- Event history -->

        <div class="section-heading" style="margin-top:30px;">

            <h2>Events by This Organiser</h2>

        </div>

        <?php if (empty($events)): ?>

            <div class="card" style="padding:20px;">

                <h3>No events listed yet</h3>

                <p class="muted">
                    This organiser has not added any events to the platform.
                </p>

            </div>

        <?php else: ?>

            <div class="dashboard-grid">

                <?php foreach ($events as $event): ?>

                    <article class="event-card">

                        <span class="role-badge">
                            <?= h($event['event_type'] ?: 'Event') ?>
                        </span>

                        <h3><?= h($event['title']) ?></h3>

                        <p>
                            <strong>Date:</strong>
                            <?= h(formatDate($event['event_date'])) ?>
                        </p>

                        <p>
                            <strong>Location:</strong>
                            <?= h($event['location'] ?: 'Not specified') ?>
                        </p>

                        <p>
                            <strong>Status:</strong>
                            <?= h(ucfirst((string) $event['status'])) ?>
                        </p>

                        <p>
                            <?= h(mb_strimwidth(
                                (string) ($event['description'] ?? ''),
                                0,
                                180,
                                '...'
                            )) ?>
                        </p>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

        <div style="margin-top:24px;">

            <a
                class="btn"
                href="<?= h(assetUrl('business/find-organisers.php')) ?>"
            >
                Back to Organiser Search
            </a>

        </div>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
