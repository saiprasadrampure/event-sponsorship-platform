
<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$user = currentUser();
$userId = (int) $user['id'];
$pageTitle = 'Business Profile';
$activePage = 'profile';
$errors = [];
$success = '';

$stmt = $pdo->prepare('SELECT id, name, email, role FROM users WHERE id = ?');
$stmt->execute([$userId]);
$profile = $stmt->fetch();

if (!$profile) {
    http_response_code(404);
    exit('Profile not found.');
}

$name = $profile['name'];
$email = $profile['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireValidCsrfToken();

    $name = trim((string) ($_POST['name'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) ($_POST['confirm_password'] ?? '');

    if ($name === '' || mb_strlen($name) > 100) {
        $errors[] = 'Enter a name of up to 100 characters.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $errors[] = 'Enter a valid email address.';
    }

    if ($password !== '') {
        if (strlen($password) < 8) {
            $errors[] = 'Password must contain at least 8 characters.';
        }
        if ($password !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1');
        $stmt->execute([$email, $userId]);

        if ($stmt->fetch()) {
            $errors[] = 'This email is already registered.';
        } else {
            if ($password !== '') {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare(
                    'UPDATE users SET name = ?, email = ?, password_hash = ? WHERE id = ?'
                );
                $stmt->execute([$name, $email, $hash, $userId]);
            } else {
                $stmt = $pdo->prepare('UPDATE users SET name = ?, email = ? WHERE id = ?');
                $stmt->execute([$name, $email, $userId]);
            }

            $_SESSION['user_name'] = $name;
            $profile['name'] = $name;
            $profile['email'] = $email;
            $success = 'Profile updated successfully.';
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">
    <h1>Business Manager Profile</h1>
    <p>Manage your account details and password.</p>

    <div class="card" style="max-width:700px;padding:24px">
        <?php if ($success): ?>
            <p class="alert alert-success"><?= h($success) ?></p>
        <?php endif; ?>

        <?php if ($errors): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $error): ?>
                    <p><?= h($error) ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">

            <div class="form-group">
                <label for="name">Full name</label>
                <input id="name" name="name" required maxlength="100"
                       value="<?= h($profile['name']) ?>">
            </div>

            <div class="form-group">
                <label for="email">Email address</label>
                <input id="email" type="email" name="email" required maxlength="190"
                       value="<?= h($profile['email']) ?>">
            </div>

            <div class="form-group">
                <label for="password">New password (optional)</label>
                <input id="password" type="password" name="password" minlength="8"
                       autocomplete="new-password">
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm new password</label>
                <input id="confirm_password" type="password" name="confirm_password"
                       autocomplete="new-password">
            </div>

            <button type="submit" class="btn btn-primary">Save Profile</button>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
