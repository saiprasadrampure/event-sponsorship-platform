
<?php
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$pageTitle = 'Sponsorship Preferences';
$activePage = 'sponsorship-preferences';

$categories = [
    'Wedding', 'Birthday', 'Corporate', 'Education',
    'Sports', 'Music', 'Cultural', 'Charity', 'Technology'
];

$preferences = $_SESSION['sponsorship_preferences'] ?? [
    'categories' => [],
    'location' => '',
    'budget' => '10000',
    'notes' => '',
];

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireValidCsrfToken();

    $selected = $_POST['categories'] ?? [];
    $location = trim((string) ($_POST['location'] ?? ''));
    $budget = filter_var($_POST['budget'] ?? null, FILTER_VALIDATE_INT);
    $notes = trim((string) ($_POST['notes'] ?? ''));

    if (!is_array($selected)) {
        $selected = [];
    }

    $selected = array_values(array_intersect($categories, $selected));

    if ($budget === false || $budget < 0 || $budget > 1000000000) {
        $errors[] = 'Enter a valid sponsorship budget.';
    }

    if (mb_strlen($location) > 120 || mb_strlen($notes) > 1000) {
        $errors[] = 'Location or notes exceed the allowed length.';
    }

    if (!$errors) {
        $_SESSION['sponsorship_preferences'] = [
            'categories' => $selected,
            'location' => $location,
            'budget' => (string) $budget,
            'notes' => $notes,
        ];
        $preferences = $_SESSION['sponsorship_preferences'];
        $success = 'Preferences saved for this session.';
    }
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">
    <h1>Sponsorship Preferences</h1>
    <p>Tell EventConnect AI which events are relevant to your business.</p>

    <div class="card" style="max-width:800px;padding:24px">
        <?php if ($success): ?><p class="alert alert-success"><?= h($success) ?></p><?php endif; ?>
        <?php if ($errors): ?>
            <div class="alert alert-error">
                <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">

            <h3>Preferred event categories</h3>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px">
                <?php foreach ($categories as $category): ?>
                    <label>
                        <input type="checkbox" name="categories[]"
                               value="<?= h($category) ?>"
                            <?= in_array($category, $preferences['categories'], true) ? 'checked' : '' ?>>
                        <?= h($category) ?>
                    </label>
                <?php endforeach; ?>
            </div>

            <div class="form-group" style="margin-top:20px">
                <label for="location">Preferred location</label>
                <input id="location" name="location" maxlength="120"
                       placeholder="e.g. Pune, Mumbai, or Maharashtra"
                       value="<?= h($preferences['location']) ?>">
            </div>

            <div class="form-group">
                <label for="budget">Maximum sponsorship budget (₹)</label>
                <input id="budget" type="number" min="0" max="1000000000"
                       name="budget" required value="<?= h($preferences['budget']) ?>">
            </div>

            <div class="form-group">
                <label for="notes">Additional preferences</label>
                <textarea id="notes" name="notes" maxlength="1000" rows="4"><?= h($preferences['notes']) ?></textarea>
            </div>

            <button class="btn btn-primary" type="submit">Save Preferences</button>
        </form>
    </div>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
