
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$pageTitle = 'Find Organisers';
$activePage = 'find-organisers';

$search = trim((string) ($_GET['q'] ?? ''));

$organisers = [];
$errorMessage = '';

/*
|--------------------------------------------------------------------------
| Search event organisers and their event history
|--------------------------------------------------------------------------
*/

try {
    $sql = "
        SELECT
            u.id,
            u.name,
            u.email,

            COUNT(
                CASE
                    WHEN e.status = 'completed' THEN 1
                END
            ) AS completed_events,

            COUNT(
                CASE
                    WHEN e.status = 'published'
                    AND e.event_date >= CURDATE()
                    THEN 1
                END
            ) AS upcoming_events

        FROM users u

        LEFT JOIN events e
            ON e.user_id = u.id

        WHERE u.role = 'event_organiser'
          AND (
              :search = ''
              OR u.name LIKE :name_search
              OR u.email LIKE :email_search
          )

        GROUP BY u.id, u.name, u.email

        ORDER BY
            completed_events DESC,
            upcoming_events DESC,
            u.name ASC

        LIMIT 100
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        'search' => $search,
        'name_search' => '%' . $search . '%',
        'email_search' => '%' . $search . '%',
    ]);

    $organisers = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log('Organiser search error: ' . $e->getMessage());

    $errorMessage = 'Organisers could not be loaded. Please check your database configuration.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>Find Event Organisers</h1>

    <p>
        Discover event organisers and review their event experience
        before contacting them about sponsorship opportunities.
    </p>

    <!-- Search form -->

    <form
        method="GET"
        action="<?= h(assetUrl('business/find-organisers.php')) ?>"
        class="card"
        style="padding:16px;display:flex;gap:10px;flex-wrap:wrap;"
    >

        <input
            type="search"
            name="q"
            value="<?= h($search) ?>"
            placeholder="Search by name or email"
            aria-label="Search organisers"
            style="flex:1;min-width:200px;"
        >

        <button type="submit" class="btn btn-primary">
            Search
        </button>

        <?php if ($search !== ''): ?>

            <a
                class="btn btn-secondary"
                href="<?= h(assetUrl('business/find-organisers.php')) ?>"
            >
                Clear
            </a>

        <?php endif; ?>

    </form>

    <!-- Error message -->

    <?php if ($errorMessage !== ''): ?>

        <div class="card" style="padding:16px;margin-top:20px;">
            <p class="alert alert-error">
                <?= h($errorMessage) ?>
            </p>
        </div>

    <?php else: ?>

        <!-- Organiser results -->

        <div class="section-heading" style="margin-top:24px;">

            <h2>Organiser Results</h2>

            <span class="muted">
                <?= count($organisers) ?> organisers found
            </span>

        </div>

        <div
            class="card"
            style="padding:20px;margin-top:20px;overflow-x:auto;"
        >

            <table style="width:100%;border-collapse:collapse;">

                <thead>
                    <tr>
                        <th align="left">Organiser</th>
                        <th align="left">Completed Events</th>
                        <th align="left">Upcoming Events</th>
                        <th align="left">Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (empty($organisers)): ?>

                        <tr>
                            <td colspan="4" style="padding:20px;">
                                No organisers found.
                                Try another name or email address.
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($organisers as $organiser): ?>

                            <tr>

                                <td style="padding:12px 8px;">

                                    <strong>
                                        <?= h($organiser['name']) ?>
                                    </strong>

                                    <br>

                                    <small>
                                        <?= h($organiser['email']) ?>
                                    </small>

                                </td>

                                <td>
                                    <?= number_format(
                                        (int) $organiser['completed_events']
                                    ) ?>
                                </td>

                                <td>
                                    <?= number_format(
                                        (int) $organiser['upcoming_events']
                                    ) ?>
                                </td>

                                <td>

                                    <a
                                        href="<?= h(assetUrl(
                                            'business/organiser-details.php?id=' .
                                            (int) $organiser['id']
                                        )) ?>"
                                    >
                                        View Profile
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
