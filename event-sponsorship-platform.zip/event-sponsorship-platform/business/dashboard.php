
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$pageTitle = 'Business Dashboard';
$activePage = 'dashboard';

$user = currentUser();

$stats = [
    'organisers' => 0,
    'events' => 0,
    'applications' => 0,
    'active_sponsorships' => 0,
];

$upcomingEvents = [];
$topOrganisers = [];

$dashboardErrors = [];

/*
|--------------------------------------------------------------------------
| Dashboard statistics
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->query("
        SELECT COUNT(DISTINCT user_id)
        FROM events
        WHERE status = 'published'
    ");

    $stats['organisers'] = (int) $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Organiser statistics: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load organiser statistics.';
}

try {
    $stmt = $pdo->query("
        SELECT COUNT(*)
        FROM events
        WHERE status = 'published'
        AND event_date >= CURDATE()
    ");

    $stats['events'] = (int) $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Upcoming event statistics: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load event statistics.';
}

try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM sponsorship_applications
        WHERE business_manager_id = :user_id
    ");

    $stmt->execute(['user_id' => $user['id']]);
    $stats['applications'] = (int) $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Application statistics: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load application statistics.';
}

try {
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM sponsorship_applications
        WHERE business_manager_id = :user_id
        AND status = 'accepted'
    ");

    $stmt->execute(['user_id' => $user['id']]);
    $stats['active_sponsorships'] = (int) $stmt->fetchColumn();

} catch (PDOException $e) {
    error_log('Accepted sponsorship statistics: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load accepted sponsorship statistics.';
}

/*
|--------------------------------------------------------------------------
| Upcoming published events
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->query("
        SELECT
            e.id,
            e.title,
            e.event_type,
            e.event_date,
            e.location,
            e.description,
            u.name AS organiser_name
        FROM events e
        INNER JOIN users u ON u.id = e.user_id
        WHERE e.status = 'published'
        AND e.event_date >= CURDATE()
        ORDER BY e.event_date ASC
        LIMIT 5
    ");

    $upcomingEvents = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Upcoming events query: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load upcoming events.';
}

/*
|--------------------------------------------------------------------------
| Experienced organisers
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->query("
        SELECT
            u.id,
            u.name,
            COUNT(e.id) AS completed_events
        FROM users u
        INNER JOIN events e ON e.user_id = u.id
        WHERE u.role = 'event_organiser'
        AND e.status = 'completed'
        GROUP BY u.id, u.name
        ORDER BY completed_events DESC
        LIMIT 5
    ");

    $topOrganisers = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Top organisers query: ' . $e->getMessage());
    $dashboardErrors[] = 'Unable to load organiser rankings.';
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="dashboard-layout">

    <?php require __DIR__ . '/../includes/sidebar.php'; ?>

    <section class="dashboard-main">

        <div class="dashboard-topbar">
            <div>
                <h1
                    data-en="Business Dashboard"
                    data-mr="व्यवसाय डॅशबोर्ड">
                    Business Dashboard
                </h1>

                <p class="muted">
                    <span
                        data-en="Welcome back,"
                        data-mr="पुन्हा स्वागत आहे,">
                        Welcome back,
                    </span>
                    <?= h($user['name']) ?>!
                </p>
            </div>

            <a
                class="btn"
                href="<?= h(assetUrl('business/event-discovery.php')) ?>"
                data-en="Explore Events"
                data-mr="कार्यक्रम शोधा">
                Explore Events
            </a>
        </div>

        <?php if (!empty($dashboardErrors)): ?>
            <div class="card" style="padding:15px;margin-bottom:20px;">
                <p>
                    Some dashboard information could not be loaded.
                    Please check the application error log.
                </p>
            </div>
        <?php endif; ?>

        <!-- Statistics -->

        <div class="stats-grid">

            <article class="stat-card">
                <span class="stat-label"
                      data-en="Event Organisers"
                      data-mr="कार्यक्रम आयोजक">
                    Event Organisers
                </span>

                <span class="stat-value">
                    <?= number_format($stats['organisers']) ?>
                </span>

                <span class="muted">Published event organisers</span>
            </article>

            <article class="stat-card">
                <span class="stat-label"
                      data-en="Upcoming Events"
                      data-mr="आगामी कार्यक्रम">
                    Upcoming Events
                </span>

                <span class="stat-value">
                    <?= number_format($stats['events']) ?>
                </span>

                <span class="muted">Available opportunities</span>
            </article>

            <article class="stat-card">
                <span class="stat-label"
                      data-en="My Applications"
                      data-mr="माझे अर्ज">
                    My Applications
                </span>

                <span class="stat-value">
                    <?= number_format($stats['applications']) ?>
                </span>

                <span class="muted">Sponsorship applications</span>
            </article>

            <article class="stat-card">
                <span class="stat-label"
                      data-en="Accepted Sponsorships"
                      data-mr="स्वीकृत प्रायोजकत्व">
                    Accepted Sponsorships
                </span>

                <span class="stat-value">
                    <?= number_format($stats['active_sponsorships']) ?>
                </span>

                <span class="muted">Successful matches</span>
            </article>

        </div>

        <!-- Quick actions -->

        <div class="section-heading">
            <h2 data-en="Quick Actions" data-mr="जलद कृती">
                Quick Actions
            </h2>
        </div>

        <div class="card-grid">

            <article class="card">
                <h3>🔎 Find Organisers</h3>

                <p class="muted">
                    Explore event organisers and review their completed
                    event history before contacting them.
                </p>

                <a class="btn"
                   href="<?= h(assetUrl('business/find-organisers.php')) ?>">
                    Find Organisers
                </a>
            </article>

            <article class="card">
                <h3>🎉 Discover Events</h3>

                <p class="muted">
                    Explore upcoming college events, festivals,
                    exhibitions and other sponsorship opportunities.
                </p>

                <a class="btn"
                   href="<?= h(assetUrl('business/event-discovery.php')) ?>">
                    View Events
                </a>
            </article>

            <article class="card">
                <h3>📩 My Applications</h3>

                <p class="muted">
                    Review your sponsorship applications and their
                    current status.
                </p>

                <a class="btn"
                   href="<?= h(assetUrl('business/applications.php')) ?>">
                    View Applications
                </a>
            </article>

        </div>

        <!-- Upcoming events -->

        <div class="section-heading" style="margin-top:32px">
            <h2 data-en="Upcoming Events"
                data-mr="आगामी कार्यक्रम">
                Upcoming Events
            </h2>

            <a href="<?= h(assetUrl('business/event-discovery.php')) ?>">
                View all →
            </a>
        </div>

        <?php if (empty($upcomingEvents)): ?>

            <div class="card">
                <h3>No upcoming events yet</h3>

                <p class="muted">
                    Published events will appear here when organisers
                    add them to the platform.
                </p>
            </div>

        <?php else: ?>

            <div class="dashboard-grid">

                <?php foreach ($upcomingEvents as $event): ?>

                    <article class="event-card">

                        <span class="badge">
                            <?= h($event['event_type'] ?: 'General Event') ?>
                        </span>

                        <h3><?= h($event['title']) ?></h3>

                        <div class="event-meta">
                            <span>
                                📅 <?= h(formatDate($event['event_date'])) ?>
                            </span>

                            <span>
                                📍 <?= h($event['location'] ?: 'Not specified') ?>
                            </span>
                        </div>

                        <p class="muted">
                            Organiser: <?= h($event['organiser_name']) ?>
                        </p>

                        <p>
                            <?= h(mb_strimwidth(
                                (string) ($event['description'] ?? ''),
                                0,
                                140,
                                '...'
                            )) ?>
                        </p>

                        <a
                            class="btn"
                            href="<?= h(assetUrl(
                                'business/event-details.php?id=' .
                                (int) $event['id']
                            )) ?>">
                            View Event
                        </a>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

        <!-- Experienced organisers -->

        <div class="section-heading" style="margin-top:32px">
            <h2 data-en="Experienced Event Organisers"
                data-mr="अनुभवी कार्यक्रम आयोजक">
                Experienced Event Organisers
            </h2>

            <a href="<?= h(assetUrl('business/find-organisers.php')) ?>">
                Find more →
            </a>
        </div>

        <?php if (empty($topOrganisers)): ?>

            <div class="card">
                <p class="muted">
                    Organisers with completed events will appear here.
                </p>
            </div>

        <?php else: ?>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Organiser</th>
                            <th>Completed Events</th>
                            <th>Profile</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($topOrganisers as $organiser): ?>

                            <tr>
                                <td><?= h($organiser['name']) ?></td>

                                <td>
                                    <?= number_format(
                                        (int) $organiser['completed_events']
                                    ) ?>
                                </td>

                                <td>
                                    <a href="<?= h(assetUrl(
                                        'business/organiser-details.php?id=' .
                                        (int) $organiser['id']
                                    )) ?>">
                                        View Profile
                                    </a>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>

        <?php endif; ?>

        <!-- Premium packages -->

        <div class="card" style="margin-top:32px">
            <h2>⭐ Business Premium</h2>

            <p class="muted">
                Explore subscription options for discovering organisers
                and finding suitable event sponsorship opportunities.
            </p>

            <a class="btn"
               href="<?= h(assetUrl('business/packages.php')) ?>">
                View Premium Packages
            </a>
        </div>

    </section>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
