
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('business_manager');

$user = currentUser();

$pageTitle = 'Sponsorship Applications';
$activePage = 'applications';

$applications = [];
$errorMessage = '';

/*
|--------------------------------------------------------------------------
| Load applications submitted by the logged-in business
|--------------------------------------------------------------------------
*/

try {
    $stmt = $pdo->prepare("
        SELECT
            sa.id,
            sa.status,
            e.id AS event_id,
            e.title AS event_title,
            e.event_date,
            e.location,
            u.id AS organiser_id,
            u.name AS organiser_name
        FROM sponsorship_applications sa
        INNER JOIN events e ON e.id = sa.event_id
        INNER JOIN users u ON u.id = e.user_id
        WHERE sa.business_manager_id = :business_id
        ORDER BY sa.id DESC
        LIMIT 100
    ");

    $stmt->execute([
        'business_id' => (int) $user['id']
    ]);

    $applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log('Business applications page error: ' . $e->getMessage());

    $errorMessage = 'Applications could not be loaded. Please check your database configuration.';
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/sidebar.php';
?>

<section class="dashboard-container">

    <h1>Sponsorship Applications</h1>

    <p>
        Track sponsorship applications submitted by your business
        and check their current status.
    </p>

    <?php if ($errorMessage !== ''): ?>

        <div class="card" style="padding:16px;margin-top:20px;">
            <p class="alert alert-error">
                <?= h($errorMessage) ?>
            </p>
        </div>

    <?php else: ?>

        <!-- Application statistics -->

        <div class="stats-grid" style="margin-top:20px;">

            <article class="stat-card">
                <span class="stat-label">Total Applications</span>

                <span class="stat-value">
                    <?= number_format(count($applications)) ?>
                </span>
            </article>

        </div>

        <!-- Applications table -->

        <div class="section-heading" style="margin-top:24px;">
            <h2>My Applications</h2>
        </div>

        <div class="card" style="padding:20px;overflow-x:auto;">

            <table style="width:100%;border-collapse:collapse;">

                <thead>
                    <tr>
                        <th align="left">Event</th>
                        <th align="left">Organiser</th>
                        <th align="left">Date</th>
                        <th align="left">Location</th>
                        <th align="left">Status</th>
                        <th align="left">Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (empty($applications)): ?>

                        <tr>
                            <td colspan="6" style="padding:20px;">
                                <strong>No applications found.</strong>

                                <p class="muted">
                                    Explore upcoming events and submit
                                    sponsorship applications to get started.
                                </p>

                                <a
                                    class="btn btn-primary"
                                    href="<?= h(assetUrl('business/event-discovery.php')) ?>"
                                >
                                    Explore Events
                                </a>
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($applications as $application): ?>

                            <?php
                            $status = strtolower(
                                (string) $application['status']
                            );

                            $statusLabel = ucfirst($status);
                            ?>

                            <tr>

                                <td style="padding:12px 8px;">
                                    <strong>
                                        <?= h($application['event_title']) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= h($application['organiser_name']) ?>
                                </td>

                                <td>
                                    <?= h(formatDate($application['event_date'])) ?>
                                </td>

                                <td>
                                    <?= h(
                                        $application['location'] ?: 'Not specified'
                                    ) ?>
                                </td>

                                <td>
                                    <span class="role-badge">
                                        <?= h($statusLabel) ?>
                                    </span>
                                </td>

                                <td>
                                    <a
                                        href="<?= h(assetUrl(
                                            'business/event-details.php?id=' .
                                            (int) $application['event_id']
                                        )) ?>"
                                    >
                                        View Event
                                    </a>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    <?php endif; ?>

</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
