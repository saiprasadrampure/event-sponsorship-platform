
<?php

// ========================================
// SESSION AND DATABASE
// ========================================

require_once __DIR__ . '/includes/db.php';

// Session is already started in config.php.


// ========================================
// CSRF TOKEN
// ========================================

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


// ========================================
// REDIRECT LOGGED-IN USERS
// ========================================

if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}


// ========================================
// LOGIN PROCESSING
// ========================================

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $token = $_POST['csrf_token'] ?? '';

    if (
        !is_string($token) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {

        $error = 'Invalid request. Refresh the page and try again.';

    } else {

        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        if (
            !filter_var($email, FILTER_VALIDATE_EMAIL) ||
            !is_string($password) ||
            $password === '' ||
            strlen($password) > 72
        ) {

            $error = 'Invalid email or password.';

        } else {

            try {

                $stmt = $pdo->prepare(
                    'SELECT id, name, email, password_hash, role
                     FROM users
                     WHERE email = :email
                     LIMIT 1'
                );

                $stmt->execute([
                    'email' => $email
                ]);

                $user = $stmt->fetch();

                if (
                    $user &&
                    password_verify($password, $user['password_hash'])
                ) {

                    session_regenerate_id(true);

                    $_SESSION['user_id'] = (int) $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_role'] = $user['role'];

                    $_SESSION['csrf_token'] = bin2hex(
                        random_bytes(32)
                    );

                    header('Location: index.php');
                    exit;

                } else {

                    $error = 'Invalid email or password.';

                }

            } catch (PDOException $e) {

                error_log('Login error: ' . $e->getMessage());

                $error = 'Unable to process login. Please try again.';

            }
        }
    }
}


// ========================================
// HTML ESCAPE FUNCTION
// ========================================

function e(string $value): string
{
    return htmlspecialchars(
        $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Login | EventConnect AI</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f3f5fb;
    color: #192033;
    min-height: 100vh;
    display: grid;
    place-items: center;
    padding: 20px;
}

.card {
    width: 100%;
    max-width: 430px;
    background: white;
    padding: 32px;
    border-radius: 18px;
    box-shadow: 0 10px 40px #17255412;
}

h1 {
    margin: 0 0 8px;
}

.muted {
    color: #64748b;
}

label {
    display: block;
    margin: 18px 0 7px;
    font-weight: 600;
}

input {
    width: 100%;
    padding: 12px;
    border: 1px solid #d8deea;
    border-radius: 9px;
    font-size: 15px;
}

button {
    width: 100%;
    margin-top: 24px;
    padding: 13px;
    background: #635bff;
    color: white;
    border: 0;
    border-radius: 9px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #5048e5;
}

.error {
    padding: 12px;
    background: #fff0f0;
    color: #a11;
    border-radius: 8px;
}

a {
    color: #635bff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

</style>

</head>

<body>

<main class="card">

    <h1>Welcome back 👋</h1>

    <p class="muted">
        Login to your EventConnect AI account.
    </p>


    <?php if ($error !== ''): ?>

        <p class="error">
            <?= e($error) ?>
        </p>

    <?php endif; ?>


    <form method="post" action="login.php">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e($_SESSION['csrf_token']) ?>"
        >


        <label for="email">
            Email address
        </label>

        <input
            id="email"
            type="email"
            name="email"
            autocomplete="email"
            maxlength="190"
            required
            value="<?= e($_POST['email'] ?? '') ?>"
        >


        <label for="password">
            Password
        </label>

        <input
            id="password"
            type="password"
            name="password"
            autocomplete="current-password"
            maxlength="72"
            required
        >


        <button type="submit">
            Login
        </button>

    </form>


    <p class="muted">
        Don't have an account?

        <a href="register.php">
            Register now
        </a>
    </p>


    <p>
        <a href="index.php">
            ← Back to homepage
        </a>
    </p>

</main>

</body>
</html>
