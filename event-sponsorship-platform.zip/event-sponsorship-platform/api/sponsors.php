
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

try {
    apiMethod('GET');
    apiRequireRole('event_organiser', 'admin');

    $q = trim((string) ($_GET['q'] ?? ''));

    $sql = "SELECT u.id, u.name,
                   COALESCE(bp.business_name, u.name) AS business_name,
                   bp.verification_status
            FROM users u
            LEFT JOIN business_profiles bp ON bp.user_id = u.id
            WHERE u.role = 'business_manager'
              AND u.is_active = 1";
    $params = [];

    if ($q !== '') {
        $sql .= ' AND (u.name LIKE ? OR bp.business_name LIKE ?)';
        $params[] = '%' . $q . '%';
        $params[] = '%' . $q . '%';
    }

    $sql .= " ORDER BY
                CASE WHEN bp.verification_status = 'approved' THEN 0 ELSE 1 END,
                business_name ASC
              LIMIT 100";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    apiJson([
        'success' => true,
        'data' => $stmt->fetchAll(PDO::FETCH_ASSOC),
    ]);
} catch (Throwable $e) {
    apiHandleError($e);
}
