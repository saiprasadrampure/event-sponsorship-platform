
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

try {
    apiMethod('GET', 'POST');
    $user = apiRequireLogin();
    $userId = (int) $user['id'];

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $unreadOnly = ($_GET['unread'] ?? '') === '1';

        $sql = 'SELECT id, title, message, is_read, created_at
                FROM notifications WHERE user_id = ?';
        $params = [$userId];

        if ($unreadOnly) {
            $sql .= ' AND is_read = 0';
        }

        $sql .= ' ORDER BY created_at DESC LIMIT 100';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare(
            'SELECT COUNT(*) FROM notifications
             WHERE user_id = ? AND is_read = 0'
        );
        $stmt->execute([$userId]);
        $unreadCount = (int) $stmt->fetchColumn();

        apiJson([
            'success' => true,
            'unread_count' => $unreadCount,
            'data' => $items,
        ]);
    }

    apiRequireCsrf();
    $data = apiReadJson();

    if (($data['all'] ?? false) === true) {
        $stmt = $pdo->prepare(
            'UPDATE notifications SET is_read = 1
             WHERE user_id = ? AND is_read = 0'
        );
        $stmt->execute([$userId]);

        apiJson([
            'success' => true,
            'message' => 'All notifications marked as read.',
            'updated' => $stmt->rowCount(),
        ]);
    }

    $notificationId = filter_var(
        $data['id'] ?? null,
        FILTER_VALIDATE_INT
    );

    if (!$notificationId || $notificationId < 1) {
        apiJson([
            'success' => false,
            'message' => 'Provide a valid notification ID or all=true.',
        ], 422);
    }

    $stmt = $pdo->prepare(
        'UPDATE notifications SET is_read = 1
         WHERE id = ? AND user_id = ?'
    );
    $stmt->execute([$notificationId, $userId]);

    apiJson([
        'success' => true,
        'message' => 'Notification marked as read if it belongs to your account.',
    ]);
} catch (Throwable $e) {
    apiHandleError($e);
}
