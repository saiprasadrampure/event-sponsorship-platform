
-- =========================================================
-- EventConnect AI - Demo / Sample Data
-- Import schema.sql BEFORE importing this file.
-- Demo website password: password
-- =========================================================

USE event_platform;

SET NAMES utf8mb4;

-- ---------------------------------------------------------
-- DEMO USERS
-- The password_hash is a bcrypt hash for "password".
-- ---------------------------------------------------------

INSERT IGNORE INTO users
    (id, name, email, password_hash, role, phone, is_active)
VALUES
    (1, 'System Administrator', 'admin@example.com',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
     'admin', '9000000001', 1),

    (2, 'Aarav Sharma', 'organiser@example.com',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
     'event_organiser', '9000000002', 1),

    (3, 'Priya Patel', 'business@example.com',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
     'business_manager', '9000000003', 1),

    (4, 'Rohan Deshmukh', 'customer@example.com',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
     'customer', '9000000004', 1),

    (5, 'Neha Kulkarni', 'business2@example.com',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
     'business_manager', '9000000005', 1),

    (6, 'Karan Joshi', 'organiser2@example.com',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.',
     'event_organiser', '9000000006', 1);

-- ---------------------------------------------------------
-- BUSINESS PROFILES
-- ---------------------------------------------------------

INSERT IGNORE INTO business_profiles
    (
        user_id, business_name, industry, website,
        address, city, description, target_audience,
        preferred_event_types, sponsorship_budget,
        verification_status
    )
VALUES
    (
        3, 'Priya Refreshments', 'Food and Beverages',
        'https://example.com',
        'FC Road', 'Pune',
        'A sample beverage business interested in community events.',
        'Students, families and young professionals',
        'Music, Education, Community',
        50000.00, 'verified'
    ),
    (
        5, 'Neha Digital Solutions', 'Technology',
        'https://example.org',
        'Baner', 'Pune',
        'A sample technology business interested in technology and education events.',
        'Students, developers and professionals',
        'Technology, Education, Business',
        100000.00, 'pending'
    );

-- ---------------------------------------------------------
-- ORGANISER PROFILES
-- ---------------------------------------------------------

INSERT IGNORE INTO organiser_profiles
    (
        user_id, organisation_name, organisation_type,
        website, address, city, description,
        experience_years, verification_status
    )
VALUES
    (
        2, 'Aarav Events', 'Event Management',
        'https://example.com',
        'Shivajinagar', 'Pune',
        'Organising student festivals and community events.',
        3, 'verified'
    ),
    (
        6, 'Karan Community Events', 'Community Organisation',
        'https://example.org',
        'Kothrud', 'Pune',
        'Organising educational and local community programmes.',
        2, 'pending'
    );

-- ---------------------------------------------------------
-- EVENTS
-- Dates are set in the future relative to October 2026.
-- ---------------------------------------------------------

INSERT IGNORE INTO events
    (
        id, user_id, title, event_type, event_date,
        location, description, sponsorship_amount,
        expected_attendees, status
    )
VALUES
    (
        1, 2, 'Pune College Music Festival',
        'Music', '2026-12-12',
        'Pune, Maharashtra',
        'A student music festival featuring local performers, food stalls and cultural activities.',
        50000.00, 1200, 'published'
    ),
    (
        2, 2, 'Youth Technology Summit',
        'Technology', '2027-01-20',
        'Pune, Maharashtra',
        'A technology event featuring student projects, presentations and networking.',
        100000.00, 800, 'published'
    ),
    (
        3, 6, 'Community Education Fair',
        'Education', '2027-02-15',
        'Pune, Maharashtra',
        'An educational community fair with workshops and learning activities.',
        30000.00, 500, 'published'
    ),
    (
        4, 6, 'Organiser Planning Draft',
        'Community', '2027-03-10',
        'Pune, Maharashtra',
        'A sample draft event that is not yet publicly published.',
        20000.00, 250, 'draft'
    );

-- ---------------------------------------------------------
-- SPONSORSHIP APPLICATION
-- ---------------------------------------------------------

INSERT IGNORE INTO sponsorship_applications
    (
        id, event_id, business_manager_id, message,
        proposed_amount, status
    )
VALUES
    (
        1, 1, 3,
        'We are interested in supporting refreshments for the festival.',
        25000.00, 'pending'
    );

-- ---------------------------------------------------------
-- CUSTOMER SAVED EVENTS
-- ---------------------------------------------------------

INSERT IGNORE INTO saved_events (customer_id, event_id)
VALUES
    (4, 1),
    (4, 2);

-- ---------------------------------------------------------
-- CUSTOMER EVENT REGISTRATIONS
-- ---------------------------------------------------------

INSERT IGNORE INTO event_registrations
    (customer_id, event_id, status)
VALUES
    (4, 1, 'registered');

-- ---------------------------------------------------------
-- ORGANISER POSTS
-- ---------------------------------------------------------

INSERT IGNORE INTO organiser_posts
    (
        id, user_id, event_id, title, content, status
    )
VALUES
    (
        1, 2, 1,
        'Music Festival Announcement',
        'We are preparing a music festival for students and local performers. Sponsorship enquiries are welcome.',
        'published'
    ),
    (
        2, 6, 3,
        'Education Fair Update',
        'Our community education fair will include workshops and learning activities.',
        'published'
    );

-- ---------------------------------------------------------
-- BUSINESS POSTS
-- ---------------------------------------------------------

INSERT IGNORE INTO business_posts
    (id, user_id, title, content, status)
VALUES
    (
        1, 3,
        'Community Sponsorship Opportunities',
        'We are exploring opportunities to support suitable community and student events.',
        'published'
    );

-- ---------------------------------------------------------
-- SUBSCRIPTION DEMO
-- ---------------------------------------------------------

INSERT IGNORE INTO subscriptions
    (
        id, user_id, package_name, amount, status,
        starts_at, ends_at
    )
VALUES
    (
        1, 3, 'Premium', 599.00, 'active',
        '2026-10-01 00:00:00',
        '2027-10-01 00:00:00'
    );

-- ---------------------------------------------------------
-- NOTIFICATIONS
-- ---------------------------------------------------------

INSERT IGNORE INTO notifications
    (
        id, user_id, title, message, type, related_id, is_read
    )
VALUES
    (
        1, 2,
        'New Sponsorship Application',
        'A business has expressed interest in your music festival.',
        'application', 1, 0
    ),
    (
        2, 3,
        'Application Submitted',
        'Your sponsorship application has been recorded.',
        'application', 1, 0
    ),
    (
        3, 4,
        'Welcome to EventConnect AI',
        'Explore published events and save the ones you like.',
        'general', NULL, 0
    );

-- ---------------------------------------------------------
-- AI RECOMMENDATION DEMO
-- ---------------------------------------------------------

INSERT IGNORE INTO sponsor_recommendations
    (
        event_id, business_manager_id, match_score, reason
    )
VALUES
    (
        1, 3, 88.00,
        'Food and beverage business with a stated interest in music and community events.'
    ),
    (
        2, 5, 91.00,
        'Technology business with a stated interest in technology and education events.'
    );

-- ---------------------------------------------------------
-- REPORT DEMO
-- ---------------------------------------------------------

INSERT IGNORE INTO reports
    (
        id, reporter_id, reported_user_id, event_id,
        reason, description, status
    )
VALUES
    (
        1, 4, 6, 3,
        'Sample report',
        'Example report record for testing the admin reports page.',
        'open'
    );

-- ---------------------------------------------------------
-- VERIFY THE IMPORT
-- ---------------------------------------------------------

SELECT id, name, email, role, is_active
FROM users
ORDER BY id;

SELECT id, title, event_date, status
FROM events
ORDER BY id;
