
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

try {
    apiMethod('GET');
    apiRequireLogin();

    $q = trim((string) ($_GET['q'] ?? ''));
    $id = $_GET['id'] ?? null;

    $sql = "SELECT u.id, u.name,
                   op.verification_status,
                   COUNT(DISTINCT CASE WHEN e.status = 'completed'
                       THEN e.id END) AS completed_events,
                   COUNT(DISTINCT CASE WHEN e.status = 'published'
                       THEN e.id END) AS published_events
            FROM users u
            LEFT JOIN organiser_profiles op ON op.user_id = u.id
            LEFT JOIN events e ON e.user_id = u.id
            WHERE u.role = 'event_organiser'
              AND u.is_active = 1";
    $params = [];

    if ($id !== null) {
        if (!ctype_digit((string) $id) || (int) $id < 1) {
            apiJson(['success' => false, 'message' => 'Invalid organiser ID.'], 422);
        }
        $sql .= ' AND u.id = ?';
        $params[] = (int) $id;
    }

    if ($q !== '') {
        $sql .= ' AND u.name LIKE ?';
        $params[] = '%' . $q . '%';
    }

    $sql .= ' GROUP BY u.id, u.name, op.verification_status
              ORDER BY completed_events DESC, u.name ASC
              LIMIT 100';

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $organisers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    apiJson(['success' => true, 'data' => $organisers]);
} catch (Throwable $e) {
    apiHandleError($e);
}
