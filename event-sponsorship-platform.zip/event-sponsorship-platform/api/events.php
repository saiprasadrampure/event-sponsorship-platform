
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

try {
    apiMethod('GET', 'POST');

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $user = apiRequireLogin();
        $mine = ($_GET['mine'] ?? '') === '1';

        if ($mine && $user['role'] !== 'event_organiser' && $user['role'] !== 'admin') {
            apiJson(['success' => false, 'message' => 'Access denied.'], 403);
        }

        $sql = 'SELECT e.id, e.user_id, e.title, e.event_type,
                       e.event_date, e.location, e.description, e.status,
                       u.name AS organiser_name
                FROM events e
                LEFT JOIN users u ON u.id = e.user_id
                WHERE 1=1';
        $params = [];

        if ($mine) {
            if ($user['role'] !== 'admin') {
                $sql .= ' AND e.user_id = ?';
                $params[] = (int) $user['id'];
            }
        } else {
            $sql .= " AND e.status = 'published'";
        }

        if (isset($_GET['id']) && ctype_digit((string) $_GET['id'])) {
            $sql .= ' AND e.id = ?';
            $params[] = (int) $_GET['id'];
        }

        $q = trim((string) ($_GET['q'] ?? ''));
        if ($q !== '') {
            $sql .= ' AND (e.title LIKE ? OR e.location LIKE ?)';
            $params[] = '%' . $q . '%';
            $params[] = '%' . $q . '%';
        }

        $type = trim((string) ($_GET['type'] ?? ''));
        if ($type !== '') {
            $sql .= ' AND e.event_type = ?';
            $params[] = $type;
        }

        $sql .= ' ORDER BY e.event_date ASC LIMIT 100';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        apiJson([
            'success' => true,
            'data' => $stmt->fetchAll(PDO::FETCH_ASSOC),
        ]);
    }

    $user = apiRequireRole('event_organiser');
    apiRequireCsrf();
    $data = apiReadJson();

    $title = trim((string) ($data['title'] ?? ''));
    $type = trim((string) ($data['event_type'] ?? ''));
    $date = trim((string) ($data['event_date'] ?? ''));
    $location = trim((string) ($data['location'] ?? ''));
    $description = trim((string) ($data['description'] ?? ''));

    if (
        $title === '' || $type === '' || $date === '' ||
        $location === '' || $description === ''
    ) {
        apiJson(['success' => false, 'message' => 'All event fields are required.'], 422);
    }

    $parsedDate = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    if (!$parsedDate || $parsedDate->format('Y-m-d') !== $date) {
        apiJson(['success' => false, 'message' => 'Use a valid YYYY-MM-DD event date.'], 422);
    }

    if (
        mb_strlen($title) > 150 ||
        mb_strlen($type) > 100 ||
        mb_strlen($location) > 255
    ) {
        apiJson(['success' => false, 'message' => 'One or more fields are too long.'], 422);
    }

    $stmt = $pdo->prepare(
        'INSERT INTO events
            (user_id, title, event_type, event_date, location, description, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        (int) $user['id'],
        $title,
        $type,
        $date,
        $location,
        $description,
        'draft',
    ]);

    apiJson([
        'success' => true,
        'message' => 'Event saved as a draft.',
        'data' => ['id' => (int) $pdo->lastInsertId()],
    ], 201);
} catch (Throwable $e) {
    apiHandleError($e);
}
