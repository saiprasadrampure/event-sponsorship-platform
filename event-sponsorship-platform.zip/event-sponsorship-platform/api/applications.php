
<?php
declare(strict_types=1);

require_once __DIR__ . '/_common.php';

try {
    apiMethod('GET', 'POST');
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $user = apiRequireRole('business_manager', 'event_organiser', 'admin');

        $sql = "SELECT a.id, a.event_id, a.business_manager_id,
                       a.message, a.status, a.created_at,
                       e.title AS event_title, e.event_date,
                       e.user_id AS organiser_id,
                       u.name AS business_name
                FROM sponsorship_applications a
                INNER JOIN events e ON e.id = a.event_id
                INNER JOIN users u ON u.id = a.business_manager_id
                WHERE 1=1";
        $params = [];

        if ($user['role'] === 'business_manager') {
            $sql .= ' AND a.business_manager_id = ?';
            $params[] = (int) $user['id'];
        } elseif ($user['role'] === 'event_organiser') {
            $sql .= ' AND e.user_id = ?';
            $params[] = (int) $user['id'];
        }

        if (isset($_GET['event_id'])) {
            if (!ctype_digit((string) $_GET['event_id'])) {
                apiJson(['success' => false, 'message' => 'Invalid event ID.'], 422);
            }
            $sql .= ' AND a.event_id = ?';
            $params[] = (int) $_GET['event_id'];
        }

        $sql .= ' ORDER BY a.created_at DESC LIMIT 200';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        apiJson([
            'success' => true,
            'data' => $stmt->fetchAll(PDO::FETCH_ASSOC),
        ]);
    }

    $user = apiRequireRole('business_manager', 'event_organiser');
    apiRequireCsrf();
    $data = apiReadJson();

    // Business manager submits a new application.
    if ($user['role'] === 'business_manager') {
        $eventId = filter_var(
            $data['event_id'] ?? null,
            FILTER_VALIDATE_INT
        );
        $message = trim((string) ($data['message'] ?? ''));

        if (!$eventId || $eventId < 1) {
            apiJson(['success' => false, 'message' => 'A valid event ID is required.'], 422);
        }

        if (mb_strlen($message) > 5000) {
            apiJson(['success' => false, 'message' => 'Message is too long.'], 422);
        }

        $stmt = $pdo->prepare(
            "SELECT id, user_id, title
             FROM events
             WHERE id = ? AND status = 'published'"
        );
        $stmt->execute([$eventId]);
        $event = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$event) {
            apiJson(['success' => false, 'message' => 'Published event not found.'], 404);
        }

        if ((int) $event['user_id'] === (int) $user['id']) {
            apiJson(['success' => false, 'message' => 'You cannot sponsor your own event.'], 422);
        }

        $stmt = $pdo->prepare(
            "INSERT INTO sponsorship_applications
                (event_id, business_manager_id, message, status)
             VALUES (?, ?, ?, 'pending')"
        );

        try {
            $stmt->execute([$eventId, (int) $user['id'], $message]);
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                apiJson([
                    'success' => false,
                    'message' => 'You have already applied to sponsor this event.',
                ], 409);
            }
            throw $e;
        }

        $notification = $pdo->prepare(
            'INSERT INTO notifications (user_id, title, message)
             VALUES (?, ?, ?)'
        );
        $notification->execute([
            (int) $event['user_id'],
            'New sponsorship application',
            $user['name'] . ' applied to sponsor "' . $event['title'] . '".',
        ]);

        apiJson([
            'success' => true,
            'message' => 'Sponsorship application submitted.',
            'data' => ['id' => (int) $pdo->lastInsertId()],
        ], 201);
    }

    // Organiser can update an application only for their own event.
    $applicationId = filter_var(
        $data['application_id'] ?? null,
        FILTER_VALIDATE_INT
    );
    $status = $data['status'] ?? '';

    if (
        !$applicationId || $applicationId < 1 ||
        !in_array($status, ['accepted', 'rejected'], true)
    ) {
        apiJson([
            'success' => false,
            'message' => 'Valid application ID and accepted/rejected status are required.',
        ], 422);
    }

    $pdo->beginTransaction();

    $stmt = $pdo->prepare(
        'SELECT a.id, a.status, a.business_manager_id, e.title, e.user_id
         FROM sponsorship_applications a
         INNER JOIN events e ON e.id = a.event_id
         WHERE a.id = ? FOR UPDATE'
    );
    $stmt->execute([$applicationId]);
    $application = $stmt->fetch(PDO::FETCH_ASSOC);

    if (
        !$application ||
        (int) $application['user_id'] !== (int) $user['id']
    ) {
        $pdo->rollBack();
        apiJson(['success' => false, 'message' => 'Application not found.'], 404);
    }

    if ($application['status'] !== 'pending') {
        $pdo->rollBack();
        apiJson([
            'success' => false,
            'message' => 'Only pending applications can be reviewed.',
        ], 409);
    }

    $stmt = $pdo->prepare(
        'UPDATE sponsorship_applications SET status = ? WHERE id = ?'
    );
    $stmt->execute([$status, $applicationId]);

    $stmt = $pdo->prepare(
        'INSERT INTO notifications (user_id, title, message)
         VALUES (?, ?, ?)'
    );
    $stmt->execute([
        (int) $application['business_manager_id'],
        'Sponsorship application update',
        'Your application for "' . $application['title'] . '" was ' . $status . '.',
    ]);

    $pdo->commit();

    apiJson([
        'success' => true,
        'message' => 'Application ' . $status . '.',
    ]);
} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    apiHandleError($e);
}
